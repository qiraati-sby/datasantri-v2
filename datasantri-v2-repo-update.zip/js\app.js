﻿// Konfigurasi URL Google Apps Script Web App (Terkoneksi langsung ke Google Spreadsheet)
        const GOOGLE_SCRIPT_WEB_APP_URL = "https://script.google.com/macros/s/AKfycbztyMICYVpwbIvo7nLSiYxxGBJfJcMdI33pI40yTlQLj7cJfihDR6sbg0N6uhg_o6lc/exec";

        let globalData = [];
        let chartKecamatanInstance = null;
        let chartJenjangInstance = null;
        let chartKelasDetailInstance = null;
        let chartUsiaInstance = null;
        let currentChartFilter = 'all'; // 'all', 'dasar', 'pra', 'ptpt'

        // ================= FUNGSI KALKULATOR USIA & MASA MENGAJAR =================
        // 1. Hitung Usia Santri Detail: Tahun - Bulan - Hari
        function hitungUsiaSantriDetail(tglLahirStr) {
            if (!tglLahirStr) return '-';
            let str = String(tglLahirStr).trim();
            let datePart = str;
            const match = str.match(/\d{4}-\d{2}-\d{2}/);
            if (match) {
                datePart = match[0];
            }
            const dob = new Date(datePart);
            if (isNaN(dob.getTime())) return '-';

            const today = new Date();
            if (dob > today) return '-';

            let years = today.getFullYear() - dob.getFullYear();
            let months = today.getMonth() - dob.getMonth();
            let days = today.getDate() - dob.getDate();

            if (days < 0) {
                months -= 1;
                const prevMonthDays = new Date(today.getFullYear(), today.getMonth(), 0).getDate();
                days += prevMonthDays;
            }

            if (months < 0) {
                years -= 1;
                months += 12;
            }

            let parts = [];
            if (years > 0) parts.push(`${years} th`);
            if (months > 0 || years > 0) parts.push(`${months} bln`);
            parts.push(`${days} hr`);
            return parts.join(' ');
        }

        // 2. Hitung Usia Guru: Cukup Tahun & Bulan saja
        function hitungUsiaGuruTahunBulan(tglLahirStr) {
            if (!tglLahirStr) return '-';
            let str = String(tglLahirStr).trim();
            let datePart = str;
            const match = str.match(/\d{4}-\d{2}-\d{2}/);
            if (match) {
                datePart = match[0];
            }
            const dob = new Date(datePart);
            if (isNaN(dob.getTime())) return '-';

            const today = new Date();
            if (dob > today) return '-';

            let years = today.getFullYear() - dob.getFullYear();
            let months = today.getMonth() - dob.getMonth();
            if (today.getDate() < dob.getDate()) {
                months -= 1;
            }
            if (months < 0) {
                years -= 1;
                months += 12;
            }

            let parts = [];
            if (years > 0) parts.push(`${years} th`);
            if (months > 0 || years > 0) parts.push(`${months} bln`);
            return parts.length > 0 ? parts.join(' ') : '0 bln';
        }

        // 3. Hitung Lama Mengajar Guru: Cukup Tahun & Bulan saja
        function hitungLamaMengajarTahunBulan(tglMulaiStr) {
            if (!tglMulaiStr) return '-';
            let str = String(tglMulaiStr).trim();
            let datePart = str;
            const match = str.match(/\d{4}-\d{2}-\d{2}/);
            if (match) {
                datePart = match[0];
            }
            const dStart = new Date(datePart);
            if (isNaN(dStart.getTime())) return '-';

            const today = new Date();
            if (dStart > today) return '-';

            let years = today.getFullYear() - dStart.getFullYear();
            let months = today.getMonth() - dStart.getMonth();
            if (today.getDate() < dStart.getDate()) {
                months -= 1;
            }
            if (months < 0) {
                years -= 1;
                months += 12;
            }

            let parts = [];
            if (years > 0) parts.push(`${years} th`);
            if (months > 0 || years > 0) parts.push(`${months} bln`);
            return parts.length > 0 ? parts.join(' ') : '< 1 bln';
        }

        // 4. Pengelompokan Kategori Usia Santri (Bocil vs Bocol berbasis Jenjang)
        // Hitung umur eksak: tahun dan selisih hari setelah ulang tahun terakhir
        function getDetailUmurSantri(tglLahirStr) {
            if (!tglLahirStr) return null;
            let str = String(tglLahirStr).trim();
            const match = str.match(/\d{4}-\d{2}-\d{2}/);
            const datePart = match ? match[0] : str;
            const dob = new Date(datePart);
            if (isNaN(dob.getTime())) return null;

            const today = new Date();
            if (dob > today) return null;

            let years = today.getFullYear() - dob.getFullYear();
            let m = today.getMonth() - dob.getMonth();
            let d = today.getDate() - dob.getDate();

            if (d < 0) {
                m -= 1;
            }
            if (m < 0) {
                years -= 1;
                m += 12;
            }

            // Kelebihan setelah genap N tahun: apakah lebih 1 hari atau lebih?
            // Jika years === 5 dan (m > 0 || d > 0), berarti sudah lewat dari tepat 5 tahun.
            return {
                years,
                months: m,
                days: d,
                isLebihDariTepatTahun: function(targetTahun) {
                    if (this.years > targetTahun) return true;
                    if (this.years === targetTahun) {
                        return (this.months > 0 || this.days > 0);
                    }
                    return false;
                }
            };
        }

        // Helper deteksi jenjang santri (dasar, pra, ptpt)
        function deteksiJenjangSantri(s) {
            if (!s) return 'dasar';
            const jilid = String(s.jilidSekarang || s.kelasAwal || s.jilid || '').toLowerCase();
            if (jilid.includes('ptpt') && !jilid.includes('pra')) return 'ptpt';
            if (jilid.includes('pra')) return 'pra';
            return 'dasar';
        }

        // Klasifikasi Bocil vs Bocol:
        // - TPQ Pagi: usia 3 - 5 tahun = Bocil. Usia 5 tahun + 1 hari ke atas = Bocol.
        // - Pra PTPT / PTPT: usia 3 - 9 tahun = Bocil. Usia 9 tahun + 1 hari ke atas = Bocol.
        function getKategoriBocilBocol(s) {
            const jenjang = deteksiJenjangSantri(s);
            const umurObj = getDetailUmurSantri(s.tglLahir || s.ttl || s.tanggalLahir);
            if (!umurObj) return { jenjang, status: 'bocil', label: 'Bocil' }; // default fallback

            if (jenjang === 'dasar') {
                const isBocol = umurObj.isLebihDariTepatTahun(5);
                return {
                    jenjang: 'dasar',
                    status: isBocol ? 'bocol' : 'bocil',
                    label: isBocol ? 'TPQ Pagi Bocol (> 5 th)' : 'TPQ Pagi Bocil (3â€“5 th)'
                };
            } else if (jenjang === 'pra') {
                const isBocol = umurObj.isLebihDariTepatTahun(9);
                return {
                    jenjang: 'pra',
                    status: isBocol ? 'bocol' : 'bocil',
                    label: isBocol ? 'PRA PTPT Bocol (> 9 th)' : 'PRA PTPT Bocil (3â€“9 th)'
                };
            } else { // ptpt
                const isBocol = umurObj.isLebihDariTepatTahun(9);
                return {
                    jenjang: 'ptpt',
                    status: isBocol ? 'bocol' : 'bocil',
                    label: isBocol ? 'PTPT Bocol (> 9 th)' : 'PTPT Bocil (3â€“9 th)'
                };
            }
        }

        function kategorikanUsiaSantri(tglLahirStr) {
            const umurObj = getDetailUmurSantri(tglLahirStr);
            if (!umurObj) return 'dasar_bocil';
            if (umurObj.years <= 5) return 'dasar_bocil';
            return 'dasar_bocol';
        }

        // Helper deteksi kategori 24 kelas untuk santri perorangan
        function deteksiKategoriKelasSantri(s) {
            if (!s) return null;
            const j = String(s.jilidSekarang || s.kelasAwal || s.jilid || '').toLowerCase().trim();
            if (!j) return null;

            // 1. Pra PTPT (5 level)
            if (j.includes('pra')) {
                if (j.includes('1')) return 'praPtpt1';
                if (j.includes('2')) return 'praPtpt2';
                if (j.includes('3')) return 'praPtpt3';
                if (j.includes('4')) return 'praPtpt4';
                if (j.includes('5')) return 'praPtpt5';
                return 'praPtpt1';
            }

            // 2. PTPT (6 kelas)
            if (j.includes('ptpt')) {
                if (j.includes('1')) return 'ptpt1';
                if (j.includes('2')) return 'ptpt2';
                if (j.includes('3')) return 'ptpt3';
                if (j.includes('4')) return 'ptpt4';
                if (j.includes('5')) return 'ptpt5';
                if (j.includes('6')) return 'ptpt6';
                return 'ptpt1';
            }

            // 3. Persiapan Imtas / Khotaman
            if (j.includes('imtas')) return 'persiapanImtas';
            if (j.includes('khotam')) return 'persiapanKhotaman';

            // 4. TPQ Pagi (13 kelas: 1A-1C, 2A-2B, 3A-3B, 4A-4B, 5A-5B)
            if (j.includes('1a') || (j.includes('1') && j.includes('a'))) return 'kelas1a';
            if (j.includes('1b') || (j.includes('1') && j.includes('b'))) return 'kelas1b';
            if (j.includes('1c') || (j.includes('1') && j.includes('c'))) return 'kelas1c';
            if (j.includes('2a') || (j.includes('2') && j.includes('a'))) return 'kelas2a';
            if (j.includes('2b') || (j.includes('2') && j.includes('b'))) return 'kelas2b';
            if (j.includes('3a') || (j.includes('3') && j.includes('a'))) return 'kelas3a';
            if (j.includes('3b') || (j.includes('3') && j.includes('b'))) return 'kelas3b';
            if (j.includes('4a') || (j.includes('4') && j.includes('a'))) return 'kelas4a';
            if (j.includes('4b') || (j.includes('4') && j.includes('b'))) return 'kelas4b';
            if (j.includes('5a') || (j.includes('5') && j.includes('a'))) return 'kelas5a';
            if (j.includes('5b') || (j.includes('5') && j.includes('b'))) return 'kelas5b';

            if (j.includes('1')) return 'kelas1a';
            if (j.includes('2')) return 'kelas2a';
            if (j.includes('3')) return 'kelas3a';
            if (j.includes('4')) return 'kelas4a';
            if (j.includes('5') || j.includes('6')) return 'kelas5a';

            return 'kelas1a';
        }

        // Kalkulasi Rincian 24 Kelas lengkap dengan Bocil dan Bocol
        function hitungRincian24Kelas(kecName, kecItems, explicitJenjangTotals) {
            const rawTotals = {
                kelas1a: 0, kelas1b: 0, kelas1c: 0,
                kelas2a: 0, kelas2b: 0,
                kelas3a: 0, kelas3b: 0,
                kelas4a: 0, kelas4b: 0,
                kelas5a: 0, kelas5b: 0,
                persiapanImtas: 0, persiapanKhotaman: 0,
                praPtpt1: 0, praPtpt2: 0, praPtpt3: 0, praPtpt4: 0, praPtpt5: 0,
                ptpt1: 0, ptpt2: 0, ptpt3: 0, ptpt4: 0, ptpt5: 0, ptpt6: 0
            };

            (kecItems || []).forEach(item => {
                rawTotals.kelas1a += (item.kelas1a || 0);
                rawTotals.kelas1b += (item.kelas1b || 0);
                rawTotals.kelas1c += (item.kelas1c || 0);
                rawTotals.kelas2a += (item.kelas2a || 0);
                rawTotals.kelas2b += (item.kelas2b || 0);
                rawTotals.kelas3a += (item.kelas3a || 0);
                rawTotals.kelas3b += (item.kelas3b || 0);
                rawTotals.kelas4a += (item.kelas4a || 0);
                rawTotals.kelas4b += (item.kelas4b || 0);
                rawTotals.kelas5a += (item.kelas5a || 0);
                rawTotals.kelas5b += (item.kelas5b || 0);
                rawTotals.persiapanImtas += (item.persiapanImtas || 0);
                rawTotals.persiapanKhotaman += (item.persiapanKhotaman || 0);

                rawTotals.praPtpt1 += (item.praPtpt1 || 0);
                rawTotals.praPtpt2 += (item.praPtpt2 || 0);
                rawTotals.praPtpt3 += (item.praPtpt3 || 0);
                rawTotals.praPtpt4 += (item.praPtpt4 || 0);
                rawTotals.praPtpt5 += (item.praPtpt5 || 0);

                rawTotals.ptpt1 += (item.ptpt1 || 0);
                rawTotals.ptpt2 += (item.ptpt2 || 0);
                rawTotals.ptpt3 += (item.ptpt3 || 0);
                rawTotals.ptpt4 += (item.ptpt4 || 0);
                rawTotals.ptpt5 += (item.ptpt5 || 0);
                rawTotals.ptpt6 += (item.ptpt6 || 0);
            });

            // Ambil data santri perorangan di kecamatan ini
            const santriList = (typeof globalSantri !== 'undefined' && Array.isArray(globalSantri)) ? globalSantri : [];
            const kecSantri = santriList.filter(s => 
                (s.kecamatan || '').toLowerCase() === (kecName || '').toLowerCase() &&
                (s.status || 'Aktif').toLowerCase() !== 'nonaktif'
            );

            const indivStats = {};
            Object.keys(rawTotals).forEach(k => { indivStats[k] = { bocil: 0, bocol: 0 }; });

            kecSantri.forEach(s => {
                const catKey = deteksiKategoriKelasSantri(s);
                if (catKey && indivStats[catKey]) {
                    const kat = getKategoriBocilBocol(s);
                    if (kat.status === 'bocil') indivStats[catKey].bocil++;
                    else indivStats[catKey].bocol++;
                }
            });

            // Bobot demografi usia standar jika belum ada santri individual di kelas tsb
            const defaultRatios = {
                kelas1a: 0.85, kelas1b: 0.82, kelas1c: 0.80,
                kelas2a: 0.75, kelas2b: 0.70,
                kelas3a: 0.65, kelas3b: 0.60,
                kelas4a: 0.45, kelas4b: 0.40,
                kelas5a: 0.30, kelas5b: 0.25,
                persiapanImtas: 0.20, persiapanKhotaman: 0.15,
                praPtpt1: 0.75, praPtpt2: 0.70, praPtpt3: 0.65, praPtpt4: 0.50, praPtpt5: 0.40,
                ptpt1: 0.65, ptpt2: 0.60, ptpt3: 0.55, ptpt4: 0.45, ptpt5: 0.40, ptpt6: 0.35
            };

            const listDasar = ['kelas1a','kelas1b','kelas1c','kelas2a','kelas2b','kelas3a','kelas3b','kelas4a','kelas4b','kelas5a','kelas5b','persiapanImtas','persiapanKhotaman'];
            const listPra = ['praPtpt1','praPtpt2','praPtpt3','praPtpt4','praPtpt5'];
            const listPtpt = ['ptpt1','ptpt2','ptpt3','ptpt4','ptpt5','ptpt6'];

            function processJenjangGroup(keys, explicitBocil, explicitBocol) {
                const groupItems = keys.map(k => {
                    const tot = rawTotals[k];
                    const ind = indivStats[k];
                    const indTotal = ind.bocil + ind.bocol;
                    const r = indTotal > 0 ? (ind.bocil / indTotal) : (defaultRatios[k] || 0.5);
                    return { key: k, total: tot, ratio: r, bocil: 0, bocol: 0 };
                });

                const groupTotal = groupItems.reduce((acc, c) => acc + c.total, 0);

                let targetBocil;
                if (explicitBocil !== undefined && explicitBocol !== undefined) {
                    targetBocil = explicitBocil;
                } else {
                    let groupIndivBocil = 0, groupIndivTotal = 0;
                    keys.forEach(k => {
                        groupIndivBocil += indivStats[k].bocil;
                        groupIndivTotal += (indivStats[k].bocil + indivStats[k].bocol);
                    });
                    if (groupIndivTotal > 0) {
                        targetBocil = Math.round(groupTotal * (groupIndivBocil / groupIndivTotal));
                    } else {
                        const avgRatio = groupItems.reduce((acc, c) => acc + c.ratio, 0) / (groupItems.length || 1);
                        targetBocil = Math.round(groupTotal * avgRatio);
                    }
                }

                if (targetBocil > groupTotal) targetBocil = groupTotal;
                if (targetBocil < 0) targetBocil = 0;

                let currSum = 0;
                groupItems.forEach(c => {
                    if (c.total <= 0) {
                        c.bocil = 0;
                    } else {
                        c.bocil = Math.round(c.total * c.ratio);
                        if (c.bocil > c.total) c.bocil = c.total;
                        if (c.bocil < 0) c.bocil = 0;
                    }
                    currSum += c.bocil;
                });

                let diff = targetBocil - currSum;
                if (diff > 0) {
                    const canAdd = groupItems.filter(c => c.total > c.bocil).sort((a,b) => b.total - a.total);
                    let i = 0;
                    while (diff > 0 && canAdd.length > 0) {
                        canAdd[i % canAdd.length].bocil++;
                        diff--;
                        i++;
                    }
                } else if (diff < 0) {
                    const canSub = groupItems.filter(c => c.bocil > 0).sort((a,b) => a.total - b.total);
                    let i = 0;
                    while (diff < 0 && canSub.length > 0) {
                        canSub[i % canSub.length].bocil--;
                        diff++;
                        i++;
                    }
                }

                groupItems.forEach(c => {
                    c.bocol = c.total - c.bocil;
                });

                return groupItems;
            }

            const exp = explicitJenjangTotals || {};
            const itemsDasar = processJenjangGroup(listDasar, exp.dasarBocil, exp.dasarBocol);
            const itemsPra = processJenjangGroup(listPra, exp.praBocil, exp.praBocol);
            const itemsPtpt = processJenjangGroup(listPtpt, exp.ptptBocil, exp.ptptBocol);

            const mapResult = {};
            [...itemsDasar, ...itemsPra, ...itemsPtpt].forEach(item => {
                mapResult[item.key] = {
                    total: item.total,
                    bocil: item.bocil,
                    bocol: item.bocol
                };
            });

            const sumGroup = (items) => ({
                total: items.reduce((a, b) => a + b.total, 0),
                bocil: items.reduce((a, b) => a + b.bocil, 0),
                bocol: items.reduce((a, b) => a + b.bocol, 0),
            });

            const subDasar = sumGroup(itemsDasar);
            const subPra = sumGroup(itemsPra);
            const subPtpt = sumGroup(itemsPtpt);

            return {
                classes: mapResult,
                subDasar,
                subPra,
                subPtpt,
                grandTotal: subDasar.total + subPra.total + subPtpt.total,
                grandBocil: subDasar.bocil + subPra.bocil + subPtpt.bocil,
                grandBocol: subDasar.bocol + subPra.bocol + subPtpt.bocol
            };
        }

        // Master Data Lembaga TPQ Resmi per Kecamatan di Kota Surabaya (Dinamis dari Google Sheet tab Users)
        let tpqListByKecamatan = {
            "Pakal": [],
            "Jambangan": [],
            "Kenjeran": [
                "AL ISLAMI",
                "NABAUSSALAM",
                "MAMBA'U ASSYARIF",
                "MIFTAHUL JANNAH",
                "NUZULUL QURAN",
                "DARUL HAQ",
                "AT TIBYAN"
            ],
            "Rungkut": [],
            "Gunung Anyar": [],
            "Karang Pilang": [],
            "Asemrowo": [],
            "Benowo": []
        };

        // Master Data Kecamatan: Alamat Sekretariat & Sekretaris Korcam (Dapat tersinkron dari tab 'Kecamatan' Google Sheets)
        let dataKorcamByKecamatan = {
            "Kenjeran": {
                alamat: "Kedung Mangu IVC No. 5 Surabaya",
                sekretaris: "Abd. Rohman Wahid",
                kontak: "0831-6659-2390"
            },
            "Pakal": {
                alamat: "Sekretariat Korcam Pakal, Surabaya",
                sekretaris: "Sekretaris Korcam Pakal"
            },
            "Jambangan": {
                alamat: "Sekretariat Korcam Jambangan, Surabaya",
                sekretaris: "Sekretaris Korcam Jambangan"
            },
            "Rungkut": {
                alamat: "Sekretariat Korcam Rungkut, Surabaya",
                sekretaris: "Sekretaris Korcam Rungkut"
            },
            "Gunung Anyar": {
                alamat: "Sekretariat Korcam Gunung Anyar, Surabaya",
                sekretaris: "Sekretaris Korcam Gunung Anyar"
            },
            "Karang Pilang": {
                alamat: "Sekretariat Korcam Karang Pilang, Surabaya",
                sekretaris: "Sekretaris Korcam Karang Pilang"
            },
            "Asemrowo": {
                alamat: "Sekretariat Korcam Asemrowo, Surabaya",
                sekretaris: "Sekretaris Korcam Asemrowo"
            },
            "Benowo": {
                alamat: "Sekretariat Korcam Benowo, Surabaya",
                sekretaris: "Sekretaris Korcam Benowo"
            }
        };

        const LOCAL_STORAGE_KEY = 'qiraati_santri_data_surabaya_real';
        const AUTH_STORAGE_KEY = 'qiraati_auth_session_permanent';
        const LOCAL_STORAGE_SANTRI_KEY = 'qiraati_santri_list_real';
        const LOCAL_STORAGE_GURU_KEY = 'qiraati_guru_list_real';
        const LOCAL_STORAGE_KENAIKAN_KEY = 'qiraati_kenaikan_list_real';

        let globalSantri = [];
        let globalGuru = [];
        let globalKenaikan = [];
        let currentDataListType = 'santri';
        let globalMutasi = [];
        const LOCAL_STORAGE_MUTASI_KEY = 'qiraati_mutasi_list_real';
        let currentSantriStatusFilter = 'all';
let santriTablePage = 1;
let santriRowsPerPage = 50;
let lastSantriFilterKey = '';
        let currentUstadzahStatusFilter = 'all';
        let currentView = 'dashboard';

        // ================= SISTEM AUTO-REKAP BULANAN & ARSIP HISTORIS DASHBOARD =================
        const LOCAL_STORAGE_AUTOREKAP_HISTORY_KEY = 'qiraati_autorekap_history_v2';
        let currentDashboardPeriode = 'live'; // 'live' atau 'YYYY-MM'
        let globalAutoRekapHistory = {};

        try {
            const savedHistory = localStorage.getItem(LOCAL_STORAGE_AUTOREKAP_HISTORY_KEY);
            if (savedHistory) globalAutoRekapHistory = JSON.parse(savedHistory);
        } catch(e) {
            console.error("Gagal membaca riwayat auto-rekap:", e);
            globalAutoRekapHistory = {};
        }

        const NAMA_BULAN_LENGKAP_INDO = [
            "Januari", "Februari", "Maret", "April", "Mei", "Juni",
            "Juli", "Agustus", "September", "Oktober", "November", "Desember"
        ];

        function getPeriodeBulanSekarangKey() {
            const now = new Date();
            return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        }

        function getLabelBulanTahunIndo(keyBulan) {
            if (!keyBulan || keyBulan === 'live') return 'Bulan Berjalan (Live)';
            const parts = keyBulan.split('-');
            if (parts.length >= 2) {
                const yr = parts[0];
                const moIdx = parseInt(parts[1], 10) - 1;
                if (moIdx >= 0 && moIdx < 12) {
                    return `${NAMA_BULAN_LENGKAP_INDO[moIdx]} ${yr}`;
                }
            }
            return keyBulan;
        }

        // Generate data rekap 24 kelas per TPQ dari daftar santri & guru aktif terkini
        function generateLiveAutoRekap(bulanKey) {
            const rekapFields = ['kelas1a','kelas1b','kelas1c','kelas2a','kelas2b','kelas3a','kelas3b','kelas4a','kelas4b','kelas5a','kelas5b','persiapanImtas','persiapanKhotaman','praPtpt1','praPtpt2','praPtpt3','praPtpt4','praPtpt5','ptpt1','ptpt2','ptpt3','ptpt4','ptpt5','ptpt6'];
            const byTpq = {};
            const bKey = bulanKey || getPeriodeBulanSekarangKey();

            // 1. Akumulasi santri aktif ke 24 kelas
            (Array.isArray(globalSantri) ? globalSantri : []).forEach(s => {
                if ((s.status || 'Aktif').toLowerCase() === 'nonaktif') return;

                const namaTpq = String(s.namaTpq || '').trim() || 'Tanpa Nama TPQ';
                const kec = String(s.kecamatan || '').trim();
                if (!byTpq[namaTpq]) {
                    const row = { id: 'AUTO_' + namaTpq, namaTpq: namaTpq, kecamatan: kec, bulan: bKey, jumlahGuru: 0, total: 0 };
                    rekapFields.forEach(f => row[f] = 0);
                    byTpq[namaTpq] = row;
                }
                const row = byTpq[namaTpq];
                row.total++;
                const fld = (typeof deteksiKategoriKelasSantri === 'function') ? deteksiKategoriKelasSantri(s) : null;
                if (fld && row[fld] !== undefined) row[fld]++;
            });

            // 2. Akumulasi guru aktif per TPQ
            (Array.isArray(globalGuru) ? globalGuru : []).forEach(g => {
                if ((g.status || 'Aktif').toLowerCase() === 'nonaktif') return;

                const namaTpq = String(g.namaTpq || '').trim() || 'Tanpa Nama TPQ';
                const kec = String(g.kecamatan || '').trim();
                if (!byTpq[namaTpq]) {
                    const row = { id: 'AUTO_' + namaTpq, namaTpq: namaTpq, kecamatan: kec, bulan: bKey, jumlahGuru: 0, total: 0 };
                    rekapFields.forEach(f => row[f] = 0);
                    byTpq[namaTpq] = row;
                }
                byTpq[namaTpq].jumlahGuru++;
            });

            // 3. Hitung demografi Bocil vs Bocol
            let countUsia = {
                'dasar_bocil': { l: 0, p: 0, total: 0, label: 'TPQ Pagi - Bocil',  rentang: '3 â€“ 5 Tahun', color: '#f59e0b' },
                'dasar_bocol': { l: 0, p: 0, total: 0, label: 'TPQ Pagi - Bocol',  rentang: '> 5 Tahun', color: '#ea580c' },
                'pra_bocil':   { l: 0, p: 0, total: 0, label: 'PRA PTPT - Bocil',  rentang: '3 â€“ 9 Tahun', color: '#0ea5e9' },
                'pra_bocol':   { l: 0, p: 0, total: 0, label: 'PRA PTPT - Bocol',  rentang: '> 9 Tahun', color: '#2563eb' },
                'ptpt_bocil':  { l: 0, p: 0, total: 0, label: 'PTPT - Bocil',      rentang: '3 â€“ 9 Tahun', color: '#a855f7' },
                'ptpt_bocol':  { l: 0, p: 0, total: 0, label: 'PTPT - Bocol',      rentang: '> 9 Tahun', color: '#7c3aed' }
            };

            (Array.isArray(globalSantri) ? globalSantri : []).forEach(s => {
                if ((s.status || 'Aktif').toLowerCase() === 'nonaktif') return;
                const info = getKategoriBocilBocol(s);
                const key = `${info.jenjang}_${info.status}`;
                if (countUsia[key]) {
                    const isPerempuan = String(s.gender || s.jenisKelamin || '').toUpperCase().startsWith('P');
                    if (isPerempuan) countUsia[key].p++;
                    else countUsia[key].l++;
                    countUsia[key].total++;
                }
            });

            return {
                bulan: bKey,
                rows: Object.values(byTpq),
                countUsia: countUsia,
                totalSantri: Object.values(byTpq).reduce((acc, r) => acc + (r.total || 0), 0),
                totalGuru: Object.values(byTpq).reduce((acc, r) => acc + (r.jumlahGuru || 0), 0),
                totalTpq: Object.keys(byTpq).length,
                updatedAt: new Date().toISOString()
            };
        }

        // Pemeriksaan otomatis awal bulan untuk membekukan rekap bulan lalu
        function checkAndSyncMonthlyArchives() {
            const now = new Date();
            const currentKey = getPeriodeBulanSekarangKey();

            // Hitung kunci bulan lalu (1 bulan ke belakang)
            const prevDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
            const prevKey = `${prevDate.getFullYear()}-${String(prevDate.getMonth() + 1).padStart(2, '0')}`;

            // PENTING: Jangan membuat data tiruan untuk bulan lalu (misal September).
            // Bulan lalu hanya memiliki data jika memang tercatat di Google Sheets atau dari hasil cutoff tersimpan.
            // Bersihkan data tiruan bulan lalu jika sebelumnya pernah tersimpan secara sintetis:
            if (globalAutoRekapHistory[prevKey] && !globalAutoRekapHistory[prevKey].isRealData) {
                delete globalAutoRekapHistory[prevKey];
            }
            if (globalAutoRekapHistory['2026-09'] && !globalAutoRekapHistory['2026-09'].isRealData) {
                delete globalAutoRekapHistory['2026-09'];
            }

            // Sync juga data dari Google Sheets jika mengandung properti item.bulan
            if (Array.isArray(globalData)) {
                const sheetByBulan = {};
                globalData.forEach(item => {
                    if (item.bulan && String(item.bulan).trim()) {
                        const b = String(item.bulan).trim();
                        if (!sheetByBulan[b]) sheetByBulan[b] = [];
                        sheetByBulan[b].push(item);
                    }
                });
                Object.keys(sheetByBulan).forEach(b => {
                    if (!globalAutoRekapHistory[b]) {
                        globalAutoRekapHistory[b] = {
                            bulan: b,
                            rows: sheetByBulan[b],
                            totalSantri: sheetByBulan[b].reduce((acc, r) => acc + (r.total || 0), 0),
                            totalGuru: sheetByBulan[b].reduce((acc, r) => acc + (r.jumlahGuru || 0), 0),
                            totalTpq: sheetByBulan[b].length,
                            updatedAt: new Date().toISOString()
                        };
                    }
                });
            }

            try {
                localStorage.setItem(LOCAL_STORAGE_AUTOREKAP_HISTORY_KEY, JSON.stringify(globalAutoRekapHistory));
            } catch(e) {}

            populatePeriodeDashboardDropdown();
        }

        function populatePeriodeDashboardDropdown() {
            const select = document.getElementById('selectPeriodeDashboard');
            if (!select) return;

            const currentKey = getPeriodeBulanSekarangKey();
            const currentLabel = getLabelBulanTahunIndo(currentKey);

            const periodSet = new Set(Object.keys(globalAutoRekapHistory));
            periodSet.add(currentKey);

            const sortedPeriods = Array.from(periodSet).filter(p => p && p.includes('-')).sort().reverse();

            let optionsHtml = `<option value="live" ${currentDashboardPeriode === 'live' ? 'selected' : ''}>${currentLabel} (Live)</option>`;

            // Pastikan bulan lalu (misal September 2026) selalu tersedia sebagai pilihan periode
            const nowForDrop = new Date();
            const prevMoDate = new Date(nowForDrop.getFullYear(), nowForDrop.getMonth() - 1, 1);
            const prevMoKey = `${prevMoDate.getFullYear()}-${String(prevMoDate.getMonth() + 1).padStart(2, '0')}`;
            periodSet.add(prevMoKey);

            sortedPeriods.forEach(p => {
                if (p === currentKey) return;
                const label = getLabelBulanTahunIndo(p);
                const isSelected = (currentDashboardPeriode === p) ? 'selected' : '';
                optionsHtml += `<option value="${p}" ${isSelected}>${label} (Arsip)</option>`;
            });

            select.innerHTML = optionsHtml;
        }

        function onPeriodeDashboardChange() {
            const select = document.getElementById('selectPeriodeDashboard');
            if (!select) return;
            currentDashboardPeriode = select.value;
            renderStatistik();
        }

        let cachedUsersList = [];
        try {
            const savedS = localStorage.getItem(LOCAL_STORAGE_SANTRI_KEY);
            if (savedS) globalSantri = JSON.parse(savedS);
            const savedG = localStorage.getItem(LOCAL_STORAGE_GURU_KEY);
            if (savedG) globalGuru = JSON.parse(savedG);
            const savedK = localStorage.getItem(LOCAL_STORAGE_KENAIKAN_KEY);
            if (savedK) globalKenaikan = JSON.parse(savedK);
            const savedM = localStorage.getItem(LOCAL_STORAGE_MUTASI_KEY);
            if (savedM) globalMutasi = JSON.parse(savedM);
        } catch(e) {}

        // ================= SIDEBAR NAVIGATION SYSTEM =================
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const icon = document.getElementById('iconToggleSidebar');
            sidebar.classList.toggle('sidebar-collapsed');
            if (sidebar.classList.contains('sidebar-collapsed')) {
                icon.classList.remove('fa-chevron-left');
                icon.classList.add('fa-chevron-right');
                sidebar.style.width = '64px';
            } else {
                icon.classList.remove('fa-chevron-right');
                icon.classList.add('fa-chevron-left');
                sidebar.style.width = '256px';
            }
        }

        function toggleSidebarMobile(open) {
            const sidebar = document.getElementById('sidebar');
            const backdrop = document.getElementById('sidebarBackdrop');
            if (open) {
                sidebar.classList.add('translate-x-0');
                sidebar.classList.remove('-translate-x-full');
                backdrop.classList.remove('hidden');
            } else {
                sidebar.classList.remove('translate-x-0');
                sidebar.classList.add('-translate-x-full');
                backdrop.classList.add('hidden');
            }
        }

        function toggleAccordion(groupName) {
            const sub = document.getElementById('acc-sub-' + groupName);
            const icon = document.getElementById('acc-icon-' + groupName);
            if (!sub) return;
            if (sub.style.display === 'none') {
                sub.style.display = 'block';
                if (icon) icon.style.transform = 'rotate(0deg)';
            } else {
                sub.style.display = 'none';
                if (icon) icon.style.transform = 'rotate(-90deg)';
            }
        }

        const VIEW_META = {
            'dashboard':        { category: 'Dashboard',  title: 'Statistik Eksekutif',    parentGroup: null },
            'santri-daftar':    { category: 'Santri',     title: 'Daftar Santri',          parentGroup: 'santri' },
            'santri-input':     { category: 'Santri',     title: 'Input Santri Baru',      parentGroup: 'santri' },
            'santri-kenaikan':  { category: 'Santri',     title: 'Kenaikan Jilid',         parentGroup: 'santri' },
            'santri-mutasi':    { category: 'Santri',     title: 'Mutasi Santri',          parentGroup: 'santri' },
            'ustadzah-daftar':  { category: 'Guru', title: 'Daftar Guru',      parentGroup: 'ustadzah' },
            'ustadzah-input':   { category: 'Guru', title: 'Input Guru Baru',  parentGroup: 'ustadzah' },
            'ustadzah-mutasi':  { category: 'Guru', title: 'Mutasi Guru',      parentGroup: 'ustadzah' },
            'rekap-kecamatan':  { category: 'Laporan',    title: 'Rekap Kecamatan',        parentGroup: 'rekap' },
            'rekap-bulanan':    { category: 'Laporan',    title: 'Rekap Bulanan',          parentGroup: 'rekap' },
            'login':            { category: 'Akun',       title: 'Login',                  parentGroup: null },
        };

        // Kontrol tampilan UI: Tampilan Awal Publik vs Sidebar EMIS (Hanya muncul saat login)
        function updateAuthUIState() {
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const sidebar = document.getElementById('sidebar');
            const topPublic = document.getElementById('topbarPublic');
            const topPublicM = document.getElementById('topbarPublicMobile');
            const topAuth = document.getElementById('topbarAuth');

            if (rawUser) {
                // SUDAH LOGIN: Tampilkan Sidebar EMIS & Topbar Mode Login
                if (sidebar) sidebar.classList.remove('hidden');
                if (topPublic) topPublic.classList.add('hidden');
                if (topPublicM) topPublicM.classList.add('hidden');
                if (topAuth) topAuth.classList.remove('hidden');
                updateSidebarUserBox();
            } else {
                // BELUM LOGIN: Sembunyikan Sidebar EMIS & Tampilkan Tampilan Awal Publik
                if (sidebar) sidebar.classList.add('hidden');
                if (topPublic) topPublic.classList.remove('hidden');
                if (topPublicM) topPublicM.classList.remove('hidden');
                if (topAuth) topAuth.classList.add('hidden');
            }
        }

        // Navigasi Tampilan Awal Publik: Statistik, Rekap Kecamatan, Login
        function switchPublicTab(tab) {
            const btnStat = document.getElementById('navPublicStatistik');
            const btnRekap = document.getElementById('navPublicRekap');
            const mStat = document.getElementById('navPublicMobileStatistik');
            const mRekap = document.getElementById('navPublicMobileRekap');
            const mLogin = document.getElementById('navPublicMobileLogin');

            const inactiveDeskClass = "px-4 lg:px-5 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center gap-2 text-slate-300 hover:text-white hover:bg-slate-700/50 cursor-pointer";
            const activeDeskClass = "px-4 lg:px-5 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center gap-2 text-white bg-amber-600 shadow-md cursor-pointer";
            const inactiveMobClass = "px-3 py-1.5 rounded-lg text-slate-300 flex items-center gap-1.5 hover:text-white cursor-pointer";
            const activeMobClass = "px-3 py-1.5 rounded-lg text-amber-400 font-extrabold flex items-center gap-1.5 bg-slate-800 border border-slate-700 cursor-pointer";

            [btnStat, btnRekap].forEach(b => { if (b) b.className = inactiveDeskClass; });
            [mStat, mRekap, mLogin].forEach(m => { if (m) m.className = inactiveMobClass; });

            if (tab === 'statistik') {
                if (btnStat) btnStat.className = activeDeskClass;
                if (mStat) mStat.className = activeMobClass;
                switchView('dashboard');
            } else if (tab === 'rekap-kecamatan') {
                if (btnRekap) btnRekap.className = activeDeskClass;
                if (mRekap) mRekap.className = activeMobClass;
                switchView('rekap-kecamatan');
            } else if (tab === 'login' || tab === 'input') {
                if (mLogin) mLogin.className = activeMobClass;
                switchView('login');
            }
        }

        function switchView(viewName) {
            // Hide all views
            document.querySelectorAll('[id^="view-"]').forEach(el => {
                if (el.id.startsWith('view-')) el.classList.add('hidden');
            });

            // Show target view
            const target = document.getElementById('view-' + viewName);
            if (target) target.classList.remove('hidden');

            // Update topbar
            const meta = VIEW_META[viewName] || { category: 'Halaman', title: viewName };
            const topCat = document.getElementById('topbarCategory');
            const topTitle = document.getElementById('topbarTitle');
            if (topCat) topCat.textContent = meta.category;
            if (topTitle) topTitle.textContent = meta.title;

            // Update active nav button
            document.querySelectorAll('.sidebar-nav-btn, .sidebar-sub-btn').forEach(btn => {
                btn.classList.remove('nav-active');
            });
            const activeBtn = document.getElementById('nav-btn-' + viewName);
            if (activeBtn) activeBtn.classList.add('nav-active');

            // Auto-open parent accordion if needed
            if (meta.parentGroup) {
                const sub = document.getElementById('acc-sub-' + meta.parentGroup);
                const icon = document.getElementById('acc-icon-' + meta.parentGroup);
                if (sub) sub.style.display = 'block';
                if (icon) icon.style.transform = 'rotate(0deg)';
            }

            // Close mobile sidebar on view switch
            toggleSidebarMobile(false);

            // Trigger renders for specific views
            currentView = viewName;
            if (viewName === 'dashboard') renderStatistik();
            else if (viewName === 'santri-daftar') renderDataListTables();
            else if (viewName === 'ustadzah-daftar') renderDataListTables();
            else if (viewName === 'santri-kenaikan') { populateSantriDropdownKenaikan(); renderRiwayatKenaikan(); }
            else if (viewName === 'santri-mutasi') renderMutasiSantriView();
            else if (viewName === 'ustadzah-mutasi') renderMutasiUstadzahView();
            else if (viewName === 'rekap-kecamatan') renderRekapKecamatan();
            else if (viewName === 'rekap-bulanan') renderRekapBulanan();
            else if (viewName === 'login') { /* login form is static */ }
        }

        function updateSidebarUserBox() {
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const sName = document.getElementById('sidebarUserName');
            const sRole = document.getElementById('sidebarUserRole');
            const sBtn = document.getElementById('sidebarBtnAuth');
            const tName = document.getElementById('topbarUserName');
            const tRole = document.getElementById('topbarUserRole');
            const tPill = document.getElementById('topbarUserPill');

            if (rawUser) {
                try {
                    const user = JSON.parse(rawUser);
                    const userRoleLower = (user.role || '').toLowerCase();
                    const isAdmin = userRoleLower === 'admin';
                    const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
                    const userNama = user.nama || user.username;
                    const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
                    const userKec = standardKecList.find(k => k.toLowerCase() === (user.kecamatan || '').toLowerCase()) || user.kecamatan || '';

                    let roleLabel = 'Operator Lembaga';
                    let roleBadge = 'Lembaga';
                    if (isAdmin) { roleLabel = 'Admin Cabang Surabaya'; roleBadge = 'Admin'; }
                    else if (isKorcam) { roleLabel = 'Koordinator Kec. ' + userKec; roleBadge = 'Korcam'; }

                    if (sName) sName.textContent = userNama;
                    if (sRole) sRole.textContent = roleLabel;
                    if (sBtn) {
                        sBtn.title = 'Logout';
                        sBtn.setAttribute('onclick', 'handleLogout()');
                        sBtn.innerHTML = '<i class="fa-solid fa-right-from-bracket text-xs"></i>';
                    }
                    if (tName) tName.textContent = userNama;
                    if (tRole) tRole.textContent = roleBadge;
                    if (tPill) tPill.classList.remove('hidden');
                    return;
                } catch(e) {}
            }

            // Not logged in
            if (sName) sName.textContent = 'Tamu / Belum Login';
            if (sRole) sRole.textContent = 'Publik';
            if (sBtn) {
                sBtn.title = 'Login';
                sBtn.setAttribute('onclick', "switchView('login')");
                sBtn.innerHTML = '<i class="fa-solid fa-right-to-bracket text-xs"></i>';
            }
            if (tName) tName.textContent = 'Tamu';
            if (tRole) tRole.textContent = 'Public';
            if (tPill) tPill.classList.add('hidden');
        }

        // ================= MUTASI FUNCTIONS =================
        function renderMutasiSantriView() {
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            if (!loggedUser) return;
            const userRoleLower = (loggedUser.role || '').toLowerCase();
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const userNama = loggedUser.nama || loggedUser.username;
            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            const userKec = standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan || '').toLowerCase()) || loggedUser.kecamatan || '';

            // Show/hide sections based on role
            const lembagaSec = document.getElementById('mutasiSantriLembagaSection');
            const adminSec = document.getElementById('mutasiSantriAdminSection');
            if (lembagaSec) lembagaSec.classList.toggle('hidden', !isLembaga);
            if (adminSec) adminSec.classList.toggle('hidden', isLembaga);

            // Populate santri dropdown for lembaga
            if (isLembaga) {
                const sel = document.getElementById('mutasiSantriSelect');
                if (sel) {
                    const mySantri = globalSantri.filter(s => (s.namaTpq || '').trim().toLowerCase() === userNama.trim().toLowerCase() && (s.status || 'Aktif').toLowerCase() !== 'nonaktif');
                    sel.innerHTML = '<option value="" disabled selected>-- Pilih Santri --</option>' + mySantri.map(s => `<option value="${s.id || s.nis}">${s.nama} (${s.jilidSekarang || s.kelasAwal || '-'})</option>`).join('');
                }
                // Populate target kecamatan dropdown
                const kecSel = document.getElementById('mutasiSantriTujuanKec');
                if (kecSel && kecSel.options.length <= 1) {
                    kecSel.innerHTML = '<option value="" disabled selected>-- Pilih Kecamatan Tujuan --</option>' + standardKecList.map(k => `<option value="${k}">${k}</option>`).join('');
                }

                // Render lembaga history table
                const tbody = document.getElementById('tbodyMutasiSantriLembaga');
                if (tbody) {
                    const myMutasi = globalMutasi.filter(m => m.tipe === 'santri' && ((m.asalTpq || '').trim().toLowerCase() === userNama.trim().toLowerCase() || (m.tujuanTpq || '').trim().toLowerCase() === userNama.trim().toLowerCase()));
                    if (myMutasi.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="8" class="text-center py-6 text-slate-400 italic">Belum ada riwayat mutasi santri.</td></tr>';
                    } else {
                        tbody.innerHTML = myMutasi.map((m, i) => `<tr class="hover:bg-slate-50"><td class="py-2.5 px-3 text-center text-slate-400 font-bold">${i+1}</td><td class="py-2.5 px-4 font-bold text-slate-900">${m.namaSantri || '-'}</td><td class="py-2.5 px-4 text-slate-600">${m.asalTpq || '-'}</td><td class="py-2.5 px-4 text-slate-600">${m.tujuanTpq || '-'}</td><td class="py-2.5 px-3 text-center text-slate-500">${m.tanggal || '-'}</td><td class="py-2.5 px-4 text-slate-500 text-xs">${m.alasan || '-'}</td><td class="py-2.5 px-3 text-center"><span class="px-2 py-0.5 rounded text-[10px] font-black ${m.status === 'Disetujui' ? 'bg-emerald-100 text-emerald-700' : m.status === 'Ditolak' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'}">${m.status || 'Menunggu'}</span></td><td class="py-2.5 px-3 text-center text-slate-400 text-xs">${m.catatanAdmin || '-'}</td></tr>`).join('');
                    }
                }
            }

            // Admin/Korcam: show pending + selesai tables
            if (isAdmin || isKorcam) {
                let mutasiList = globalMutasi.filter(m => m.tipe === 'santri');
                if (isKorcam) mutasiList = mutasiList.filter(m => (m.asalKec || '').toLowerCase() === userKec.toLowerCase() || (m.tujuanKec || '').toLowerCase() === userKec.toLowerCase());

                const pending = mutasiList.filter(m => (m.status || 'Menunggu') === 'Menunggu');
                const selesai = mutasiList.filter(m => m.status === 'Disetujui' || m.status === 'Ditolak');

                const badge = document.getElementById('badgePendingMutasiSantri');
                if (badge) {
                    if (pending.length > 0) {
                        badge.textContent = pending.length;
                        badge.classList.remove('hidden');
                    } else {
                        badge.classList.add('hidden');
                    }
                }

                const tbodyPending = document.getElementById('tbodyMutasiSantriPending');
                if (tbodyPending) {
                    if (pending.length === 0) {
                        tbodyPending.innerHTML = '<tr><td colspan="8" class="text-center py-6 text-slate-400 italic">Tidak ada pengajuan mutasi santri yang menunggu.</td></tr>';
                    } else {
                        tbodyPending.innerHTML = pending.map((m, i) => `<tr class="hover:bg-slate-50"><td class="py-2.5 px-3 text-center text-slate-400 font-bold">${i+1}</td><td class="py-2.5 px-4 font-bold text-slate-900">${m.namaSantri || '-'}</td><td class="py-2.5 px-4 text-slate-600">${m.asalTpq || '-'} (${m.asalKec || '-'})</td><td class="py-2.5 px-4 text-slate-600">${m.tujuanTpq || '-'} (${m.tujuanKec || '-'})</td><td class="py-2.5 px-3 text-center text-slate-500">${m.tanggal || '-'}</td><td class="py-2.5 px-4 text-slate-500 text-xs">${m.alasan || '-'}</td><td class="py-2.5 px-3 text-center"><span class="px-2 py-0.5 rounded text-[10px] font-black bg-amber-100 text-amber-700">Menunggu</span></td><td class="py-2.5 px-3 text-center"><div class="flex items-center justify-center gap-1"><button onclick="handleProsesMutasi('${m.id}','Disetujui')" class="px-2 py-1 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold"><i class="fa-solid fa-check"></i> Setujui</button><button onclick="handleProsesMutasi('${m.id}','Ditolak')" class="px-2 py-1 bg-rose-500 hover:bg-rose-600 text-white rounded-lg text-xs font-bold"><i class="fa-solid fa-xmark"></i> Tolak</button></div></td></tr>`).join('');
                    }
                }

                const tbodySelesai = document.getElementById('tbodyMutasiSantriSelesai');
                if (tbodySelesai) {
                    if (selesai.length === 0) {
                        tbodySelesai.innerHTML = '<tr><td colspan="8" class="text-center py-6 text-slate-400 italic">Belum ada mutasi santri yang diproses.</td></tr>';
                    } else {
                        tbodySelesai.innerHTML = selesai.map((m, i) => `<tr class="hover:bg-slate-50"><td class="py-2.5 px-3 text-center text-slate-400 font-bold">${i+1}</td><td class="py-2.5 px-4 font-bold text-slate-900">${m.namaSantri || '-'}</td><td class="py-2.5 px-4 text-slate-600">${m.asalTpq || '-'}</td><td class="py-2.5 px-4 text-slate-600">${m.tujuanTpq || '-'}</td><td class="py-2.5 px-3 text-center text-slate-500">${m.tanggal || '-'}</td><td class="py-2.5 px-4 text-slate-500 text-xs">${m.alasan || '-'}</td><td class="py-2.5 px-3 text-center"><span class="px-2 py-0.5 rounded text-[10px] font-black ${m.status === 'Disetujui' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}">${m.status}</span></td><td class="py-2.5 px-3 text-center text-slate-400 text-xs">${m.catatanAdmin || '-'}</td></tr>`).join('');
                    }
                }
            }
        }

        function renderMutasiUstadzahView() {
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            if (!loggedUser) return;
            const userRoleLower = (loggedUser.role || '').toLowerCase();
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const userNama = loggedUser.nama || loggedUser.username;
            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            const userKec = standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan || '').toLowerCase()) || loggedUser.kecamatan || '';

            const lembagaSec = document.getElementById('mutasiUstadzahLembagaSection');
            const adminSec = document.getElementById('mutasiUstadzahAdminSection');
            if (lembagaSec) lembagaSec.classList.toggle('hidden', !isLembaga);
            if (adminSec) adminSec.classList.toggle('hidden', isLembaga);

            if (isLembaga) {
                const sel = document.getElementById('mutasiUstadzahSelect');
                if (sel) {
                    const myGuru = globalGuru.filter(g => (g.namaTpq || '').trim().toLowerCase() === userNama.trim().toLowerCase() && (g.status || 'Aktif').toLowerCase() !== 'nonaktif');
                    sel.innerHTML = '<option value="" disabled selected>-- Pilih Guru --</option>' + myGuru.map(g => `<option value="${g.id || g.idGuru}">${g.nama}</option>`).join('');
                }
                const kecSel = document.getElementById('mutasiUstadzahTujuanKec');
                if (kecSel && kecSel.options.length <= 1) {
                    kecSel.innerHTML = '<option value="" disabled selected>-- Pilih Kecamatan Tujuan --</option>' + standardKecList.map(k => `<option value="${k}">${k}</option>`).join('');
                }

                const tbody = document.getElementById('tbodyMutasiUstadzahLembaga');
                if (tbody) {
                    const myMutasi = globalMutasi.filter(m => m.tipe === 'guru' && ((m.asalTpq || '').trim().toLowerCase() === userNama.trim().toLowerCase() || (m.tujuanTpq || '').trim().toLowerCase() === userNama.trim().toLowerCase()));
                    if (myMutasi.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="8" class="text-center py-6 text-slate-400 italic">Belum ada riwayat mutasi guru.</td></tr>';
                    } else {
                        tbody.innerHTML = myMutasi.map((m, i) => `<tr class="hover:bg-slate-50"><td class="py-2.5 px-3 text-center text-slate-400 font-bold">${i+1}</td><td class="py-2.5 px-4 font-bold text-slate-900">${m.namaGuru || m.namaSantri || '-'}</td><td class="py-2.5 px-4 text-slate-600">${m.asalTpq || '-'}</td><td class="py-2.5 px-4 text-slate-600">${m.tujuanTpq || '-'}</td><td class="py-2.5 px-3 text-center text-slate-500">${m.tanggal || '-'}</td><td class="py-2.5 px-4 text-slate-500 text-xs">${m.alasan || '-'}</td><td class="py-2.5 px-3 text-center"><span class="px-2 py-0.5 rounded text-[10px] font-black ${m.status === 'Disetujui' ? 'bg-emerald-100 text-emerald-700' : m.status === 'Ditolak' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'}">${m.status || 'Menunggu'}</span></td><td class="py-2.5 px-3 text-center text-slate-400 text-xs">${m.catatanAdmin || '-'}</td></tr>`).join('');
                    }
                }
            }

            if (isAdmin || isKorcam) {
                let mutasiList = globalMutasi.filter(m => m.tipe === 'guru');
                if (isKorcam) mutasiList = mutasiList.filter(m => (m.asalKec || '').toLowerCase() === userKec.toLowerCase() || (m.tujuanKec || '').toLowerCase() === userKec.toLowerCase());

                const pending = mutasiList.filter(m => (m.status || 'Menunggu') === 'Menunggu');
                const selesai = mutasiList.filter(m => m.status === 'Disetujui' || m.status === 'Ditolak');

                const badge = document.getElementById('badgePendingMutasiUstadzah');
                if (badge) {
                    if (pending.length > 0) { badge.textContent = pending.length; badge.classList.remove('hidden'); }
                    else { badge.classList.add('hidden'); }
                }

                const tbodyPending = document.getElementById('tbodyMutasiUstadzahPending');
                if (tbodyPending) {
                    if (pending.length === 0) {
                        tbodyPending.innerHTML = '<tr><td colspan="8" class="text-center py-6 text-slate-400 italic">Tidak ada pengajuan mutasi guru yang menunggu.</td></tr>';
                    } else {
                        tbodyPending.innerHTML = pending.map((m, i) => `<tr class="hover:bg-slate-50"><td class="py-2.5 px-3 text-center text-slate-400 font-bold">${i+1}</td><td class="py-2.5 px-4 font-bold text-slate-900">${m.namaGuru || m.namaSantri || '-'}</td><td class="py-2.5 px-4 text-slate-600">${m.asalTpq || '-'} (${m.asalKec || '-'})</td><td class="py-2.5 px-4 text-slate-600">${m.tujuanTpq || '-'} (${m.tujuanKec || '-'})</td><td class="py-2.5 px-3 text-center text-slate-500">${m.tanggal || '-'}</td><td class="py-2.5 px-4 text-slate-500 text-xs">${m.alasan || '-'}</td><td class="py-2.5 px-3 text-center"><span class="px-2 py-0.5 rounded text-[10px] font-black bg-amber-100 text-amber-700">Menunggu</span></td><td class="py-2.5 px-3 text-center"><div class="flex items-center justify-center gap-1"><button onclick="handleProsesMutasi('${m.id}','Disetujui')" class="px-2 py-1 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold"><i class="fa-solid fa-check"></i> Setujui</button><button onclick="handleProsesMutasi('${m.id}','Ditolak')" class="px-2 py-1 bg-rose-500 hover:bg-rose-600 text-white rounded-lg text-xs font-bold"><i class="fa-solid fa-xmark"></i> Tolak</button></div></td></tr>`).join('');
                    }
                }

                const tbodySelesai = document.getElementById('tbodyMutasiUstadzahSelesai');
                if (tbodySelesai) {
                    if (selesai.length === 0) {
                        tbodySelesai.innerHTML = '<tr><td colspan="8" class="text-center py-6 text-slate-400 italic">Belum ada mutasi guru yang diproses.</td></tr>';
                    } else {
                        tbodySelesai.innerHTML = selesai.map((m, i) => `<tr class="hover:bg-slate-50"><td class="py-2.5 px-3 text-center text-slate-400 font-bold">${i+1}</td><td class="py-2.5 px-4 font-bold text-slate-900">${m.namaGuru || m.namaSantri || '-'}</td><td class="py-2.5 px-4 text-slate-600">${m.asalTpq || '-'}</td><td class="py-2.5 px-4 text-slate-600">${m.tujuanTpq || '-'}</td><td class="py-2.5 px-3 text-center text-slate-500">${m.tanggal || '-'}</td><td class="py-2.5 px-4 text-slate-500 text-xs">${m.alasan || '-'}</td><td class="py-2.5 px-3 text-center"><span class="px-2 py-0.5 rounded text-[10px] font-black ${m.status === 'Disetujui' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}">${m.status}</span></td><td class="py-2.5 px-3 text-center text-slate-400 text-xs">${m.catatanAdmin || '-'}</td></tr>`).join('');
                    }
                }
            }
        }

        function onMutasiSantriKecChange() {
            const kecVal = document.getElementById('mutasiSantriTujuanKec').value;
            const tpqSel = document.getElementById('mutasiSantriTujuanTpq');
            if (!tpqSel || !kecVal) return;
            const list = tpqListByKecamatan[kecVal] || [];
            if (list.length > 0) {
                tpqSel.innerHTML = '<option value="" disabled selected>-- Pilih TPQ Tujuan --</option>' + list.map(t => `<option value="${t}">${t}</option>`).join('');
                tpqSel.disabled = false;
            } else {
                tpqSel.innerHTML = '<option value="" disabled selected>-- Belum ada TPQ di kecamatan ini --</option>';
                tpqSel.disabled = true;
            }
        }

        function onMutasiUstadzahKecChange() {
            const kecVal = document.getElementById('mutasiUstadzahTujuanKec').value;
            const tpqSel = document.getElementById('mutasiUstadzahTujuanTpq');
            if (!tpqSel || !kecVal) return;
            const list = tpqListByKecamatan[kecVal] || [];
            if (list.length > 0) {
                tpqSel.innerHTML = '<option value="" disabled selected>-- Pilih TPQ Tujuan --</option>' + list.map(t => `<option value="${t}">${t}</option>`).join('');
                tpqSel.disabled = false;
            } else {
                tpqSel.innerHTML = '<option value="" disabled selected>-- Belum ada TPQ di kecamatan ini --</option>';
                tpqSel.disabled = true;
            }
        }

        async function handlePengajuanMutasiSantri(event) {
            event.preventDefault();
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            if (!loggedUser) { alert('Silakan login terlebih dahulu.'); return; }
            const userNama = loggedUser.nama || loggedUser.username;
            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            const userKec = standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan || '').toLowerCase()) || loggedUser.kecamatan || '';

            const santriId = document.getElementById('mutasiSantriSelect').value;
            const tujuanKec = document.getElementById('mutasiSantriTujuanKec').value;
            const tujuanTpq = document.getElementById('mutasiSantriTujuanTpq').value;
            const alasan = (document.getElementById('mutasiSantriAlasan') || {}).value || '';

            if (!santriId || !tujuanKec || !tujuanTpq) { alert('Lengkapi semua field mutasi santri.'); return; }

            const santri = globalSantri.find(s => (s.id && String(s.id) === String(santriId)) || (s.nis && String(s.nis) === String(santriId)));
            if (!santri) { alert('Santri tidak ditemukan.'); return; }

            const dataObj = {
                formType: 'pengajuanMutasi',
                id: 'MUT_S_' + Date.now(),
                tipe: 'santri',
                namaSantri: santri.nama,
                santriId: santriId,
                asalTpq: userNama,
                asalKec: userKec,
                tujuanTpq: tujuanTpq,
                tujuanKec: tujuanKec,
                alasan: alasan,
                tanggal: new Date().toISOString().split('T')[0],
                status: 'Menunggu',
                catatanAdmin: ''
            };

            globalMutasi.unshift(dataObj);
            try { localStorage.setItem(LOCAL_STORAGE_MUTASI_KEY, JSON.stringify(globalMutasi)); } catch(e) {}

            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    await fetch(GOOGLE_SCRIPT_WEB_APP_URL, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(dataObj) });
                } catch(e) { console.error('Gagal kirim mutasi santri:', e); }
            }

            alert('Pengajuan mutasi santri berhasil dikirim! Menunggu persetujuan admin.');
            event.target.reset();
            renderMutasiSantriView();
        }

        async function handlePengajuanMutasiUstadzah(event) {
            event.preventDefault();
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            if (!loggedUser) { alert('Silakan login terlebih dahulu.'); return; }
            const userNama = loggedUser.nama || loggedUser.username;
            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            const userKec = standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan || '').toLowerCase()) || loggedUser.kecamatan || '';

            const guruId = document.getElementById('mutasiUstadzahSelect').value;
            const tujuanKec = document.getElementById('mutasiUstadzahTujuanKec').value;
            const tujuanTpq = document.getElementById('mutasiUstadzahTujuanTpq').value;
            const alasan = (document.getElementById('mutasiUstadzahAlasan') || {}).value || '';

            if (!guruId || !tujuanKec || !tujuanTpq) { alert('Lengkapi semua field mutasi guru.'); return; }

            const guru = globalGuru.find(g => (g.id && String(g.id) === String(guruId)) || (g.idGuru && String(g.idGuru) === String(guruId)));
            if (!guru) { alert('Guru tidak ditemukan.'); return; }

            const dataObj = {
                formType: 'pengajuanMutasi',
                id: 'MUT_G_' + Date.now(),
                tipe: 'guru',
                namaGuru: guru.nama,
                namaSantri: guru.nama,
                guruId: guruId,
                asalTpq: userNama,
                asalKec: userKec,
                tujuanTpq: tujuanTpq,
                tujuanKec: tujuanKec,
                alasan: alasan,
                tanggal: new Date().toISOString().split('T')[0],
                status: 'Menunggu',
                catatanAdmin: ''
            };

            globalMutasi.unshift(dataObj);
            try { localStorage.setItem(LOCAL_STORAGE_MUTASI_KEY, JSON.stringify(globalMutasi)); } catch(e) {}

            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    await fetch(GOOGLE_SCRIPT_WEB_APP_URL, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(dataObj) });
                } catch(e) { console.error('Gagal kirim mutasi guru:', e); }
            }

            alert('Pengajuan mutasi guru berhasil dikirim! Menunggu persetujuan admin.');
            event.target.reset();
            renderMutasiUstadzahView();
        }

        async function handleProsesMutasi(idMutasi, statusBaru) {
            const catatan = prompt(`Catatan untuk ${statusBaru === 'Disetujui' ? 'persetujuan' : 'penolakan'} mutasi ini:`, '');
            if (catatan === null) return; // user cancelled

            const idx = globalMutasi.findIndex(m => m.id === idMutasi);
            if (idx === -1) { alert('Data mutasi tidak ditemukan.'); return; }

            globalMutasi[idx].status = statusBaru;
            globalMutasi[idx].catatanAdmin = catatan;
            try { localStorage.setItem(LOCAL_STORAGE_MUTASI_KEY, JSON.stringify(globalMutasi)); } catch(e) {}

            // If approved, also update the santri/guru namaTpq and kecamatan in local data
            if (statusBaru === 'Disetujui') {
                const m = globalMutasi[idx];
                if (m.tipe === 'santri') {
                    const s = globalSantri.find(x => (x.id && String(x.id) === String(m.santriId)) || (x.nis && String(x.nis) === String(m.santriId)));
                    if (s) { s.namaTpq = m.tujuanTpq; s.kecamatan = m.tujuanKec; }
                    try { localStorage.setItem(LOCAL_STORAGE_SANTRI_KEY, JSON.stringify(globalSantri)); } catch(e) {}
                } else {
                    const g = globalGuru.find(x => (x.id && String(x.id) === String(m.guruId)) || (x.idGuru && String(x.idGuru) === String(m.guruId)));
                    if (g) { g.namaTpq = m.tujuanTpq; g.kecamatan = m.tujuanKec; }
                    try { localStorage.setItem(LOCAL_STORAGE_GURU_KEY, JSON.stringify(globalGuru)); } catch(e) {}
                }
            }

            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    const postData = { formType: 'prosesMutasi', id: idMutasi, status: statusBaru, catatanAdmin: catatan };
                    await fetch(GOOGLE_SCRIPT_WEB_APP_URL, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(postData) });
                } catch(e) { console.error('Gagal proses mutasi:', e); }
            }

            alert(`Mutasi berhasil ${statusBaru === 'Disetujui' ? 'disetujui' : 'ditolak'}.`);
            renderMutasiSantriView();
            renderMutasiUstadzahView();
        }

        window.onload = function() {
            const now = new Date();
            const bulanInput = document.getElementById('bulan');
            if(bulanInput) {
                bulanInput.value = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
            }
            fetchSheetData();
            checkAndSyncMonthlyArchives();
            checkAuthSession();
            updateAuthUIState();
            renderRekapBulanan();
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            if (rawUser) {
                switchView('dashboard');
                // Auto cutoff previous month jika belum ada snapshotnya
                setTimeout(checkAutoMonthlyCutoff, 3000);
            } else {
                switchPublicTab('statistik');
            }
        };

        // Sinkronisasi data Lembaga TPQ dari seluruh sumber data
        function refreshAllTpqFromData() {
            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            standardKecList.forEach(k => {
                if (!Array.isArray(tpqListByKecamatan[k])) tpqListByKecamatan[k] = [];
            });

            // Dari globalSantri
            if (Array.isArray(globalSantri)) {
                globalSantri.forEach(s => {
                    if (s.kecamatan && s.namaTpq) {
                        const matched = standardKecList.find(k => k.toLowerCase() === (s.kecamatan || '').trim().toLowerCase()) || s.kecamatan;
                        if (tpqListByKecamatan[matched] && !tpqListByKecamatan[matched].includes(s.namaTpq.trim())) {
                            tpqListByKecamatan[matched].push(s.namaTpq.trim());
                        }
                    }
                });
            }

            // Dari globalGuru
            if (Array.isArray(globalGuru)) {
                globalGuru.forEach(g => {
                    if (g.kecamatan && g.namaTpq) {
                        const matched = standardKecList.find(k => k.toLowerCase() === (g.kecamatan || '').trim().toLowerCase()) || g.kecamatan;
                        if (tpqListByKecamatan[matched] && !tpqListByKecamatan[matched].includes(g.namaTpq.trim())) {
                            tpqListByKecamatan[matched].push(g.namaTpq.trim());
                        }
                    }
                });
            }

            // Dari cachedUsersList
            if (Array.isArray(cachedUsersList)) {
                cachedUsersList.forEach(u => {
                    if (u.kecamatan && (u.nama || u.username) && (u.role || '').toLowerCase() === 'lembaga') {
                        const matched = standardKecList.find(k => k.toLowerCase() === (u.kecamatan || '').trim().toLowerCase()) || u.kecamatan;
                        const tpqName = (u.nama || u.username).trim();
                        if (tpqListByKecamatan[matched] && !tpqListByKecamatan[matched].includes(tpqName)) {
                            tpqListByKecamatan[matched].push(tpqName);
                        }
                    }
                });
            }
        }

        function updateTpqDropdown(kecVal, tpqSelectId, defaultTpq) {
            refreshAllTpqFromData();
            const tpqSel = document.getElementById(tpqSelectId);
            if (!tpqSel) return;
            if (!kecVal) {
                tpqSel.innerHTML = '<option value="" disabled selected>-- Pilih Kecamatan Terlebih Dahulu --</option>';
                return;
            }
            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            const matchedKec = standardKecList.find(k => k.toLowerCase() === (kecVal || '').toLowerCase()) || kecVal;
            const list = tpqListByKecamatan[matchedKec] || [];

            if (list.length > 0) {
                tpqSel.innerHTML = '<option value="" disabled selected>-- Pilih Lembaga TPQ di Kec. ' + matchedKec + ' --</option>' +
                    list.map(t => `<option value="${t}">${t}</option>`).join('');
                if (defaultTpq && list.includes(defaultTpq)) {
                    tpqSel.value = defaultTpq;
                }
            } else {
                tpqSel.innerHTML = '<option value="" disabled selected>-- Belum ada TPQ di Kec. ' + matchedKec + ' --</option>';
            }
        }

        function onInputSantriKecamatanChange() {
            const kec = document.getElementById('kecamatanSantri').value;
            updateTpqDropdown(kec, 'namaTpqSantri');
        }

        function onInputGuruKecamatanChange() {
            const kec = document.getElementById('kecamatanUstadzah').value;
            updateTpqDropdown(kec, 'namaTpqUstadzah');
        }

        // ================= SISTEM AUTENTIKASI PENGGUNA (LOGIN INPUT DATA) =================
        function checkAuthSession() {
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            updateAuthUIState();
            refreshAllTpqFromData();

            if (rawUser) {
                try {
                    const user = JSON.parse(rawUser);
                    const userRoleLower = (user.role || '').toLowerCase();
                    const isAdmin = userRoleLower === 'admin';
                    const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
                    const isLembaga = !isAdmin && !isKorcam;
                    const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
                    const userKec = standardKecList.find(k => k.toLowerCase() === (user.kecamatan || '').toLowerCase()) || user.kecamatan || 'Kenjeran';
                    const userNama = user.nama || user.username;

                    function configureFormFields(kecId, tpqId, lockNoticeId, lockTextId) {
                        const kecEl = document.getElementById(kecId);
                        const tpqEl = document.getElementById(tpqId);
                        const lockEl = document.getElementById(lockNoticeId);
                        const lockTextEl = document.getElementById(lockTextId);

                        if (isLembaga) {
                            // AKUN LEMBAGA: Terkunci pada Lembaga & Kecamatan miliknya sendiri
                            if (lockEl) lockEl.classList.remove('hidden');
                            if (lockTextEl) lockTextEl.innerText = `Kecamatan dan Nama TPQ terkunci otomatis untuk ${userNama} (Kec. ${userKec}).`;
                            if (kecEl) {
                                kecEl.value = userKec;
                                kecEl.disabled = true;
                                kecEl.classList.add('bg-slate-100', 'cursor-not-allowed');
                                kecEl.classList.remove('bg-white');
                            }
                            if (tpqEl) {
                                tpqEl.innerHTML = `<option value="${userNama}" selected>${userNama}</option>`;
                                tpqEl.disabled = true;
                                tpqEl.classList.add('bg-slate-100', 'cursor-not-allowed');
                                tpqEl.classList.remove('bg-white');
                            }
                        } else if (isKorcam) {
                            // AKUN KECAMATAN: Terkunci di Kecamatannya saja, BISA MENENTUKAN LEMBAGA DI KECAMATANNYA
                            if (lockEl) lockEl.classList.remove('hidden');
                            if (lockTextEl) lockTextEl.innerText = `Akun Admin Kecamatan (${userKec}). Wilayah terkunci di Kec. ${userKec}. Silakan tentukan Lembaga TPQ tujuan.`;
                            if (kecEl) {
                                kecEl.value = userKec;
                                kecEl.disabled = true;
                                kecEl.classList.add('bg-slate-100', 'cursor-not-allowed');
                                kecEl.classList.remove('bg-white');
                            }
                            if (tpqEl) {
                                tpqEl.disabled = false;
                                tpqEl.classList.remove('bg-slate-100', 'cursor-not-allowed');
                                tpqEl.classList.add('bg-white');
                                const list = tpqListByKecamatan[userKec] || [];
                                if (list.length > 0) {
                                    tpqEl.innerHTML = `<option value="" disabled selected>-- Pilih Lembaga TPQ di Kec. ${userKec} --</option>` +
                                        list.map(t => `<option value="${t}">${t}</option>`).join('');
                                } else {
                                    tpqEl.innerHTML = `<option value="" disabled selected>-- Belum ada TPQ terdaftar di Kec. ${userKec} --</option>`;
                                }
                            }
                        } else {
                            // AKUN CABANG (ADMIN): BISA SEMUA LEMBAGA SE-SURABAYA (Bisa pilih Kecamatan & TPQ manapun)
                            if (lockEl) lockEl.classList.add('hidden');
                            if (kecEl) {
                                kecEl.disabled = false;
                                kecEl.classList.remove('bg-slate-100', 'cursor-not-allowed');
                                kecEl.classList.add('bg-white');
                            }
                            if (tpqEl) {
                                tpqEl.disabled = false;
                                tpqEl.classList.remove('bg-slate-100', 'cursor-not-allowed');
                                tpqEl.classList.add('bg-white');
                                const selectedKec = kecEl ? kecEl.value : '';
                                if (selectedKec) {
                                    updateTpqDropdown(selectedKec, tpqId);
                                } else {
                                    tpqEl.innerHTML = '<option value="" disabled selected>-- Pilih Kecamatan Terlebih Dahulu --</option>';
                                }
                            }
                        }
                    }

                    configureFormFields('kecamatanSantri', 'namaTpqSantri', 'lembagaLockNoticeSantri', 'lembagaLockTextSantri');
                    configureFormFields('kecamatanUstadzah', 'namaTpqUstadzah', 'lembagaLockNoticeUstadzah', 'lembagaLockTextUstadzah');

                    // Backward compatibility untuk elemen lama jika ada
                    const oldKec = document.getElementById('kecamatan');
                    const oldTpq = document.getElementById('namaTpq');
                    const oldLock = document.getElementById('lembagaLockNotice');
                    const oldLockText = document.getElementById('lembagaLockText');
                    if (oldKec && oldTpq) {
                        configureFormFields('kecamatan', 'namaTpq', 'lembagaLockNotice', 'lembagaLockText');
                    }

                    // Tampilkan section mutasi sesuai hak akses peran
                    const mutasiSantriLembaga = document.getElementById('mutasiSantriLembagaSection');
                    const mutasiSantriAdmin = document.getElementById('mutasiSantriAdminSection');
                    const mutasiUstadzahLembaga = document.getElementById('mutasiUstadzahLembagaSection');
                    const mutasiUstadzahAdmin = document.getElementById('mutasiUstadzahAdminSection');

                    if (mutasiSantriLembaga) mutasiSantriLembaga.classList.toggle('hidden', !isLembaga);
                    if (mutasiSantriAdmin) mutasiSantriAdmin.classList.toggle('hidden', isLembaga);
                    if (mutasiUstadzahLembaga) mutasiUstadzahLembaga.classList.toggle('hidden', !isLembaga);
                    if (mutasiUstadzahAdmin) mutasiUstadzahAdmin.classList.toggle('hidden', isLembaga);

                    return true;
                } catch(e) {
                    console.error("Gagal membaca sesi login:", e);
                }
            }
            return false;
        }

        function togglePasswordVisibility() {
            const pwdInput = document.getElementById('loginPassword');
            const icon = document.getElementById('iconTogglePassword');
            if (!pwdInput) return;

            if (pwdInput.type === 'password') {
                pwdInput.type = 'text';
                if (icon) {
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                }
            } else {
                pwdInput.type = 'password';
                if (icon) {
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            }
        }

        // Fungsi hashing SHA-256 (Web Crypto API) agar password tidak dikirim dalam bentuk plaintext
async function sha256Hex(text) {
    const encoder = new TextEncoder();
    const data = encoder.encode(text);
    const hash = await crypto.subtle.digest('SHA-256', data);
    const bytes = Array.from(new Uint8Array(hash));
    return bytes.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function handleLoginSubmit(event) {
            event.preventDefault();

            const uInput = document.getElementById('loginUsername');
            const pInput = document.getElementById('loginPassword');
            const btnSubmit = document.getElementById('btnLoginSubmit');
            const iconSubmit = document.getElementById('iconLoginSubmit');
            const errAlert = document.getElementById('authErrorAlert');
            const errMsg = document.getElementById('authErrorMessage');

            const username = uInput.value.trim();
            const password = pInput.value.trim();

            if (!username || !password) return;

            if (errAlert) errAlert.classList.add('hidden');
            btnSubmit.disabled = true;
            iconSubmit.className = "fa-solid fa-spinner fa-spin";

            const cleanUser = username.toLowerCase();

            // Login diverifikasi melalui Google Apps Script Web App.
            // Kredensial tidak disimpan di klien dan tidak ada hardcoded password.

            // Hash password sebelum dikirim (SHA-256) agar tidak berlalu dalam plaintext
            let passwordHash = '';
            try {
                passwordHash = await sha256Hex(password);
            } catch (e) {
                console.error("Gagal hash password:", e);
            }

            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    const url = `${GOOGLE_SCRIPT_WEB_APP_URL}?action=login&username=${encodeURIComponent(cleanUser)}&passwordHash=${encodeURIComponent(passwordHash)}`;
                    const response = await fetch(url);
                    const res = await response.json();

                    btnSubmit.disabled = false;
                    iconSubmit.className = "fa-solid fa-right-to-bracket";

                    if (res && res.status === 'success') {
                        // Simpan sesi tanpa password
                        const loggedUser = {
                            username: (res.user && res.user.username) || cleanUser,
                            nama: (res.user && res.user.nama) || '',
                            kecamatan: (res.user && res.user.kecamatan) || '',
                            role: (res.user && res.user.role) || 'Lembaga'
                        };
                        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(loggedUser));
                        uInput.value = '';
                        pInput.value = '';
                        checkAuthSession();
                        switchView('dashboard');
                        return;
                    } else {
                        if (errAlert && errMsg) {
                            errMsg.innerText = res.message || "Username atau Password salah.";
                            errAlert.classList.remove('hidden');
                        }
                        return;
                    }
                } catch(e) {
                    console.error("Gagal verifikasi login online:", e);
                }
            }

            btnSubmit.disabled = false;
            iconSubmit.className = "fa-solid fa-right-to-bracket";
            if (errAlert && errMsg) {
                errMsg.innerText = "Tidak dapat memverifikasi login. Periksa koneksi internet.";
                errAlert.classList.remove('hidden');
            }
        }

        function handleLogout() {
            localStorage.removeItem(AUTH_STORAGE_KEY);
            sessionStorage.removeItem(AUTH_STORAGE_KEY);
            const forms = ['formSantriBaru', 'formGuru', 'formInputTpq'];
            forms.forEach(f => {
                const el = document.getElementById(f);
                if (el) el.reset();
            });
            updateAuthUIState();
            switchPublicTab('statistik');
        }

        // ================= SWITCH SUB-TAB FORMULIR INPUT =================
        function switchInputSubTab(tabName) {
            const tabs = ['santri', 'guru', 'kenaikan', 'data-list', 'tpq'];
            tabs.forEach(t => {
                const subtab = document.getElementById(`subtab-${t}`);
                const btn = document.getElementById(`subnav-${t}`);
                if (subtab) subtab.classList.add('hidden');
                if (btn) {
                    btn.className = "px-5 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center gap-2 text-slate-500 hover:text-slate-900 whitespace-nowrap";
                }
            });

            const activeSubtab = document.getElementById(`subtab-${tabName}`);
            const activeBtn = document.getElementById(`subnav-${tabName}`);
            if (activeSubtab) activeSubtab.classList.remove('hidden');
            if (activeBtn) {
                activeBtn.className = "px-5 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center gap-2 bg-white text-slate-900 shadow-sm border border-slate-200 whitespace-nowrap";
            }

            if (tabName === 'kenaikan') {
                populateSantriDropdownKenaikan();
                renderRiwayatKenaikan();
            } else if (tabName === 'data-list') {
                renderDataListTables();
            }
        }

        // ================= SUBMIT SANTRI BARU =================
        async function handleSantriSubmit(event) {
            event.preventDefault();
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            const userRoleLower = loggedUser && loggedUser.role ? loggedUser.role.toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;

            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            const userKec = standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan || '').toLowerCase()) || loggedUser.kecamatan || 'Kenjeran';
            const userNama = loggedUser ? (loggedUser.nama || loggedUser.username) : '';

            const kecEl = document.getElementById('kecamatanSantri');
            const tpqEl = document.getElementById('namaTpqSantri');
            let kecVal = isLembaga ? userKec : (isKorcam ? userKec : (kecEl ? kecEl.value : ''));
            let tpqVal = isLembaga ? userNama : (tpqEl ? tpqEl.value : '');

            const btn = document.getElementById('btnSubmitSantri');
            const icon = document.getElementById('iconSubmitSantri');

            if (!kecVal) {
                alert('Silakan pilih Kecamatan terlebih dahulu!');
                return;
            }
            if (!tpqVal) {
                alert('Silakan pilih Lembaga TPQ terlebih dahulu!');
                return;
            }

            if (btn) btn.disabled = true;
            if (icon) icon.className = "fa-solid fa-spinner fa-spin";

            const tempatLahir = document.getElementById('santriTempatLahir').value.trim();
            const tglLahir = document.getElementById('santriTglLahir').value;
            const ttl = tempatLahir ? `${tempatLahir}, ${tglLahir}` : tglLahir;
            const nis = document.getElementById('santriNis').value.trim();
            const nisq = (document.getElementById('santriNisq').value || '').trim();
            const kelasAwal = document.getElementById('santriKelasAwal').value;
            const nama = document.getElementById('santriNama').value.trim();
            const gender = document.getElementById('santriGender').value;

            const dataObj = {
                formType: 'santri',
                id: 'S_' + Date.now(),
                nama: nama,
                gender: gender,
                tempatLahir: tempatLahir,
                tglLahir: tglLahir,
                ttl: ttl,
                nis: nis,
                nisq: nisq,
                kelasAwal: kelasAwal,
                jilidSekarang: kelasAwal,
                namaTpq: tpqVal,
                kecamatan: kecVal,
                status: 'Aktif'
            };

            // Simpan ke cache lokal langsung agar instan
            globalSantri.unshift(dataObj);
            try { localStorage.setItem(LOCAL_STORAGE_SANTRI_KEY, JSON.stringify(globalSantri)); } catch(e) {}

            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    await fetch(GOOGLE_SCRIPT_WEB_APP_URL, {
                        method: 'POST',
                        mode: 'no-cors',
                        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                        body: JSON.stringify(dataObj)
                    });
                } catch(e) {
                    console.error("Gagal simpan santri ke Apps Script:", e);
                }
            }

            if (btn) btn.disabled = false;
            if (icon) icon.className = "fa-solid fa-floppy-disk";
            alert(`Data Santri Baru untuk ${tpqVal} (${kecVal}) berhasil disimpan!`);
            const form = document.getElementById('formSantriBaru');
            if (form) form.reset();
            checkAuthSession();

            populateSantriDropdownKenaikan();
            renderDataListTables();
            // Refresh auto-rekap live di dashboard agar data kenaikan kelas langsung tampak
            if (currentDashboardPeriode === 'live' || currentDashboardPeriode === getPeriodeBulanSekarangKey()) {
                renderStatistik();
            }
        }

        // ================= SUBMIT DATA GURU =================
        async function handleGuruSubmit(event) {
            event.preventDefault();
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            const userRoleLower = loggedUser && loggedUser.role ? loggedUser.role.toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;

            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            const userKec = standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan || '').toLowerCase()) || loggedUser.kecamatan || 'Kenjeran';
            const userNama = loggedUser ? (loggedUser.nama || loggedUser.username) : '';

            const kecEl = document.getElementById('kecamatanUstadzah');
            const tpqEl = document.getElementById('namaTpqUstadzah');
            let kecVal = isLembaga ? userKec : (isKorcam ? userKec : (kecEl ? kecEl.value : ''));
            let tpqVal = isLembaga ? userNama : (tpqEl ? tpqEl.value : '');

            const btn = document.getElementById('btnSubmitGuru');
            const icon = document.getElementById('iconSubmitGuru');

            if (!kecVal) {
                alert('Silakan pilih Kecamatan terlebih dahulu!');
                return;
            }
            if (!tpqVal) {
                alert('Silakan pilih Lembaga TPQ terlebih dahulu!');
                return;
            }

            if (btn) btn.disabled = true;
            if (icon) icon.className = "fa-solid fa-spinner fa-spin";

            const tempatLahir = document.getElementById('guruTempatLahir').value.trim();
            const tglLahir = document.getElementById('guruTglLahir').value;
            const ttl = tempatLahir ? `${tempatLahir}, ${tglLahir}` : tglLahir;
            const idGuru = document.getElementById('guruIdQiraati').value.trim();
            const mulaiMengajar = document.getElementById('guruMulaiMengajar').value;
            const nama = document.getElementById('guruNama').value.trim();
            const gender = document.getElementById('guruGender').value;

            const dataObj = {
                formType: 'guru',
                id: 'G_' + Date.now(),
                nama: nama,
                gender: gender,
                tempatLahir: tempatLahir,
                tglLahir: tglLahir,
                ttl: ttl,
                idGuru: idGuru,
                mulaiMengajar: mulaiMengajar,
                namaTpq: tpqVal,
                kecamatan: kecVal,
                status: 'Aktif'
            };

            // Simpan ke cache lokal langsung agar instan
            globalGuru.unshift(dataObj);
            try { localStorage.setItem(LOCAL_STORAGE_GURU_KEY, JSON.stringify(globalGuru)); } catch(e) {}

            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    await fetch(GOOGLE_SCRIPT_WEB_APP_URL, {
                        method: 'POST',
                        mode: 'no-cors',
                        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                        body: JSON.stringify(dataObj)
                    });
                } catch(e) {
                    console.error("Gagal simpan data guru ke Apps Script:", e);
                }
            }

            if (btn) btn.disabled = false;
            if (icon) icon.className = "fa-solid fa-floppy-disk";
            alert(`Data Guru untuk ${tpqVal} (${kecVal}) berhasil disimpan!`);
            const form = document.getElementById('formGuru');
            if (form) form.reset();
            checkAuthSession();

            renderDataListTables();
        }

        // ================= TEMPLATE & UPLOAD EXCEL SANTRI =================
        function downloadTemplateSantri() {
            if (typeof XLSX === 'undefined') {
                alert("Pustaka Excel belum siap. Silakan coba sesaat lagi.");
                return;
            }
            const templateData = [
                {
                    "Nama Santri": "Ahmad Dani Pratama",
                    "Jenis Kelamin (L/P)": "L",
                    "Tempat Lahir": "Surabaya",
                    "Tanggal Lahir (YYYY-MM-DD)": "2018-05-12",
                    "NIS": "1001",
                    "NISQ (Opsional)": "Q-0012",
                    "Jilid / Kelas Awal": "Kls 1A"
                },
                {
                    "Nama Santri": "Siti Fatimah Zahra",
                    "Jenis Kelamin (L/P)": "P",
                    "Tempat Lahir": "Sidoarjo",
                    "Tanggal Lahir (YYYY-MM-DD)": "2019-02-20",
                    "NIS": "1002",
                    "NISQ (Opsional)": "",
                    "Jilid / Kelas Awal": "Kls 1B"
                }
            ];
            const ws = XLSX.utils.json_to_sheet(templateData);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Template_Santri");
            XLSX.writeFile(wb, "Template_Import_Santri_Qiraati.xlsx");
        }

        async function uploadBatchSantri() {
            if (typeof XLSX === 'undefined') {
                alert("Pustaka Excel belum siap. Silakan periksa koneksi internet Anda.");
                return;
            }
            const fileInput = document.getElementById('fileImportSantri');
            const file = fileInput ? fileInput.files[0] : null;
            if (!file) {
                alert("Silakan pilih file Excel (.xlsx / .xls) atau CSV terlebih dahulu!");
                return;
            }

            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            if (!loggedUser) {
                alert("Anda belum login. Silakan login terlebih dahulu sebelum import data.");
                return;
            }
            const userRoleLower = loggedUser && loggedUser.role ? loggedUser.role.toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            const userKec = standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan || '').toLowerCase()) || loggedUser.kecamatan || 'Kenjeran';
            const userNama = loggedUser ? (loggedUser.nama || loggedUser.username) : '';

            const kecEl = document.getElementById('kecamatanSantri');
            const tpqEl = document.getElementById('namaTpqSantri');
            const kecVal = isLembaga ? userKec : (isKorcam ? userKec : (kecEl ? kecEl.value : 'Kenjeran'));
            const tpqVal = isLembaga ? userNama : (tpqEl ? tpqEl.value : '');

            if (!tpqVal) {
                alert("Silakan tentukan / pilih Lembaga TPQ tujuan terlebih dahulu pada formulir di atas sebelum import Excel!");
                return;
            }

            const btn = document.getElementById('btnUploadSantri');
            const icon = document.getElementById('iconUploadSantri');
            if (btn) btn.disabled = true;
            if (icon) icon.className = "fa-solid fa-spinner fa-spin";

            const reader = new FileReader();
            reader.onload = async function(e) {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: 'array' });
                    const firstSheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[firstSheetName];
                    const rows = XLSX.utils.sheet_to_json(worksheet);

                    if (!rows || rows.length === 0) {
                        alert("File Excel kosong atau format kolom tidak sesuai!");
                        if (btn) btn.disabled = false;
                        if (icon) icon.className = "fa-solid fa-cloud-arrow-up";
                        return;
                    }

                    const santriBatch = rows.map((r, idx) => {
                        const nama = r["Nama Santri"] || r["nama"] || r["Nama"] || r["NAMA"] || "";
                        const genderRaw = r["Jenis Kelamin (L/P)"] || r["gender"] || r["Gender"] || r["L/P"] || "L";
                        const tempatLahir = r["Tempat Lahir"] || r["tempatLahir"] || "Surabaya";
                        let tglLahir = r["Tanggal Lahir (YYYY-MM-DD)"] || r["tglLahir"] || r["Tanggal Lahir"] || "";
                        if (tglLahir instanceof Date) {
                            tglLahir = tglLahir.toISOString().split('T')[0];
                        }
                        const nis = String(r["NIS"] || r["nis"] || ('10' + idx));
                        const nisq = String(r["NISQ (Opsional)"] || r["nisq"] || r["NISQ"] || "");
                        const kelasAwal = r["Jilid / Kelas Awal"] || r["kelasAwal"] || r["Jilid"] || "Kls 1A";

                        return {
                            id: 'S_' + Date.now() + '_' + idx,
                            nama: String(nama).trim(),
                            gender: String(genderRaw).trim().toUpperCase().startsWith('P') ? 'P' : 'L',
                            tempatLahir: String(tempatLahir).trim(),
                            tglLahir: String(tglLahir).trim(),
                            ttl: `${tempatLahir}, ${tglLahir}`,
                            nis: nis.trim(),
                            nisq: nisq.trim(),
                            kelasAwal: kelasAwal.trim(),
                            jilidSekarang: kelasAwal.trim(),
                            namaTpq: tpqVal,
                            kecamatan: kecVal,
                            status: 'Aktif'
                        };
                    }).filter(s => s.nama);

                    if (santriBatch.length === 0) {
                        alert("Tidak ada baris data santri yang valid!");
                        if (btn) btn.disabled = false;
                        if (icon) icon.className = "fa-solid fa-cloud-arrow-up";
                        return;
                    }

                    if (GOOGLE_SCRIPT_WEB_APP_URL) {
                        try {
                            await fetch(GOOGLE_SCRIPT_WEB_APP_URL, {
                                method: 'POST',
                                mode: 'no-cors',
                                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                                body: JSON.stringify({
                                    formType: 'batchSantri',
                                    santriList: santriBatch
                                })
                            });
                        } catch(err) {
                            console.error("Gagal kirim batch santri ke GAS:", err);
                        }
                    }

                    globalSantri.unshift(...santriBatch);
                    try { localStorage.setItem(LOCAL_STORAGE_SANTRI_KEY, JSON.stringify(globalSantri)); } catch(e){}

                    populateSantriDropdownKenaikan();
                    renderDataListTables();

                    alert(`Berhasil mengimpor ${santriBatch.length} santri baru!`);
                    fileInput.value = '';
                } catch(ex) {
                    console.error("Error membaca file Excel santri:", ex);
                    alert("Terjadi kesalahan saat memproses file Excel santri. Pastikan format kolom sesuai template.");
                } finally {
                    if (btn) btn.disabled = false;
                    if (icon) icon.className = "fa-solid fa-cloud-arrow-up";
                }
            };
            reader.readAsArrayBuffer(file);
        }

        // ================= TEMPLATE & UPLOAD EXCEL GURU =================
        function downloadTemplateGuru() {
            if (typeof XLSX === 'undefined') {
                alert("Pustaka Excel belum siap. Silakan coba sesaat lagi.");
                return;
            }
            const templateData = [
                {
                    "Nama Lengkap Guru": "Ustadz Ahmad Fauzi",
                    "Jenis Kelamin (L/P)": "L",
                    "Tempat Lahir": "Surabaya",
                    "Tanggal Lahir (YYYY-MM-DD)": "1990-08-15",
                    "ID Guru Qiraati": "G-1082",
                    "Mulai Mengajar (YYYY-MM-DD)": "2020-07-01"
                },
                {
                    "Nama Lengkap Guru": "Siti Aisyah",
                    "Jenis Kelamin (L/P)": "P",
                    "Tempat Lahir": "Gresik",
                    "Tanggal Lahir (YYYY-MM-DD)": "1994-11-23",
                    "ID Guru Qiraati": "G-1083",
                    "Mulai Mengajar (YYYY-MM-DD)": "2021-01-15"
                }
            ];
            const ws = XLSX.utils.json_to_sheet(templateData);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Template_Guru");
            XLSX.writeFile(wb, "Template_Import_Guru_Qiraati.xlsx");
        }

        async function uploadBatchGuru() {
            if (typeof XLSX === 'undefined') {
                alert("Pustaka Excel belum siap. Silakan periksa koneksi internet Anda.");
                return;
            }
            const fileInput = document.getElementById('fileImportGuru');
            const file = fileInput ? fileInput.files[0] : null;
            if (!file) {
                alert("Silakan pilih file Excel (.xlsx / .xls) atau CSV guru terlebih dahulu!");
                return;
            }

            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            if (!loggedUser) {
                alert("Anda belum login. Silakan login terlebih dahulu sebelum import data guru.");
                return;
            }
            const userRoleLower = loggedUser && loggedUser.role ? loggedUser.role.toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            const userKec = standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan || '').toLowerCase()) || loggedUser.kecamatan || 'Kenjeran';
            const userNama = loggedUser ? (loggedUser.nama || loggedUser.username) : '';

            const kecEl = document.getElementById('kecamatanUstadzah');
            const tpqEl = document.getElementById('namaTpqUstadzah');
            const kecVal = isLembaga ? userKec : (isKorcam ? userKec : (kecEl ? kecEl.value : 'Kenjeran'));
            const tpqVal = isLembaga ? userNama : (tpqEl ? tpqEl.value : '');

            const btn = document.getElementById('btnUploadGuru');
            const icon = document.getElementById('iconUploadGuru');
            if (btn) btn.disabled = true;
            if (icon) icon.className = "fa-solid fa-spinner fa-spin";

            if (!tpqVal) {
                alert("Silakan tentukan / pilih Lembaga TPQ tujuan terlebih dahulu pada formulir di atas sebelum import Excel!");
                if (btn) btn.disabled = false;
                if (icon) icon.className = "fa-solid fa-cloud-arrow-up";
                return;
            }

            const reader = new FileReader();
            reader.onload = async function(e) {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: 'array' });
                    const firstSheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[firstSheetName];
                    const rows = XLSX.utils.sheet_to_json(worksheet);

                    if (!rows || rows.length === 0) {
                        alert("File Excel kosong atau format tidak sesuai!");
                        if (btn) btn.disabled = false;
                        if (icon) icon.className = "fa-solid fa-cloud-arrow-up";
                        return;
                    }

                    const guruBatch = rows.map((r, idx) => {
                        const nama = r["Nama Lengkap Guru"] || r["nama"] || r["Nama"] || r["NAMA"] || "";
                        const genderRaw = r["Jenis Kelamin (L/P)"] || r["gender"] || r["Gender"] || r["L/P"] || "L";
                        const tempatLahir = r["Tempat Lahir"] || r["tempatLahir"] || "Surabaya";
                        let tglLahir = r["Tanggal Lahir (YYYY-MM-DD)"] || r["tglLahir"] || r["Tanggal Lahir"] || "";
                        if (tglLahir instanceof Date) tglLahir = tglLahir.toISOString().split('T')[0];
                        const idGuru = String(r["ID Guru Qiraati"] || r["idGuru"] || r["ID Guru"] || ('G-' + idx));
                        let mulaiMengajar = r["Mulai Mengajar (YYYY-MM-DD)"] || r["mulaiMengajar"] || r["Mulai Mengajar"] || "";
                        if (mulaiMengajar instanceof Date) mulaiMengajar = mulaiMengajar.toISOString().split('T')[0];

                        return {
                            id: 'G_' + Date.now() + '_' + idx,
                            nama: String(nama).trim(),
                            gender: String(genderRaw).trim().toUpperCase().startsWith('P') ? 'P' : 'L',
                            tempatLahir: String(tempatLahir).trim(),
                            tglLahir: String(tglLahir).trim(),
                            ttl: `${tempatLahir}, ${tglLahir}`,
                            idGuru: idGuru.trim(),
                            mulaiMengajar: String(mulaiMengajar).trim(),
                            namaTpq: tpqVal,
                            kecamatan: kecVal,
                            status: 'Aktif'
                        };
                    }).filter(g => g.nama);

                    if (guruBatch.length === 0) {
                        alert("Tidak ada baris data guru yang valid!");
                        if (btn) btn.disabled = false;
                        if (icon) icon.className = "fa-solid fa-cloud-arrow-up";
                        return;
                    }

                    if (GOOGLE_SCRIPT_WEB_APP_URL) {
                        try {
                            await fetch(GOOGLE_SCRIPT_WEB_APP_URL, {
                                method: 'POST',
                                mode: 'no-cors',
                                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                                body: JSON.stringify({
                                    formType: 'batchGuru',
                                    guruList: guruBatch
                                })
                            });
                        } catch(err) {
                            console.error("Gagal kirim batch guru ke GAS:", err);
                        }
                    }

                    globalGuru.unshift(...guruBatch);
                    try { localStorage.setItem(LOCAL_STORAGE_GURU_KEY, JSON.stringify(globalGuru)); } catch(e){}

                    renderDataListTables();

                    alert(`Berhasil mengimpor ${guruBatch.length} data guru!`);
                    fileInput.value = '';
                } catch(ex) {
                    console.error("Error membaca file Excel guru:", ex);
                    alert("Terjadi kesalahan saat membaca file Excel guru. Pastikan kolom sesuai template.");
                } finally {
                    if (btn) btn.disabled = false;
                    if (icon) icon.className = "fa-solid fa-cloud-arrow-up";
                }
            };
            reader.readAsArrayBuffer(file);
        }

        // ================= KENAIKAN JILID SANTRI =================
        function populateSantriDropdownKenaikan() {
            const selectEl = document.getElementById('kenaikanPilihSantri');
            if (!selectEl) return;

            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            const userRoleLower = loggedUser && loggedUser.role ? loggedUser.role.toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const userNama = loggedUser ? (loggedUser.nama || loggedUser.username) : '';
            const userKec = loggedUser ? (loggedUser.kecamatan || '') : '';

            // Filter santri: HANYA YANG AKTIF (status bukan Nonaktif)
            let listSantri = globalSantri.filter(s => (s.status || 'Aktif').toLowerCase() !== 'nonaktif');
            if (isLembaga) {
                listSantri = listSantri.filter(s => (s.namaTpq || '').trim().toLowerCase() === userNama.trim().toLowerCase());
            } else if (isKorcam) {
                listSantri = listSantri.filter(s => (s.kecamatan || '').trim().toLowerCase() === userKec.trim().toLowerCase());
            }

            const currentVal = selectEl.value;
            selectEl.innerHTML = '<option value="" disabled selected>-- Pilih Santri --</option>';

            listSantri.forEach(s => {
                const opt = document.createElement('option');
                opt.value = s.nis || s.id;
                opt.dataset.nis = s.nis || '';
                opt.dataset.nama = s.nama;
                opt.dataset.jilid = s.jilidSekarang || s.kelasAwal || 'Kls 1A';
                opt.dataset.tpq = s.namaTpq || '';
                opt.dataset.kecamatan = s.kecamatan || '';
                opt.textContent = `${s.nama} (${s.nis ? 'NIS: ' + s.nis + ' | ' : ''}Jilid: ${s.jilidSekarang || s.kelasAwal || 'Kls 1A'}${!isLembaga ? ' | ' + (s.namaTpq || '') : ''})`;
                selectEl.appendChild(opt);
            });

            if (currentVal) selectEl.value = currentVal;
            onPilihSantriKenaikan();
        }

        function onPilihSantriKenaikan() {
            const selectEl = document.getElementById('kenaikanPilihSantri');
            const jilidLamaInput = document.getElementById('kenaikanJilidLama');
            if (!selectEl || !jilidLamaInput) return;

            const selectedOpt = selectEl.options[selectEl.selectedIndex];
            if (selectedOpt && selectedOpt.dataset && selectedOpt.dataset.jilid) {
                jilidLamaInput.value = selectedOpt.dataset.jilid;
            } else {
                jilidLamaInput.value = '';
            }
        }

        async function handleKenaikanSubmit(event) {
            event.preventDefault();
            const selectEl = document.getElementById('kenaikanPilihSantri');
            const selectedOpt = selectEl ? selectEl.options[selectEl.selectedIndex] : null;

            if (!selectedOpt || !selectedOpt.value) {
                alert("Harap pilih santri terlebih dahulu.");
                return;
            }

            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            const userRoleLower = loggedUser && loggedUser.role ? loggedUser.role.toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const kecVal = (!isAdmin) ? (loggedUser.kecamatan || 'Kenjeran') : (selectedOpt.dataset.kecamatan || 'Kenjeran');
            const tpqVal = isLembaga ? (loggedUser.nama || loggedUser.username) : (selectedOpt.dataset.tpq || 'Pusat');

            const btn = document.getElementById('btnSubmitKenaikan');
            const icon = document.getElementById('iconSubmitKenaikan');
            if (btn) btn.disabled = true;
            if (icon) icon.className = "fa-solid fa-spinner fa-spin";

            const namaSantri = selectedOpt.dataset.nama || '';
            const nis = selectedOpt.dataset.nis || selectedOpt.value;
            const jilidLama = document.getElementById('kenaikanJilidLama').value;
            const jilidBaru = document.getElementById('kenaikanJilidBaru').value;
            const tanggal = document.getElementById('kenaikanTanggal').value;
            const masaTempuh = document.getElementById('kenaikanMasaTempuh').value;
            const catatan = document.getElementById('kenaikanCatatan').value.trim();

            const dataObj = {
                formType: 'kenaikan',
                id: 'K_' + Date.now(),
                nis: nis,
                namaSantri: namaSantri,
                jilidLama: jilidLama,
                jilidBaru: jilidBaru,
                tanggal: tanggal,
                masaTempuh: Number(masaTempuh) || masaTempuh,
                catatan: catatan,
                namaTpq: tpqVal,
                kecamatan: kecVal
            };

            // Update jilidSekarang santri di memory
            const matchedSantri = globalSantri.find(s => (s.nis && s.nis === nis) || s.nama === namaSantri);
            if (matchedSantri) {
                matchedSantri.jilidSekarang = jilidBaru;
                try { localStorage.setItem(LOCAL_STORAGE_SANTRI_KEY, JSON.stringify(globalSantri)); } catch(e){}
            }

            globalKenaikan.unshift(dataObj);
            try { localStorage.setItem(LOCAL_STORAGE_KENAIKAN_KEY, JSON.stringify(globalKenaikan)); } catch(e){}

            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    await fetch(GOOGLE_SCRIPT_WEB_APP_URL, {
                        method: 'POST',
                        mode: 'no-cors',
                        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                        body: JSON.stringify(dataObj)
                    });
                } catch(e) {
                    console.error("Gagal simpan kenaikan jilid ke GAS:", e);
                }
            }

            if (btn) btn.disabled = false;
            if (icon) icon.className = "fa-solid fa-floppy-disk";
            alert(`Kenaikan Jilid untuk santri ${namaSantri} ke '${jilidBaru}' berhasil disimpan!`);

            const form = document.getElementById('formKenaikanJilid');
            if (form) form.reset();

            populateSantriDropdownKenaikan();
            renderRiwayatKenaikan();
            renderDataListTables();
        }

        function renderRiwayatKenaikan() {
            const tbody = document.getElementById('tbodyRiwayatKenaikan');
            const badgeCount = document.getElementById('badgeCountKenaikan');
            if (!tbody) return;

            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            const userRoleLower = loggedUser && loggedUser.role ? loggedUser.role.toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const userNama = loggedUser ? (loggedUser.nama || loggedUser.username) : '';
            const userKec = loggedUser ? (loggedUser.kecamatan || '') : '';

            let list = globalKenaikan;
            if (isLembaga) {
                list = list.filter(k => (k.namaTpq || '').trim().toLowerCase() === userNama.trim().toLowerCase());
            } else if (isKorcam) {
                list = list.filter(k => (k.kecamatan || '').trim().toLowerCase() === userKec.trim().toLowerCase());
            }

            if (badgeCount) badgeCount.textContent = `${list.length} Riwayat`;

            if (list.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" class="text-center py-8 text-slate-400 italic">Belum ada riwayat kenaikan jilid yang dicatat.</td></tr>';
                return;
            }

            tbody.innerHTML = list.map((k, idx) => `
                <tr class="hover:bg-slate-50 transition-colors">
                    <td class="py-3 px-4 text-center font-bold text-slate-400">${santriStart + idx + 1}</td>
                    <td class="py-3 px-4 font-bold text-slate-900">${k.namaSantri || k.nama || '-'}</td>
                    <td class="py-3 px-4 text-center font-semibold text-slate-500">${k.jilidLama || '-'}</td>
                    <td class="py-3 px-4 text-center">
                        <span class="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-lg font-black text-[11px] inline-flex items-center gap-1">
                            <i class="fa-solid fa-arrow-up text-[9px]"></i> ${k.jilidBaru || '-'}
                        </span>
                    </td>
                    <td class="py-3 px-4 text-center text-slate-600 font-medium">${k.tanggal || '-'}</td>
                    <td class="py-3 px-4 text-center font-bold text-slate-700">${k.masaTempuh ? k.masaTempuh + ' hari' : '-'}</td>
                    <td class="py-3 px-4 text-slate-500 italic">${k.catatan || '-'}</td>
                </tr>
            `).join('');
        }

        function exportDataSantri() {
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            const userRoleLower = loggedUser ? (loggedUser.role || '').toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const userNama = loggedUser ? (loggedUser.nama || loggedUser.username) : '';
            const standardKecList = ["Pakal","Jambangan","Kenjeran","Rungkut","Gunung Anyar","Karang Pilang","Asemrowo","Benowo"];
            const userKec = loggedUser ? (standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan||'').toLowerCase()) || loggedUser.kecamatan || '') : '';

            let data = globalSantri;
            if (isLembaga) data = data.filter(s => (s.namaTpq||'').toLowerCase() === userNama.toLowerCase());
            else if (isKorcam) data = data.filter(s => (s.kecamatan||'').toLowerCase() === userKec.toLowerCase());

            const rows = data.map((s,i) => ({
                'No': i+1,
                'Nama Santri': s.nama || '',
                'L/P': s.jenisKelamin || '',
                'Tempat Lahir': s.tempatLahir || '',
                'Tanggal Lahir': s.tanggalLahir || '',
                'NIS': s.nis || '',
                'Jilid': s.jilidSekarang || s.kelasAwal || '',
                'Lembaga TPQ': s.namaTpq || '',
                'Kecamatan': s.kecamatan || '',
                'Status': s.status || 'Aktif'
            }));

            if (rows.length === 0) { alert('Tidak ada data santri untuk diekspor.'); return; }

            if (typeof XLSX === 'undefined') { alert('Library Excel belum siap, coba lagi sebentar.'); return; }
            const ws = XLSX.utils.json_to_sheet(rows);
            // Set column widths
            ws['!cols'] = [
                { wch: 5 }, { wch: 30 }, { wch: 5 }, { wch: 18 }, { wch: 15 },
                { wch: 15 }, { wch: 10 }, { wch: 25 }, { wch: 18 }, { wch: 10 }
            ];
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Data Santri');
            const now = new Date();
            XLSX.writeFile(wb, `Data_Santri_${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}.xlsx`);

        }

        function exportDataGuru() {
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            const userRoleLower = loggedUser ? (loggedUser.role || '').toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const userNama = loggedUser ? (loggedUser.nama || loggedUser.username) : '';
            const standardKecList = ["Pakal","Jambangan","Kenjeran","Rungkut","Gunung Anyar","Karang Pilang","Asemrowo","Benowo"];
            const userKec = loggedUser ? (standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan||'').toLowerCase()) || loggedUser.kecamatan || '') : '';

            let data = globalGuru;
            if (isLembaga) data = data.filter(g => (g.namaTpq||'').toLowerCase() === userNama.toLowerCase());
            else if (isKorcam) data = data.filter(g => (g.kecamatan||'').toLowerCase() === userKec.toLowerCase());

            const rows = data.map((g,i) => ({
                'No': i+1,
                'Nama Guru': g.nama || '',
                'L/P': g.jenisKelamin || '',
                'Tempat Lahir': g.tempatLahir || '',
                'Tanggal Lahir': g.tanggalLahir || '',
                'ID Guru Qiraati': g.idGuru || g.id || '',
                'Mulai Mengajar': g.mulaiMengajar || '',
                'Lembaga TPQ': g.namaTpq || '',
                'Kecamatan': g.kecamatan || '',
                'Status': g.status || 'Aktif'
            }));

            if (rows.length === 0) { alert('Tidak ada data guru untuk diekspor.'); return; }

            if (typeof XLSX === 'undefined') { alert('Library Excel belum siap, coba lagi sebentar.'); return; }
            const ws = XLSX.utils.json_to_sheet(rows);
            ws['!cols'] = [
                { wch: 5 }, { wch: 30 }, { wch: 5 }, { wch: 18 }, { wch: 15 },
                { wch: 18 }, { wch: 15 }, { wch: 25 }, { wch: 18 }, { wch: 10 }
            ];
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Data Guru');
            const now = new Date();
            XLSX.writeFile(wb, `Data_Guru_${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}.xlsx`);

        }

        function setStatusFilterSantri(filter) {
            currentSantriStatusFilter = filter;
            const btnAll = document.getElementById('btnStatusSantriAll');
            const btnAktif = document.getElementById('btnStatusSantriAktif');
            const btnNonaktif = document.getElementById('btnStatusSantriNonaktif');
            [btnAll, btnAktif, btnNonaktif].forEach(b => {
                if (b) b.className = "px-3 py-1.5 rounded-xl text-slate-500 hover:text-slate-900 transition-all font-bold text-xs";
            });
            if (filter === 'all' && btnAll) btnAll.className = "px-3 py-1.5 rounded-xl bg-slate-900 text-white shadow-xs transition-all font-bold text-xs";
            else if (filter === 'aktif' && btnAktif) btnAktif.className = "px-3 py-1.5 rounded-xl bg-emerald-600 text-white shadow-xs transition-all font-bold text-xs";
            else if (filter === 'nonaktif' && btnNonaktif) btnNonaktif.className = "px-3 py-1.5 rounded-xl bg-rose-600 text-white shadow-xs transition-all font-bold text-xs";
            filterSantriTable();
        }

        function setStatusFilterUstadzah(filter) {
            currentUstadzahStatusFilter = filter;
            const btnAll = document.getElementById('btnStatusUstadzahAll');
            const btnAktif = document.getElementById('btnStatusUstadzahAktif');
            const btnNonaktif = document.getElementById('btnStatusUstadzahNonaktif');
            [btnAll, btnAktif, btnNonaktif].forEach(b => {
                if (b) b.className = "px-3 py-1.5 rounded-xl text-slate-500 hover:text-slate-900 transition-all font-bold text-xs";
            });
            if (filter === 'all' && btnAll) btnAll.className = "px-3 py-1.5 rounded-xl bg-slate-900 text-white shadow-xs transition-all font-bold text-xs";
            else if (filter === 'aktif' && btnAktif) btnAktif.className = "px-3 py-1.5 rounded-xl bg-emerald-600 text-white shadow-xs transition-all font-bold text-xs";
            else if (filter === 'nonaktif' && btnNonaktif) btnNonaktif.className = "px-3 py-1.5 rounded-xl bg-rose-600 text-white shadow-xs transition-all font-bold text-xs";
            filterUstadzahTable();
        }

        function filterSantriTable() {
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            const userRoleLower = loggedUser && loggedUser.role ? loggedUser.role.toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const userNama = loggedUser ? (loggedUser.nama || loggedUser.username) : '';
            const userKec = loggedUser ? (loggedUser.kecamatan || '') : '';

            const searchInput = document.getElementById('searchInputSantri');
            const q = searchInput ? searchInput.value.toLowerCase().trim() : '';

            let filtered = [...globalSantri];
            const norm = v => String(v || '').trim().toLowerCase().replace(/\s+/g, ' ');
            const targetTpq = norm(userNama);
            const targetKec = norm(userKec);
            if (isLembaga) {
                filtered = filtered.filter(s => {
                    const c = norm(s.namaTpq);
                    return c === targetTpq || c.includes(targetTpq) || targetTpq.includes(c);
                });
            } else if (isKorcam) {
                filtered = filtered.filter(s => norm(s.kecamatan) === targetKec);
            }

            if (currentSantriStatusFilter === 'aktif') {
                filtered = filtered.filter(s => (s.status || 'Aktif').toLowerCase() !== 'nonaktif');
            } else if (currentSantriStatusFilter === 'nonaktif') {
                filtered = filtered.filter(s => (s.status || '').toLowerCase() === 'nonaktif');
            }

            if (q) {
                filtered = filtered.filter(s =>
                    (s.nama || '').toLowerCase().includes(q) ||
                    (s.nis || '').toLowerCase().includes(q) ||
                    (s.nisq || '').toLowerCase().includes(q) ||
                    (s.jilidSekarang || s.kelasAwal || '').toLowerCase().includes(q) ||
                    (s.namaTpq || '').toLowerCase().includes(q) ||
                    (s.kecamatan || '').toLowerCase().includes(q)
                );
            }

            const filterKey = (isLembaga ? userNama : '') + '|' + (isKorcam ? userKec : '') + '|' + currentSantriStatusFilter + '|' + q;
            if (filterKey !== lastSantriFilterKey) {
                lastSantriFilterKey = filterKey;
                santriTablePage = 1;
            }

            const santriTotalPages = Math.max(1, Math.ceil(filtered.length / santriRowsPerPage));
            if (santriTablePage > santriTotalPages) santriTablePage = santriTotalPages;
            if (santriTablePage < 1) santriTablePage = 1;
            const santriStart = (santriTablePage - 1) * santriRowsPerPage;
            const pageRows = filtered.slice(santriStart, santriStart + santriRowsPerPage);

            const badgeCount = document.getElementById('badgeCountSantriDaftar');
            if (badgeCount) badgeCount.textContent = `${filtered.length} Santri`;

            const tbody = document.getElementById('tbodyListSantri');
            if (!tbody) return;

            if (filtered.length === 0) {
                tbody.innerHTML = '<tr><td colspan="11" class="text-center py-8 text-slate-400 italic">Tidak ada data santri yang cocok.</td></tr>';
                return;
            }

            tbody.innerHTML = pageRows.map((s, idx) => {
                const isNonaktif = (s.status || 'Aktif').toLowerCase() === 'nonaktif';
                return `
                <tr class="hover:bg-slate-50 transition-colors ${isNonaktif ? 'opacity-65 bg-slate-50/50' : ''}">
                    <td class="py-3 px-3 text-center font-bold text-slate-400">${idx + 1}</td>
                    <td class="py-3 px-4 font-bold text-slate-900">${s.nama}</td>
                    <td class="py-3 px-3 text-center">
                        <span class="px-2 py-0.5 rounded text-[10px] font-black ${s.gender === 'L' ? 'bg-blue-100 text-blue-700' : 'bg-pink-100 text-pink-700'}">
                            ${s.gender || 'L'}
                        </span>
                    </td>
                    <td class="py-3 px-4 text-slate-600">${s.ttl || (s.tempatLahir ? s.tempatLahir + ', ' + (s.tglLahir || '') : '-')}</td>
                    <td class="py-3 px-3 text-center font-bold text-amber-800 bg-amber-50/60 whitespace-nowrap">${hitungUsiaSantriDetail(s.tglLahir || s.ttl)}</td>
                    <td class="py-3 px-3 text-center font-mono font-bold text-slate-700">${s.nis || '-'}</td>
                    <td class="py-3 px-3 text-center font-mono text-slate-500">${s.nisq || '-'}</td>
                    <td class="py-3 px-3 text-center">
                        <span class="px-2 py-0.5 bg-amber-100 text-amber-900 border border-amber-300 rounded-lg font-black text-xs inline-block">
                            ${s.jilidSekarang || s.kelasAwal || 'Kls 1A'}
                        </span>
                    </td>
                    <td class="py-3 px-3 text-slate-700 font-semibold text-center whitespace-nowrap">${s.namaTpq || '-'}</td>
                    <td class="py-3 px-3 text-center whitespace-nowrap">
                        <span class="px-2 py-0.5 rounded text-[10px] font-black ${isNonaktif ? 'bg-rose-100 text-rose-700 border border-rose-200' : 'bg-emerald-100 text-emerald-700 border border-emerald-200'}">
                            ${isNonaktif ? 'Nonaktif' : 'Aktif'}
                        </span>
                    </td>
                    <td class="py-3 px-4 text-center whitespace-nowrap">
                        <div class="inline-flex items-center gap-1">
                            <!-- Tombol Edit disembunyikan: perbaikan data santri dilakukan via Spreadsheet (lebih stabil). -->
                            <!-- <button type="button" onclick="openModalEditSantri('${s.id || s.nis}')" title="Edit Data Santri" class="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 rounded-lg text-xs transition-all">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </button> -->
                            ${!isNonaktif ? `
                            <button type="button" onclick="pilihSantriUntukKenaikan('${s.nis || s.id}')" title="Catat Kenaikan Jilid" class="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg font-bold text-xs transition-all inline-flex items-center gap-1">
                                <i class="fa-solid fa-arrow-trend-up"></i> Naik
                            </button>
                            ` : ''}
                            ${(isAdmin || isKorcam) ? `<button type="button" onclick="toggleStatusSantri('${s.id || s.nis}', '${isNonaktif ? 'Aktif' : 'Nonaktif'}')" title="${isNonaktif ? 'Aktifkan Kembali Santri' : 'Nonaktifkan Santri'}" class="p-1.5 ${isNonaktif ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200' : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'} rounded-lg text-xs transition-all">
                                <i class="fa-solid ${isNonaktif ? 'fa-user-check' : 'fa-user-slash'}"></i>
                            </button>` : ''}
                        </div>
                    </td>
                </tr>`;
            }).join('');
            renderSantriPagination(filtered.length, santriTablePage, santriRowsPerPage);
        }

        function changeSantriTablePage(page) {
            const target = Number(page);
            if (!Number.isFinite(target)) return;
            santriTablePage = Math.max(1, target);
            filterSantriTable();
        }

        function ensureSantriPaginationBar() {
            let bar = document.getElementById('santriPagination');
            if (!bar) {
                const container = document.getElementById('containerListSantri');
                if (!container || !container.parentNode) return null;
                bar = document.createElement('div');
                bar.id = 'santriPagination';
                bar.className = 'flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-3 border-t border-slate-100 bg-slate-50';
                container.parentNode.insertBefore(bar, container.nextSibling);
            }
            return bar;
        }

        function renderSantriPagination(total, page, perPage) {
            const bar = ensureSantriPaginationBar();
            if (!bar) return;
            if (!total || total <= perPage) {
                bar.innerHTML = total ? `<span class="text-xs font-bold text-slate-500">Total ${total} data</span>` : '';
                return;
            }
            const totalPages = Math.max(1, Math.ceil(total / perPage));
            if (page > totalPages) page = totalPages;
            if (page < 1) page = 1;
            bar.innerHTML = `
                <span class="text-xs font-bold text-slate-600">Halaman ${page} dari ${totalPages} &bull; Total ${total} data</span>
                <div class="flex items-center gap-2">
                    <button type="button" onclick="changeSantriTablePage(${page - 1})" ${page <= 1 ? 'disabled' : ''} class="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-bold ${page <= 1 ? 'text-slate-300 cursor-not-allowed' : 'text-slate-700 hover:bg-white'}">Sebelumnya</button>
                    <button type="button" onclick="changeSantriTablePage(${page + 1})" ${page >= totalPages ? 'disabled' : ''} class="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-bold ${page >= totalPages ? 'text-slate-300 cursor-not-allowed' : 'text-slate-700 hover:bg-white'}">Berikutnya</button>
                </div>
            `;
        }

        function filterUstadzahTable() {
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            const userRoleLower = loggedUser && loggedUser.role ? loggedUser.role.toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const userNama = loggedUser ? (loggedUser.nama || loggedUser.username) : '';
            const userKec = loggedUser ? (loggedUser.kecamatan || '') : '';
            const norm = v => String(v || '').trim().toLowerCase().replace(/\s+/g, ' ');
            const targetTpq = norm(userNama);
            const targetKec = norm(userKec);

            const searchInput = document.getElementById('searchInputUstadzah');
            const q = searchInput ? searchInput.value.toLowerCase().trim() : '';

            let filtered = [...globalGuru];
            if (isLembaga) {
                filtered = filtered.filter(g => {
                    const c = norm(g.namaTpq);
                    return c === targetTpq || c.includes(targetTpq) || targetTpq.includes(c);
                });
            } else if (isKorcam) {
                filtered = filtered.filter(g => norm(g.kecamatan) === targetKec);
            }

            if (currentUstadzahStatusFilter === 'aktif') {
                filtered = filtered.filter(g => (g.status || 'Aktif').toLowerCase() !== 'nonaktif');
            } else if (currentUstadzahStatusFilter === 'nonaktif') {
                filtered = filtered.filter(g => (g.status || '').toLowerCase() === 'nonaktif');
            }

            if (q) {
                filtered = filtered.filter(g =>
                    (g.nama || '').toLowerCase().includes(q) ||
                    (g.idGuru || '').toLowerCase().includes(q) ||
                    (g.ttl || '').toLowerCase().includes(q) ||
                    (g.namaTpq || '').toLowerCase().includes(q) ||
                    (g.kecamatan || '').toLowerCase().includes(q)
                );
            }

            const badgeCount = document.getElementById('badgeCountUstadzahDaftar');
            if (badgeCount) badgeCount.textContent = `${filtered.length} Guru`;

            const tbody = document.getElementById('tbodyListGuru');
            if (!tbody) return;

            if (filtered.length === 0) {
                tbody.innerHTML = '<tr><td colspan="11" class="text-center py-8 text-slate-400 italic">Tidak ada data guru yang cocok.</td></tr>';
                return;
            }

            tbody.innerHTML = filtered.map((g, idx) => {
                const isNonaktif = (g.status || 'Aktif').toLowerCase() === 'nonaktif';
                return `
                <tr class="hover:bg-slate-50 transition-colors ${isNonaktif ? 'opacity-65 bg-slate-50/50' : ''}">
                    <td class="py-3 px-3 text-center font-bold text-slate-400">${idx + 1}</td>
                    <td class="py-3 px-4 font-bold text-slate-900">${g.nama}</td>
                    <td class="py-3 px-3 text-center">
                        <span class="px-2 py-0.5 rounded text-[10px] font-black ${g.gender === 'L' ? 'bg-blue-100 text-blue-700' : 'bg-pink-100 text-pink-700'}">
                            ${g.gender || 'L'}
                        </span>
                    </td>
                    <td class="py-3 px-4 text-slate-600">${g.ttl || (g.tempatLahir ? g.tempatLahir + ', ' + (g.tglLahir || '') : '-')}</td>
                    <td class="py-3 px-3 text-center font-bold text-indigo-800 bg-indigo-50/60 whitespace-nowrap">${hitungUsiaGuruTahunBulan(g.tglLahir || g.ttl)}</td>
                    <td class="py-3 px-3 text-center font-mono font-bold text-indigo-700">${g.idGuru || '-'}</td>
                    <td class="py-3 px-3 text-center text-slate-600 font-medium">${g.mulaiMengajar || '-'}</td>
                    <td class="py-3 px-3 text-center font-bold text-emerald-800 bg-emerald-50/60 whitespace-nowrap">${hitungLamaMengajarTahunBulan(g.mulaiMengajar)}</td>
                    <td class="py-3 px-3 text-slate-700 font-semibold text-center whitespace-nowrap">${g.namaTpq || '-'}</td>
                    <td class="py-3 px-3 text-center whitespace-nowrap">
                        <span class="px-2 py-0.5 rounded text-[10px] font-black ${isNonaktif ? 'bg-rose-100 text-rose-700 border border-rose-200' : 'bg-emerald-100 text-emerald-700 border border-emerald-200'}">
                            ${isNonaktif ? 'Nonaktif' : 'Aktif'}
                        </span>
                    </td>
                    <td class="py-3 px-4 text-center whitespace-nowrap">
                        <div class="inline-flex items-center gap-1">
                            <button type="button" onclick="openModalEditGuru('${g.id || g.idGuru}')" title="Edit Data Guru" class="p-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs transition-all">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </button>
                            <button type="button" onclick="toggleStatusGuru('${g.id || g.idGuru}', '${isNonaktif ? 'Aktif' : 'Nonaktif'}')" title="${isNonaktif ? 'Aktifkan Kembali Guru' : 'Nonaktifkan Guru'}" class="p-1.5 ${isNonaktif ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200' : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'} rounded-lg text-xs transition-all">
                                <i class="fa-solid ${isNonaktif ? 'fa-user-check' : 'fa-user-slash'}"></i>
                            </button>
                        </div>
                    </td>
                </tr>`;
            }).join('');
        }

        function renderDataListTables() {
            filterSantriTable();
            filterUstadzahTable();
        }

        // Backward compatibility aliases
        function filterDataListTable() { renderDataListTables(); }
        function setStatusFilter(filter) { setStatusFilterSantri(filter); }
        function switchDataListType(type) { /* handled by separate views */ }

        // ================= OPERASI MODAL & TOGGLE STATUS SANTRI =================
        function openModalEditSantri(idOrNis) {
            const s = globalSantri.find(x => (x.id && String(x.id) === String(idOrNis)) || (x.nis && String(x.nis) === String(idOrNis)));
            if (!s) return;

            document.getElementById('editSantriId').value = s.id || '';
            document.getElementById('editSantriOriginalNis').value = s.nis || '';
            document.getElementById('editSantriNama').value = s.nama || '';
            document.getElementById('editSantriGender').value = s.gender || 'L';
            document.getElementById('editSantriTempatLahir').value = s.tempatLahir || '';
            
            let tgl = s.tglLahir || '';
            const match = String(tgl).match(/\d{4}-\d{2}-\d{2}/);
            document.getElementById('editSantriTglLahir').value = match ? match[0] : tgl;
            
            document.getElementById('editSantriNis').value = s.nis || '';
            document.getElementById('editSantriNisq').value = s.nisq || '';
            document.getElementById('editSantriJilid').value = s.jilidSekarang || s.kelasAwal || 'Kls 1A';
            document.getElementById('editSantriTpq').value = s.namaTpq || '';
            document.getElementById('editSantriKecamatan').value = s.kecamatan || '';
            document.getElementById('editSantriStatus').value = s.status || 'Aktif';

            const modal = document.getElementById('modalEditSantri');
            if (modal) modal.classList.remove('hidden');
        }

        function closeModalEditSantri() {
            const modal = document.getElementById('modalEditSantri');
            if (modal) modal.classList.add('hidden');
        }

        async function handleSaveEditSantri(event) {
            event.preventDefault();
            const id = document.getElementById('editSantriId').value;
            const origNis = document.getElementById('editSantriOriginalNis').value;

            const s = globalSantri.find(x => (x.id && String(x.id) === String(id)) || (x.nis && String(x.nis) === String(origNis)));
            if (!s) return;

            const btn = document.getElementById('btnSaveEditSantri');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Menyimpan...';
            }

            const updatedData = {
                id: s.id || ('S_' + Date.now()),
                nama: document.getElementById('editSantriNama').value.trim(),
                gender: document.getElementById('editSantriGender').value,
                tempatLahir: document.getElementById('editSantriTempatLahir').value.trim(),
                tglLahir: document.getElementById('editSantriTglLahir').value,
                nis: document.getElementById('editSantriNis').value.trim(),
                nisq: document.getElementById('editSantriNisq').value.trim(),
                jilidSekarang: document.getElementById('editSantriJilid').value,
                namaTpq: s.namaTpq,
                kecamatan: s.kecamatan,
                status: document.getElementById('editSantriStatus').value
            };
            updatedData.ttl = updatedData.tempatLahir ? `${updatedData.tempatLahir}, ${updatedData.tglLahir}` : updatedData.tglLahir;

            // Update memori lokal
            Object.assign(s, updatedData);
            try { localStorage.setItem(LOCAL_STORAGE_SANTRI_KEY, JSON.stringify(globalSantri)); } catch(e){}

            // Kirim ke GAS Web App
            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    await fetch(GOOGLE_SCRIPT_WEB_APP_URL, {
                        method: 'POST',
                        mode: 'no-cors',
                        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                        body: JSON.stringify({
                            formType: 'editSantri',
                            ...updatedData
                        })
                    });
                } catch(e) {
                    console.error("Gagal sinkron edit santri ke server:", e);
                }
            }

            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-check"></i> Simpan Perubahan';
            }

            closeModalEditSantri();
            renderDataListTables();
            populateSantriDropdownKenaikan();
            alert("Data santri berhasil diperbarui!");
        }

        async function toggleStatusSantri(idOrNis, targetStatus) {
            const s = globalSantri.find(x => (x.id && String(x.id) === String(idOrNis)) || (x.nis && String(x.nis) === String(idOrNis)));
            if (!s) return;

            const isDeactivating = targetStatus === 'Nonaktif';
            const confirmMsg = isDeactivating
                ? `Apakah Anda yakin ingin menonaktifkan santri "${s.nama}"?\nSantri ini tidak akan muncul di daftar aktif dan proses kenaikan jilid.`
                : `Aktifkan kembali santri "${s.nama}"?`;

            if (!confirm(confirmMsg)) return;

            s.status = targetStatus;
            try { localStorage.setItem(LOCAL_STORAGE_SANTRI_KEY, JSON.stringify(globalSantri)); } catch(e){}

            renderDataListTables();
            populateSantriDropdownKenaikan();

            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    await fetch(GOOGLE_SCRIPT_WEB_APP_URL, {
                        method: 'POST',
                        mode: 'no-cors',
                        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                        body: JSON.stringify({
                            formType: 'statusSantri',
                            id: s.id,
                            nis: s.nis,
                            status: targetStatus
                        })
                    });
                } catch(e) {
                    console.error("Gagal update status santri ke cloud:", e);
                }
            }
        }

        // ================= OPERASI MODAL & TOGGLE STATUS GURU =================
        function openModalEditGuru(idOrIdGuru) {
            const g = globalGuru.find(x => (x.id && String(x.id) === String(idOrIdGuru)) || (x.idGuru && String(x.idGuru) === String(idOrIdGuru)));
            if (!g) return;

            document.getElementById('editGuruId').value = g.id || '';
            document.getElementById('editGuruOriginalIdQiraati').value = g.idGuru || '';
            document.getElementById('editGuruNama').value = g.nama || '';
            document.getElementById('editGuruGender').value = g.gender || 'L';
            document.getElementById('editGuruTempatLahir').value = g.tempatLahir || '';
            
            let tgl = g.tglLahir || '';
            const match = String(tgl).match(/\d{4}-\d{2}-\d{2}/);
            document.getElementById('editGuruTglLahir').value = match ? match[0] : tgl;
            
            document.getElementById('editGuruIdQiraati').value = g.idGuru || '';
            document.getElementById('editGuruMulaiMengajar').value = g.mulaiMengajar || '';
            document.getElementById('editGuruTpq').value = g.namaTpq || '';
            document.getElementById('editGuruKecamatan').value = g.kecamatan || '';
            document.getElementById('editGuruStatus').value = g.status || 'Aktif';

            const modal = document.getElementById('modalEditGuru');
            if (modal) modal.classList.remove('hidden');
        }

        function closeModalEditGuru() {
            const modal = document.getElementById('modalEditGuru');
            if (modal) modal.classList.add('hidden');
        }

        async function handleSaveEditGuru(event) {
            event.preventDefault();
            const id = document.getElementById('editGuruId').value;
            const origIdGuru = document.getElementById('editGuruOriginalIdQiraati').value;

            const g = globalGuru.find(x => (x.id && String(x.id) === String(id)) || (x.idGuru && String(x.idGuru) === String(origIdGuru)));
            if (!g) return;

            const btn = document.getElementById('btnSaveEditGuru');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Menyimpan...';
            }

            const updatedData = {
                id: g.id || ('G_' + Date.now()),
                nama: document.getElementById('editGuruNama').value.trim(),
                gender: document.getElementById('editGuruGender').value,
                tempatLahir: document.getElementById('editGuruTempatLahir').value.trim(),
                tglLahir: document.getElementById('editGuruTglLahir').value,
                idGuru: document.getElementById('editGuruIdQiraati').value.trim(),
                mulaiMengajar: document.getElementById('editGuruMulaiMengajar').value,
                namaTpq: g.namaTpq,
                kecamatan: g.kecamatan,
                status: document.getElementById('editGuruStatus').value
            };
            updatedData.ttl = updatedData.tempatLahir ? `${updatedData.tempatLahir}, ${updatedData.tglLahir}` : updatedData.tglLahir;

            // Update memori lokal
            Object.assign(g, updatedData);
            try { localStorage.setItem(LOCAL_STORAGE_GURU_KEY, JSON.stringify(globalGuru)); } catch(e){}

            // Kirim ke GAS Web App
            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    await fetch(GOOGLE_SCRIPT_WEB_APP_URL, {
                        method: 'POST',
                        mode: 'no-cors',
                        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                        body: JSON.stringify({
                            formType: 'editGuru',
                            ...updatedData
                        })
                    });
                } catch(e) {
                    console.error("Gagal sinkron edit guru ke server:", e);
                }
            }

            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-check"></i> Simpan Perubahan';
            }

            closeModalEditGuru();
            renderDataListTables();
            alert("Data guru / ustadz berhasil diperbarui!");
        }

        async function toggleStatusGuru(idOrIdGuru, targetStatus) {
            const g = globalGuru.find(x => (x.id && String(x.id) === String(idOrIdGuru)) || (x.idGuru && String(x.idGuru) === String(idOrIdGuru)));
            if (!g) return;

            const isDeactivating = targetStatus === 'Nonaktif';
            const confirmMsg = isDeactivating
                ? `Apakah Anda yakin ingin menonaktifkan data pengajar "${g.nama}"?`
                : `Aktifkan kembali data pengajar "${g.nama}"?`;

            if (!confirm(confirmMsg)) return;

            g.status = targetStatus;
            try { localStorage.setItem(LOCAL_STORAGE_GURU_KEY, JSON.stringify(globalGuru)); } catch(e){}

            renderDataListTables();

            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    await fetch(GOOGLE_SCRIPT_WEB_APP_URL, {
                        method: 'POST',
                        mode: 'no-cors',
                        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                        body: JSON.stringify({
                            formType: 'statusGuru',
                            id: g.id,
                            idGuru: g.idGuru,
                            status: targetStatus
                        })
                    });
                } catch(e) {
                    console.error("Gagal update status guru ke cloud:", e);
                }
            }
        }

        function pilihSantriUntukKenaikan(santriIdOrNis) {
            switchView('santri-kenaikan');
            populateSantriDropdownKenaikan();
            const selectEl = document.getElementById('kenaikanPilihSantri');
            if (selectEl) {
                selectEl.value = santriIdOrNis;
                onPilihSantriKenaikan();
                selectEl.focus();
            }
        }

        // Handler perubahan kecamatan pada Formulir Input Data
        function onInputKecamatanChange() {
            const kecSelect = document.getElementById('kecamatan');
            const tpqSelect = document.getElementById('namaTpq');
            const selectedKec = kecSelect.value;

            tpqSelect.innerHTML = '';

            const list = tpqListByKecamatan[selectedKec];
            if (list && list.length > 0) {
                tpqSelect.disabled = false;
                tpqSelect.classList.remove('bg-slate-100');
                tpqSelect.classList.add('bg-white');

                const defaultOpt = document.createElement('option');
                defaultOpt.value = "";
                defaultOpt.disabled = true;
                defaultOpt.selected = true;
                defaultOpt.textContent = "-- Pilih Nama TPQ --";
                tpqSelect.appendChild(defaultOpt);

                list.forEach(tpqName => {
                    const opt = document.createElement('option');
                    opt.value = tpqName;
                    opt.textContent = tpqName;
                    tpqSelect.appendChild(opt);
                });
            } else {
                tpqSelect.disabled = false;
                tpqSelect.classList.remove('bg-slate-100');
                tpqSelect.classList.add('bg-white');

                const opt = document.createElement('option');
                opt.value = "";
                opt.selected = true;
                opt.textContent = "-- Belum ada TPQ terdaftar (Tambah di tab Users) --";
                tpqSelect.appendChild(opt);
            }
        }

        function switchTab(tabId) {
            if (tabId === 'statistik') switchView('dashboard');
            else if (tabId === 'input') switchView('santri-input');
            else if (tabId === 'rekap-kecamatan') switchView('rekap-kecamatan');
            else switchView(tabId);
        }

        function toggleMobileMenu() {
            const menu = document.getElementById('mobileMenu');
            menu.classList.toggle('hidden');
        }

        async function fetchSheetData() {
            const icons = [document.getElementById('iconRefreshStat')];
            icons.forEach(icon => { if(icon) icon.classList.add('fa-spin'); });

            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
                    const loggedUser = rawUser ? JSON.parse(rawUser) : null;
                    const role = loggedUser && loggedUser.role ? String(loggedUser.role) : '';
                    const roleLower = role.toLowerCase();
                    const isAdmin = roleLower === 'admin';
                    const params = new URLSearchParams();
                    params.set('action', 'getData');
                    // Lembaga/Korcam hanya menerima data miliknya, mengurangi payload (7000 -> 200-300)
                    if (!isAdmin) {
                        const kec = loggedUser && loggedUser.kecamatan ? String(loggedUser.kecamatan).trim() : '';
                        if (kec && kec.toLowerCase() !== 'semua') params.set('kecamatan', kec);
                        const isKorcam = roleLower.includes('korcam') || roleLower.includes('kecamatan');
                        if (!isKorcam && loggedUser && loggedUser.nama) {
                            params.set('namaTpq', String(loggedUser.nama).trim());
                        }
                    }
                    const response = await fetch(GOOGLE_SCRIPT_WEB_APP_URL + '?' + params.toString());
                    const json = await response.json();
                    onDataLoaded(json.data || json, json.korcam, json.tpqByKecamatan, json.users, json.santri, json.guru, json.kenaikan, json.mutasi);
                    return;
                } catch(e) {
                    console.error("Gagal fetch dari Web App URL:", e);
                }
            }

            // Fallback: LocalStorage
            let saved = localStorage.getItem(LOCAL_STORAGE_KEY);
            let savedSantri = localStorage.getItem(LOCAL_STORAGE_SANTRI_KEY);
            let savedGuru = localStorage.getItem(LOCAL_STORAGE_GURU_KEY);
            let savedKenaikan = localStorage.getItem(LOCAL_STORAGE_KENAIKAN_KEY);
            let savedMutasi = localStorage.getItem(LOCAL_STORAGE_MUTASI_KEY);

            let parsedData = saved ? JSON.parse(saved) : [];
            let parsedSantri = savedSantri ? JSON.parse(savedSantri) : [];
            let parsedGuru = savedGuru ? JSON.parse(savedGuru) : [];
            let parsedKenaikan = savedKenaikan ? JSON.parse(savedKenaikan) : [];
            let parsedMutasi = savedMutasi ? JSON.parse(savedMutasi) : [];

            onDataLoaded(parsedData, null, null, null, parsedSantri, parsedGuru, parsedKenaikan, parsedMutasi);
        }

        function onDataLoaded(data, korcamMap, tpqMap, usersList, santriList, guruList, kenaikanList, mutasiList) {
            globalData = data || [];
            
            if (Array.isArray(santriList)) {
                const normalizedSantri = santriList.map(item => {
                    const s = { ...(item || {}) };
                    s.id = s.id || s.ID || s.Id || ('S_' + Math.random().toString(36).slice(2));
                    s.nama = s.nama || s['Nama Santri'] || s.Nama || s.namaSantri || '';
                    s.gender = (s.gender || s['L/P'] || 'L').toString().trim().toUpperCase().startsWith('P') ? 'P' : 'L';
                    s.tempatLahir = s.tempatLahir || s['Tempat Lahir'] || '';
                    s.tglLahir = s.tglLahir || s['Tanggal Lahir'] || '';
                    if (!s.ttl && (s.tempatLahir || s.tglLahir)) {
                        s.ttl = (s.tempatLahir ? s.tempatLahir : '') + (s.tglLahir ? (s.tempatLahir ? ', ' : '') + s.tglLahir : '');
                    }
                    s.nis = (s.nis !== undefined && s.nis !== null) ? String(s.nis).trim() : String(s.NIS || '').trim();
                    s.nisq = (s.nisq !== undefined && s.nisq !== null) ? String(s.nisq).trim() : String(s.NISQ || '').trim();
                    s.jilidSekarang = s.jilidSekarang || s['Jilid Sekarang'] || s.kelasAwal || s.Jilid || 'Kls 1A';
                    s.namaTpq = s.namaTpq || s['Nama TPQ'] || s.namaTpqLembaga || '';
                    s.kecamatan = s.kecamatan || s.Kecamatan || '';
                    s.status = s.status || s.Status || 'Aktif';
                    return s;
                });
                globalSantri = normalizedSantri;
                try { localStorage.setItem(LOCAL_STORAGE_SANTRI_KEY, JSON.stringify(normalizedSantri)); } catch(e) {}
            }
            if (Array.isArray(guruList)) {
                const normalizedGuru = guruList.map(item => {
                    const g = { ...(item || {}) };
                    g.id = g.id || g.ID || g.Id || ('G_' + Math.random().toString(36).slice(2));
                    g.nama = g.nama || g['Nama Guru'] || g.Nama || '';
                    g.gender = (g.gender || g['L/P'] || 'L').toString().trim().toUpperCase().startsWith('P') ? 'P' : 'L';
                    g.tempatLahir = g.tempatLahir || g['Tempat Lahir'] || '';
                    g.tglLahir = g.tglLahir || g['Tanggal Lahir'] || '';
                    g.idGuru = (g.idGuru !== undefined && g.idGuru !== null) ? String(g.idGuru).trim() : String(g['ID Guru Qiraati'] || g['ID Guru'] || '').trim();
                    g.mulaiMengajar = g.mulaiMengajar || g['Mulai Mengajar'] || '';
                    g.namaTpq = g.namaTpq || g['Nama TPQ'] || '';
                    g.kecamatan = g.kecamatan || g.Kecamatan || '';
                    g.status = g.status || g.Status || 'Aktif';
                    return g;
                });
                globalGuru = normalizedGuru;
                try { localStorage.setItem(LOCAL_STORAGE_GURU_KEY, JSON.stringify(normalizedGuru)); } catch(e) {}
            }
            if (Array.isArray(kenaikanList)) {
                globalKenaikan = kenaikanList;
                try { localStorage.setItem(LOCAL_STORAGE_KENAIKAN_KEY, JSON.stringify(kenaikanList)); } catch(e) {}
            }
            if (Array.isArray(mutasiList)) {
                globalMutasi = mutasiList;
                try { localStorage.setItem(LOCAL_STORAGE_MUTASI_KEY, JSON.stringify(mutasiList)); } catch(e) {}
            }

            // Data Users tidak disimpan ke klien (tidak ada password di localStorage).
            // cachedUsersList sengaja tidak diisi dari respons server.

            if (korcamMap && typeof korcamMap === 'object') {
                Object.keys(korcamMap).forEach(k => {
                    if (!dataKorcamByKecamatan[k]) dataKorcamByKecamatan[k] = {};
                    if (korcamMap[k].alamat) dataKorcamByKecamatan[k].alamat = korcamMap[k].alamat;
                    if (korcamMap[k].sekretaris) dataKorcamByKecamatan[k].sekretaris = korcamMap[k].sekretaris;
                    if (korcamMap[k].kontak) dataKorcamByKecamatan[k].kontak = korcamMap[k].kontak;
                });
            }

            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            if (tpqMap && typeof tpqMap === 'object') {
                Object.keys(tpqMap).forEach(rawK => {
                    const matchedKec = standardKecList.find(sk => sk.toLowerCase() === rawK.toLowerCase()) || rawK;
                    if (!tpqListByKecamatan[matchedKec]) tpqListByKecamatan[matchedKec] = [];
                    (tpqMap[rawK] || []).forEach(nama => {
                        if (!tpqListByKecamatan[matchedKec].includes(nama)) {
                            tpqListByKecamatan[matchedKec].push(nama);
                        }
                    });
                });
            }

            if (Array.isArray(globalData)) {
                globalData.forEach(d => {
                    if (d.kecamatan && d.namaTpq) {
                        const matchedKec = standardKecList.find(sk => sk.toLowerCase() === d.kecamatan.toLowerCase()) || d.kecamatan;
                        if (!tpqListByKecamatan[matchedKec]) tpqListByKecamatan[matchedKec] = [];
                        if (!tpqListByKecamatan[matchedKec].includes(d.namaTpq)) {
                            tpqListByKecamatan[matchedKec].push(d.namaTpq);
                        }
                    }
                });
            }

            const icons = [document.getElementById('iconRefreshStat')];
            icons.forEach(icon => { if(icon) icon.classList.remove('fa-spin'); });

            // Jika sheet rekap (DataSantri) kosong, rekap otomatis dari daftar santri/guru
            // agar Dashboard & Statistik Eksekutif tetap menampilkan data.
            if (!Array.isArray(globalData) || globalData.length === 0) {
                const rekapFields = ['kelas1a','kelas1b','kelas1c','kelas2a','kelas2b','kelas3a','kelas3b','kelas4a','kelas4b','kelas5a','kelas5b','persiapanImtas','persiapanKhotaman','praPtpt1','praPtpt2','praPtpt3','praPtpt4','praPtpt5','ptpt1','ptpt2','ptpt3','ptpt4','ptpt5','ptpt6'];
                const byTpq = {};
                (Array.isArray(globalSantri) ? globalSantri : []).forEach(s => {
                    const namaTpq = String(s.namaTpq || '').trim() || 'Tanpa Nama TPQ';
                    const kec = String(s.kecamatan || '').trim();
                    if (!byTpq[namaTpq]) {
                        const row = { id: 'AUTO_' + namaTpq, namaTpq: namaTpq, kecamatan: kec, bulan: '', jumlahGuru: 0, total: 0 };
                        rekapFields.forEach(f => row[f] = 0);
                        byTpq[namaTpq] = row;
                    }
                    const row = byTpq[namaTpq];
                    row.total++;
                    const fld = (typeof deteksiKategoriKelasSantri === 'function') ? deteksiKategoriKelasSantri(s) : null;
                    if (fld && row[fld] !== undefined) row[fld]++;
                });
                (Array.isArray(globalGuru) ? globalGuru : []).forEach(g => {
                    const namaTpq = String(g.namaTpq || '').trim() || 'Tanpa Nama TPQ';
                    const kec = String(g.kecamatan || '').trim();
                    if (!byTpq[namaTpq]) {
                        const row = { id: 'AUTO_' + namaTpq, namaTpq: namaTpq, kecamatan: kec, bulan: '', jumlahGuru: 0, total: 0 };
                        rekapFields.forEach(f => row[f] = 0);
                        byTpq[namaTpq] = row;
                    }
                    byTpq[namaTpq].jumlahGuru++;
                });
                globalData = Object.values(byTpq);
            }

            checkAndSyncMonthlyArchives();
            renderStatistik();
            onInputKecamatanChange();
            renderRekapKecamatan();
            populateSantriDropdownKenaikan();
            renderRiwayatKenaikan();
            renderDataListTables();

            checkAuthSession();
            updateSidebarUserBox();
            renderMutasiSantriView();
            renderMutasiUstadzahView();
        }

        function onDataError(err) {
            console.error("Gagal mengambil data:", err);
            const icons = [document.getElementById('iconRefreshStat')];
            icons.forEach(icon => { if(icon) icon.classList.remove('fa-spin'); });
            alert("Gagal menyambungkan data.");
        }

        async function handleFormSubmit(event) {
            event.preventDefault();

            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            const userRoleLower = loggedUser && loggedUser.role ? loggedUser.role.toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;

            const standardKecList = ["Pakal", "Jambangan", "Kenjeran", "Rungkut", "Gunung Anyar", "Karang Pilang", "Asemrowo", "Benowo"];
            const loggedKec = (!isAdmin) ? (
                standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan || '').toLowerCase()) ||
                standardKecList.find(k => k.toLowerCase() === userRoleLower) ||
                loggedUser.kecamatan || 'Kenjeran'
            ) : '';

            const kecVal = (!isAdmin) ? loggedKec : document.getElementById('kecamatan').value;
            const tpqVal = isLembaga ? (loggedUser.nama || '') : document.getElementById('namaTpq').value.trim();
            const bulanVal = document.getElementById('bulan').value;

            if (!kecVal || !tpqVal) {
                alert("Harap pilih Kecamatan dan Nama TPQ terlebih dahulu.");
                return;
            }
            if (!bulanVal) {
                alert("Harap pilih Bulan Pendataan.");
                return;
            }

            const btnSubmit = document.getElementById('btnSubmit');
            const iconSubmit = document.getElementById('iconSubmit');
            btnSubmit.disabled = true;
            iconSubmit.className = "fa-solid fa-spinner fa-spin";

            const dataObj = {
                id: 'id_' + Date.now(),
                namaTpq: tpqVal,
                kecamatan: kecVal,
                bulan: bulanVal,
                jumlahGuru: Number(document.getElementById('jumlahGuru').value) || 0,
                
                kelas1a: Number(document.getElementById('kelas1a').value) || 0,
                kelas1b: Number(document.getElementById('kelas1b').value) || 0,
                kelas1c: Number(document.getElementById('kelas1c').value) || 0,
                kelas2a: Number(document.getElementById('kelas2a').value) || 0,
                kelas2b: Number(document.getElementById('kelas2b').value) || 0,
                kelas3a: Number(document.getElementById('kelas3a').value) || 0,
                kelas3b: Number(document.getElementById('kelas3b').value) || 0,
                kelas4a: Number(document.getElementById('kelas4a').value) || 0,
                kelas4b: Number(document.getElementById('kelas4b').value) || 0,
                kelas5a: Number(document.getElementById('kelas5a').value) || 0,
                kelas5b: Number(document.getElementById('kelas5b').value) || 0,
                persiapanImtas: Number(document.getElementById('persiapanImtas').value) || 0,
                persiapanKhotaman: Number(document.getElementById('persiapanKhotaman').value) || 0,
                
                praPtpt1: Number(document.getElementById('praPtpt1').value) || 0,
                praPtpt2: Number(document.getElementById('praPtpt2').value) || 0,
                praPtpt3: Number(document.getElementById('praPtpt3').value) || 0,
                praPtpt4: Number(document.getElementById('praPtpt4').value) || 0,
                praPtpt5: Number(document.getElementById('praPtpt5').value) || 0,
                
                ptpt1: Number(document.getElementById('ptpt1').value) || 0,
                ptpt2: Number(document.getElementById('ptpt2').value) || 0,
                ptpt3: Number(document.getElementById('ptpt3').value) || 0,
                ptpt4: Number(document.getElementById('ptpt4').value) || 0,
                ptpt5: Number(document.getElementById('ptpt5').value) || 0,
                ptpt6: Number(document.getElementById('ptpt6').value) || 0,
            };

            let totalSemua = 0;
            Object.keys(dataObj).forEach(k => {
                if(typeof dataObj[k] === 'number') totalSemua += dataObj[k];
            });
            dataObj.total = totalSemua;

            if (GOOGLE_SCRIPT_WEB_APP_URL) {
                try {
                    await fetch(GOOGLE_SCRIPT_WEB_APP_URL, {
                        method: 'POST',
                        mode: 'no-cors',
                        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                        body: JSON.stringify(dataObj)
                    });
                    resetAndFinishSubmit(dataObj);
                    setTimeout(() => { fetchSheetData(); }, 1500);
                    return;
                } catch(e) {
                    console.error("Gagal kirim ke Web App:", e);
                }
            }

            // 3. Fallback LocalStorage
            setTimeout(() => {
                resetAndFinishSubmit(dataObj);
            }, 600);
        }

        function resetAndFinishSubmit(newRecord) {
            const btnSubmit = document.getElementById('btnSubmit');
            const iconSubmit = document.getElementById('iconSubmit');
            if (btnSubmit) btnSubmit.disabled = false;
            if (iconSubmit) iconSubmit.className = "fa-solid fa-floppy-disk";

            if (newRecord) {
                globalData.unshift(newRecord);
                localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(globalData));
            }

            alert("Data TPQ berhasil disimpan!");
            const form = document.getElementById('formInputTpq');
            if (form) form.reset();

            checkAuthSession();

            const now = new Date();
            const bulanInput = document.getElementById('bulan');
            if(bulanInput) {
                bulanInput.value = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
            }

            renderStatistik();
            switchTab('rekap-kecamatan');
        }

        // ================= KONTROL FILTER GRAFIK KELAS =================
        function setChartKelasFilter(filterType) {
            currentChartFilter = filterType;

            const btnIds = {
                'all': 'btnChartAll',
                'dasar': 'btnChartDasar',
                'pra': 'btnChartPra',
                'ptpt': 'btnChartPtpt'
            };

            Object.keys(btnIds).forEach(key => {
                const btn = document.getElementById(btnIds[key]);
                if (btn) {
                    if (key === filterType) {
                        btn.className = "px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 bg-white text-slate-900 shadow-sm border border-slate-200/80";
                    } else {
                        btn.className = "px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 text-slate-500 hover:text-slate-900";
                    }
                }
            });

            renderStatistik();
        }

        // ================= RENDER STATISTIK & GRAFIK PROFESIONAL =================
        function renderStatistik() {
            const currentKey = getPeriodeBulanSekarangKey();
            const isLive = (currentDashboardPeriode === 'live' || currentDashboardPeriode === currentKey);

            let activeData = [];
            let activeCountUsia = null;

            if (isLive) {
                // Selalu generate real-time dari data santri dan guru aktif
                // Kenaikan jilid dan penambahan santri langsung mempengaruhi rekap live
                const liveSnapshot = generateLiveAutoRekap(currentKey);
                activeData = liveSnapshot.rows;
                activeCountUsia = liveSnapshot.countUsia;
            } else if (globalAutoRekapHistory[currentDashboardPeriode]) {
                const hist = globalAutoRekapHistory[currentDashboardPeriode];
                activeData = hist.rows || hist.data || [];
                activeCountUsia = hist.countUsia || null;
            } else {
                activeData = (globalData || []).filter(d => String(d.bulan || '').trim() === currentDashboardPeriode);
                if (activeData.length === 0) {
                    // Data periode lampau memang kosong, kosongkan seluruh rekap dan metrik usia
                    activeData = [];
                    activeCountUsia = {
                        'dasar_bocil': { l: 0, p: 0, total: 0, label: 'TPQ Pagi - Bocil',  rentang: '3 â€“ 5 Tahun', color: '#f59e0b' },
                        'dasar_bocol': { l: 0, p: 0, total: 0, label: 'TPQ Pagi - Bocol',  rentang: '> 5 Tahun', color: '#ea580c' },
                        'pra_bocil':   { l: 0, p: 0, total: 0, label: 'PRA PTPT - Bocil',  rentang: '3 â€“ 9 Tahun', color: '#0ea5e9' },
                        'pra_bocol':   { l: 0, p: 0, total: 0, label: 'PRA PTPT - Bocol',  rentang: '> 9 Tahun', color: '#2563eb' },
                        'ptpt_bocil':  { l: 0, p: 0, total: 0, label: 'PTPT - Bocil',      rentang: '3 â€“ 9 Tahun', color: '#a855f7' },
                        'ptpt_bocol':  { l: 0, p: 0, total: 0, label: 'PTPT - Bocol',      rentang: '> 9 Tahun', color: '#7c3aed' }
                    };
                }
            }

            // Update badge dan teks periode di header Dashboard
            const badgeLive = document.getElementById('badgeDashboardLiveStatus');
            const labelPeriode = document.getElementById('labelDashboardPeriodeAktif');
            if (badgeLive) {
                if (isLive) {
                    badgeLive.className = "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-200";
                    badgeLive.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Auto-Rekap (Live)';
                } else {
                    badgeLive.className = "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-900 border border-amber-200";
                    badgeLive.innerHTML = '<i class="fa-solid fa-box-archive text-[9px]"></i> Arsip Rekap';
                }
            }
            if (labelPeriode) {
                labelPeriode.textContent = getLabelBulanTahunIndo(currentDashboardPeriode === 'live' ? currentKey : currentDashboardPeriode);
            }

            const noticeEl = document.getElementById('noticeDashboardDataKosong');
            const noticeJudul = document.getElementById('noticeDataKosongJudul');
            const noticeDesc = document.getElementById('noticeDataKosongDesc');
            if (noticeEl) {
                if (!isLive && activeData.length === 0) {
                    noticeEl.classList.remove('hidden');
                    if (noticeJudul) noticeJudul.textContent = `Data Rekapitulasi ${getLabelBulanTahunIndo(currentDashboardPeriode)} Kosong`;
                    if (noticeDesc) noticeDesc.textContent = `Periode ini belum memiliki catatan data santri / rekapitulasi di sistem (Semua metrik bernilai 0).`;
                } else {
                    noticeEl.classList.add('hidden');
                }
            }

            const totalTpq = activeData.length;
            let totalSantri = 0;
            let totalGuru = 0;
            let totalDasar = 0;
            let totalPra = 0;
            let totalPtpt = 0;

            let kecCounts = { "Pakal": 0, "Jambangan": 0, "Kenjeran": 0, "Rungkut": 0, "Gunung Anyar": 0, "Karang Pilang": 0, "Asemrowo": 0, "Benowo": 0 };

            let sumKelas1a = 0, sumKelas1b = 0, sumKelas1c = 0;
            let sumKelas2a = 0, sumKelas2b = 0;
            let sumKelas3a = 0, sumKelas3b = 0;
            let sumKelas4a = 0, sumKelas4b = 0;
            let sumKelas5a = 0, sumKelas5b = 0;
            let sumPersiapanImtas = 0, sumPersiapanKhotaman = 0;
            let sumPra1 = 0, sumPra2 = 0, sumPra3 = 0, sumPra4 = 0, sumPra5 = 0;
            let sumPtpt1 = 0, sumPtpt2 = 0, sumPtpt3 = 0, sumPtpt4 = 0, sumPtpt5 = 0, sumPtpt6 = 0;

            activeData.forEach(item => {
                const dasar = (item.kelas1a||0)+(item.kelas1b||0)+(item.kelas1c||0)+(item.kelas2a||0)+(item.kelas2b||0)+(item.kelas3a||0)+(item.kelas3b||0)+(item.kelas4a||0)+(item.kelas4b||0)+(item.kelas5a||0)+(item.kelas5b||0)+(item.persiapanImtas||0)+(item.persiapanKhotaman||0);
                const praReal = (item.praPtpt1||0)+(item.praPtpt2||0)+(item.praPtpt3||0)+(item.praPtpt4||0)+(item.praPtpt5||0);
                const ptpt = (item.ptpt1||0)+(item.ptpt2||0)+(item.ptpt3||0)+(item.ptpt4||0)+(item.ptpt5||0)+(item.ptpt6||0);
                
                totalSantri += Number(item.total || (dasar + praReal + ptpt));
                totalGuru += Number(item.jumlahGuru || 0);
                totalDasar += dasar;
                totalPra += praReal;
                totalPtpt += ptpt;

                sumKelas1a += (item.kelas1a||0); sumKelas1b += (item.kelas1b||0); sumKelas1c += (item.kelas1c||0);
                sumKelas2a += (item.kelas2a||0); sumKelas2b += (item.kelas2b||0);
                sumKelas3a += (item.kelas3a||0); sumKelas3b += (item.kelas3b||0);
                sumKelas4a += (item.kelas4a||0); sumKelas4b += (item.kelas4b||0);
                sumKelas5a += (item.kelas5a||0); sumKelas5b += (item.kelas5b||0);
                sumPersiapanImtas += (item.persiapanImtas||0); sumPersiapanKhotaman += (item.persiapanKhotaman||0);

                sumPra1 += (item.praPtpt1||0); sumPra2 += (item.praPtpt2||0); sumPra3 += (item.praPtpt3||0); sumPra4 += (item.praPtpt4||0); sumPra5 += (item.praPtpt5||0);
                sumPtpt1 += (item.ptpt1||0); sumPtpt2 += (item.ptpt2||0); sumPtpt3 += (item.ptpt3||0); sumPtpt4 += (item.ptpt4||0); sumPtpt5 += (item.ptpt5||0); sumPtpt6 += (item.ptpt6||0);

                if(kecCounts[item.kecamatan] !== undefined) {
                    kecCounts[item.kecamatan]++;
                }
            });

            document.getElementById('statTotalTpq').innerText = totalTpq.toLocaleString();
            const elTotalGuru = document.getElementById('statTotalGuru');
            if(elTotalGuru) elTotalGuru.innerText = totalGuru.toLocaleString();
            document.getElementById('statTotalSantri').innerText = totalSantri.toLocaleString();
            document.getElementById('statTotalDasar').innerText = totalDasar.toLocaleString();
            if(document.getElementById('statTotalPra')) document.getElementById('statTotalPra').innerText = totalPra.toLocaleString();
            if(document.getElementById('statTotalPtpt')) document.getElementById('statTotalPtpt').innerText = totalPtpt.toLocaleString();

            const elSumDasar = document.getElementById('badgeSumDasar');
            const elSumPra = document.getElementById('badgeSumPra');
            const elSumPtpt = document.getElementById('badgeSumPtpt');
            if(elSumDasar) elSumDasar.innerText = totalDasar.toLocaleString() + " Santri";
            if(elSumPra) elSumPra.innerText = totalPra.toLocaleString() + " Santri";
            if(elSumPtpt) elSumPtpt.innerText = totalPtpt.toLocaleString() + " Santri";

            const ctxKec = document.getElementById('chartKecamatan').getContext('2d');
            if(chartKecamatanInstance) chartKecamatanInstance.destroy();
            chartKecamatanInstance = new Chart(ctxKec, {
                type: 'bar',
                data: {
                    labels: Object.keys(kecCounts),
                    datasets: [{
                        label: 'Jumlah TPQ Terdaftar',
                        data: Object.values(kecCounts),
                        backgroundColor: '#d97706',
                        borderRadius: 10,
                        barThickness: 26
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false, 
                    plugins: { 
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: '#0f172a',
                            padding: 10,
                            cornerRadius: 8
                        }
                    },
                    scales: {
                        y: { 
                            ticks: { precision: 0, font: { weight: 'bold' } }, 
                            grid: { borderDash: [4, 4], color: '#f1f5f9' } 
                        },
                        x: { 
                            grid: { display: false },
                            ticks: { font: { weight: 'bold', size: 11 } }
                        }
                    }
                }
            });

            const ctxJenjang = document.getElementById('chartJenjang').getContext('2d');
            if(chartJenjangInstance) chartJenjangInstance.destroy();
            chartJenjangInstance = new Chart(ctxJenjang, {
                type: 'doughnut',
                data: {
                    labels: ['TPQ Pagi', 'PRA PTPT', 'PTPT'],
                    datasets: [{
                        data: [totalDasar, totalPra, totalPtpt],
                        backgroundColor: ['#d97706', '#2563eb', '#7c3aed'],
                        borderWidth: 4,
                        borderColor: '#ffffff',
                        hoverOffset: 8
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false,
                    plugins: { 
                        legend: { 
                            position: 'bottom', 
                            labels: { font: { weight: 'bold', size: 12 }, padding: 15 } 
                        },
                        tooltip: {
                            backgroundColor: '#0f172a',
                            padding: 12,
                            cornerRadius: 8,
                            callbacks: {
                                label: function(c) {
                                    return ` ${c.label}: ${c.parsed.toLocaleString()} santri`;
                                }
                            }
                        }
                    }
                }
            });

            const dataDefDasar = [
                { label: 'Kls 1A', value: sumKelas1a, color: '#f59e0b', category: 'TPQ Pagi' },
                { label: 'Kls 1B', value: sumKelas1b, color: '#f59e0b', category: 'TPQ Pagi' },
                { label: 'Kls 1C', value: sumKelas1c, color: '#f59e0b', category: 'TPQ Pagi' },
                { label: 'Kls 2A', value: sumKelas2a, color: '#f59e0b', category: 'TPQ Pagi' },
                { label: 'Kls 2B', value: sumKelas2b, color: '#f59e0b', category: 'TPQ Pagi' },
                { label: 'Kls 3A', value: sumKelas3a, color: '#f59e0b', category: 'TPQ Pagi' },
                { label: 'Kls 3B', value: sumKelas3b, color: '#f59e0b', category: 'TPQ Pagi' },
                { label: 'Kls 4A', value: sumKelas4a, color: '#d97706', category: 'TPQ Pagi' },
                { label: 'Kls 4B', value: sumKelas4b, color: '#d97706', category: 'TPQ Pagi' },
                { label: 'Kls 5A', value: sumKelas5a, color: '#d97706', category: 'TPQ Pagi' },
                { label: 'Kls 5B', value: sumKelas5b, color: '#d97706', category: 'TPQ Pagi' },
                { label: 'Persiapan Imtas', value: sumPersiapanImtas, color: '#b45309', category: 'TPQ Pagi' },
                { label: 'Persiapan Khotaman', value: sumPersiapanKhotaman, color: '#b45309', category: 'TPQ Pagi' }
            ];

            const dataDefPra = [
                { label: 'PRA Lev 1', value: sumPra1, color: '#3b82f6', category: 'PRA PTPT' },
                { label: 'PRA Lev 2', value: sumPra2, color: '#3b82f6', category: 'PRA PTPT' },
                { label: 'PRA Lev 3', value: sumPra3, color: '#2563eb', category: 'PRA PTPT' },
                { label: 'PRA Lev 4', value: sumPra4, color: '#2563eb', category: 'PRA PTPT' },
                { label: 'PRA Lev 5', value: sumPra5, color: '#1d4ed8', category: 'PRA PTPT' }
            ];

            const dataDefPtpt = [
                { label: 'PTPT Kls 1', value: sumPtpt1, color: '#8b5cf6', category: 'PTPT' },
                { label: 'PTPT Kls 2', value: sumPtpt2, color: '#8b5cf6', category: 'PTPT' },
                { label: 'PTPT Kls 3', value: sumPtpt3, color: '#7c3aed', category: 'PTPT' },
                { label: 'PTPT Kls 4', value: sumPtpt4, color: '#7c3aed', category: 'PTPT' },
                { label: 'PTPT Kls 5', value: sumPtpt5, color: '#6d28d9', category: 'PTPT' },
                { label: 'PTPT Kls 6', value: sumPtpt6, color: '#5b21b6', category: 'PTPT' }
            ];

            let activeDataset = [];
            if (currentChartFilter === 'dasar') {
                activeDataset = dataDefDasar;
            } else if (currentChartFilter === 'pra') {
                activeDataset = dataDefPra;
            } else if (currentChartFilter === 'ptpt') {
                activeDataset = dataDefPtpt;
            } else {
                activeDataset = [...dataDefDasar, ...dataDefPra, ...dataDefPtpt];
            }

            const chartLabels = activeDataset.map(d => d.label);
            const chartValues = activeDataset.map(d => d.value);
            const chartColors = activeDataset.map(d => d.color);

            const ctxKelas = document.getElementById('chartKelasDetail').getContext('2d');
            if(chartKelasDetailInstance) chartKelasDetailInstance.destroy();
            chartKelasDetailInstance = new Chart(ctxKelas, {
                type: 'bar',
                data: {
                    labels: chartLabels,
                    datasets: [{
                        label: 'Jumlah Santri',
                        data: chartValues,
                        backgroundColor: chartColors,
                        borderRadius: 8,
                        borderSkipped: false,
                        barThickness: currentChartFilter === 'all' ? 18 : 34
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false, 
                    plugins: { 
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: '#0f172a',
                            titleFont: { size: 13, weight: 'bold', family: 'Inter' },
                            bodyFont: { size: 12, family: 'Inter' },
                            padding: 12,
                            cornerRadius: 10,
                            callbacks: {
                                title: function(items) {
                                    const index = items[0].dataIndex;
                                    return `${activeDataset[index].label} (${activeDataset[index].category})`;
                                },
                                label: function(context) {
                                    return ` Total Akumulasi: ${context.parsed.y.toLocaleString()} Santri`;
                                }
                            }
                        }
                    },
                    scales: {
                        y: { 
                            beginAtZero: true,
                            ticks: { 
                                font: { weight: 'bold', family: 'Inter' },
                                precision: 0
                            },
                            grid: { borderDash: [4, 4], color: '#f1f5f9' } 
                        },
                        x: { 
                            grid: { display: false },
                            ticks: { 
                                font: { weight: 'bold', size: currentChartFilter === 'all' ? 10 : 12, family: 'Inter' },
                                maxRotation: currentChartFilter === 'all' ? 45 : 0, 
                                minRotation: currentChartFilter === 'all' ? 45 : 0 
                            }
                        }
                    }
                }
            });

            // ================= KALKULASI STATISTIK KATEGORI USIA SANTRI (BOCIL vs BOCOL) =================
            let countUsia;
            if (activeCountUsia) {
                countUsia = activeCountUsia;
            } else {
                countUsia = {
                    'dasar_bocil': { l: 0, p: 0, total: 0, label: 'TPQ Pagi - Bocil',  rentang: '3 â€“ 5 Tahun', color: '#f59e0b' },
                    'dasar_bocol': { l: 0, p: 0, total: 0, label: 'TPQ Pagi - Bocol',  rentang: '> 5 Tahun', color: '#ea580c' },
                    'pra_bocil':   { l: 0, p: 0, total: 0, label: 'PRA PTPT - Bocil',  rentang: '3 â€“ 9 Tahun', color: '#0ea5e9' },
                    'pra_bocol':   { l: 0, p: 0, total: 0, label: 'PRA PTPT - Bocol',  rentang: '> 9 Tahun', color: '#2563eb' },
                    'ptpt_bocil':  { l: 0, p: 0, total: 0, label: 'PTPT - Bocil',      rentang: '3 â€“ 9 Tahun', color: '#a855f7' },
                    'ptpt_bocol':  { l: 0, p: 0, total: 0, label: 'PTPT - Bocol',      rentang: '> 9 Tahun', color: '#7c3aed' }
                };

                let santriWithDobCount = 0;
                if (Array.isArray(globalSantri) && globalSantri.length > 0) {
                    globalSantri.forEach(s => {
                        const info = getKategoriBocilBocol(s);
                        const key = `${info.jenjang}_${info.status}`;
                        if (countUsia[key]) {
                            santriWithDobCount++;
                            const isPerempuan = String(s.gender || s.jenisKelamin || '').toUpperCase().startsWith('P');
                            if (isPerempuan) {
                                countUsia[key].p++;
                            } else {
                                countUsia[key].l++;
                            }
                            countUsia[key].total++;
                        }
                    });
                }
            }

            // Update 6 Kartu Metrik Kategori Usia
            const rawTotalAkumulasiUsia = Object.values(countUsia).reduce((acc, c) => acc + c.total, 0);
            const totalAkumulasiUsia = rawTotalAkumulasiUsia;
            const divisorAkumulasiUsia = rawTotalAkumulasiUsia > 0 ? rawTotalAkumulasiUsia : 1;

            const mapKeys = [
                { key: 'dasar_bocil', idNum: 'statUsiaDasarBocil', idPct: 'pctUsiaDasarBocil' },
                { key: 'dasar_bocol', idNum: 'statUsiaDasarBocol', idPct: 'pctUsiaDasarBocol' },
                { key: 'pra_bocil',   idNum: 'statUsiaPraBocil',   idPct: 'pctUsiaPraBocil' },
                { key: 'pra_bocol',   idNum: 'statUsiaPraBocol',   idPct: 'pctUsiaPraBocol' },
                { key: 'ptpt_bocil',  idNum: 'statUsiaPtptBocil',  idPct: 'pctUsiaPtptBocil' },
                { key: 'ptpt_bocol',  idNum: 'statUsiaPtptBocol',  idPct: 'pctUsiaPtptBocol' },
            ];

            mapKeys.forEach(m => {
                const elNum = document.getElementById(m.idNum);
                const elPct = document.getElementById(m.idPct);
                const tot = countUsia[m.key].total;
                const pct = rawTotalAkumulasiUsia > 0 ? Math.round((tot / divisorAkumulasiUsia) * 100) : 0;
                if (elNum) elNum.innerText = tot.toLocaleString();
                if (elPct) elPct.innerText = `${pct}%`;
            });

            // Update Tabel Rincian Demografi Usia
            const tbodyUsia = document.getElementById('tbodyStatistikUsia');
            if (tbodyUsia) {
                tbodyUsia.innerHTML = Object.keys(countUsia).map(k => {
                    const item = countUsia[k];
                    const pct = rawTotalAkumulasiUsia > 0 ? Math.round((item.total / divisorAkumulasiUsia) * 100) : 0;
                    return `
                        <tr class="hover:bg-slate-50 transition-colors">
                            <td class="py-3 px-4 font-bold text-slate-900 flex items-center gap-2">
                                <span class="w-2.5 h-2.5 rounded-full" style="background-color: ${item.color}"></span>
                                ${item.label}
                            </td>
                            <td class="py-3 px-4 text-center font-semibold text-slate-500">${item.rentang}</td>
                            <td class="py-3 px-4 text-center font-bold text-blue-700">${item.l.toLocaleString()}</td>
                            <td class="py-3 px-4 text-center font-bold text-pink-700">${item.p.toLocaleString()}</td>
                            <td class="py-3 px-4 text-center font-black text-slate-900 bg-slate-50/80">${item.total.toLocaleString()}</td>
                            <td class="py-3 px-4 text-center font-bold text-slate-600">${pct}%</td>
                        </tr>
                    `;
                }).join('');
            }

            const footerTotalSantriUsia = document.getElementById('footerTotalSantriUsia');
            if (footerTotalSantriUsia) {
                footerTotalSantriUsia.innerText = `${totalAkumulasiUsia.toLocaleString()} Santri`;
            }

            // Render Chart Usia Santri (Doughnut Chart Elegan)
            const canvasUsia = document.getElementById('chartUsiaSantri');
            if (canvasUsia) {
                const ctxUsia = canvasUsia.getContext('2d');
                if (chartUsiaInstance) chartUsiaInstance.destroy();
                chartUsiaInstance = new Chart(ctxUsia, {
                    type: 'doughnut',
                    data: {
                        labels: Object.values(countUsia).map(c => c.label),
                        datasets: [{
                            data: Object.values(countUsia).map(c => c.total),
                            backgroundColor: Object.values(countUsia).map(c => c.color),
                            borderWidth: 4,
                            borderColor: '#ffffff',
                            hoverOffset: 8
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: {
                                    font: { weight: 'bold', size: 11, family: 'Inter' },
                                    padding: 12
                                }
                            },
                            tooltip: {
                                backgroundColor: '#0f172a',
                                padding: 12,
                                cornerRadius: 8,
                                callbacks: {
                                    label: function(ctx) {
                                        const val = ctx.parsed;
                                        const pct = rawTotalAkumulasiUsia > 0 ? Math.round((val / divisorAkumulasiUsia) * 100) : 0;
                                        return ` ${ctx.label}: ${val.toLocaleString()} santri (${pct}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            }
        }

        function normalizeBulan(bulanVal) {
            if (!bulanVal) return "";
            if (typeof bulanVal === 'string') {
                if (bulanVal.includes('T')) {
                    const d = new Date(bulanVal);
                    if (!isNaN(d.getTime())) {
                        const yr = d.getFullYear();
                        const mo = String(d.getMonth() + 1).padStart(2, '0');
                        return `${yr}-${mo}`;
                    }
                }
                const parts = bulanVal.split('-');
                if (parts.length >= 2) {
                    return `${parts[0]}-${parts[1].substring(0, 2)}`;
                }
            }
            return String(bulanVal);
        }

        function formatBulanIndo(bulanStr) {
            if(!bulanStr) return "-";
            const norm = normalizeBulan(bulanStr);
            const parts = norm.split('-');
            if(parts.length === 2) {
                const tahun = parts[0];
                const bulanIndex = parseInt(parts[1], 10) - 1;
                const namaBulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
                if(namaBulan[bulanIndex]) {
                    return `${namaBulan[bulanIndex]} ${tahun}`;
                }
            }
            return bulanStr;
        }

        // ================= LOGIKA REKAPITULASI PER KECAMATAN =================
        const DAFTAR_8_KECAMATAN = [
            "Pakal",
            "Jambangan",
            "Kenjeran",
            "Rungkut",
            "Gunung Anyar",
            "Karang Pilang",
            "Asemrowo",
            "Benowo"
        ];

        function resetFilterBulanKecamatan() {
            const inp = document.getElementById('filterBulanKecamatan');
            if (inp) inp.value = '';
            renderRekapKecamatan();
        }

        function closePanelDetailKecamatan() {
            const panel = document.getElementById('panelDetailKelasKecamatan');
            if (panel) panel.classList.add('hidden');
        }

        // ================= REKAP BULANAN (CUTOFF) =================
        const LOCAL_STORAGE_SNAPSHOT_KEY = 'qiraati_snapshots_bulanan';

        function getSnapshotList() {
            try {
                const raw = localStorage.getItem(LOCAL_STORAGE_SNAPSHOT_KEY);
                return raw ? JSON.parse(raw) : [];
            } catch(e) { return []; }
        }

        function saveSnapshotList(list) {
            try { localStorage.setItem(LOCAL_STORAGE_SNAPSHOT_KEY, JSON.stringify(list)); } catch(e) {}
        }

        function performMonthlyCutoff(manual = false) {
            const now = new Date();
            const yr = now.getFullYear();
            const mo = now.getMonth() + 1;
            const snapYr = manual ? yr : (mo === 1 ? yr - 1 : yr);
            const snapMo = manual ? mo : (mo === 1 ? 12 : mo - 1);

            // Detect user role
            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            if (!loggedUser) { if (manual) alert('Silakan login terlebih dahulu.'); return; }
            const userRoleLower = (loggedUser.role || '').toLowerCase();
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const userNama = loggedUser.nama || loggedUser.username;
            const standardKecList = ["Pakal","Jambangan","Kenjeran","Rungkut","Gunung Anyar","Karang Pilang","Asemrowo","Benowo"];
            const userKec = standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan||'').toLowerCase()) || loggedUser.kecamatan || '';

            // Snapshot key scoped per user
            const scopeKey = isAdmin ? 'admin' : (isKorcam ? `korcam_${userKec}` : `lembaga_${userNama}`);
            const keyId = `${snapYr}-${String(snapMo).padStart(2,'0')}_${scopeKey}`;

            const snapList = getSnapshotList();
            const BULAN_INDO = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

            if (manual) {
                const existing = snapList.find(s => s.id === keyId);
                if (existing) {
                    if (!confirm(`Rekap bulan ${BULAN_INDO[snapMo]} ${snapYr} sudah ada. Timpa dengan data terbaru?`)) return;
                }
            }

            // Helper: kategorikan santri berdasarkan jilid/kelas
            function jenjangSantri(s) {
                const jilid = String(s.jilidSekarang || s.kelasAwal || s.jilid || '').toLowerCase();
                if (jilid.includes('ptpt') && !jilid.includes('pra')) return 'ptpt';
                if (jilid.includes('pra')) return 'pra';
                // Jilid 1-6, kelas dasar, persiapan imtas/khotaman
                return 'dasar';
            }

            // Filter data source sesuai role
            let santriBase = globalSantri.filter(s => (s.status||'Aktif').toLowerCase() !== 'nonaktif');
            let guruBase   = globalGuru.filter(g => (g.status||'Aktif').toLowerCase() !== 'nonaktif');
            if (isLembaga) {
                santriBase = santriBase.filter(s => (s.namaTpq||'').toLowerCase() === userNama.toLowerCase());
                guruBase   = guruBase.filter(g => (g.namaTpq||'').toLowerCase() === userNama.toLowerCase());
            } else if (isKorcam) {
                santriBase = santriBase.filter(s => (s.kecamatan||'').toLowerCase() === userKec.toLowerCase());
                guruBase   = guruBase.filter(g => (g.kecamatan||'').toLowerCase() === userKec.toLowerCase());
            }

            // Build per-kecamatan stats (hanya untuk Korcam & Admin)
            let statsKec = [];
            if (!isLembaga) {
                const kecList = isKorcam ? [userKec] : standardKecList;
                statsKec = kecList.map(kec => {
                    const sk = santriBase.filter(s => (s.kecamatan||'').toLowerCase() === kec.toLowerCase());
                    const gk = guruBase.filter(g => (g.kecamatan||'').toLowerCase() === kec.toLowerCase());
                    const tSet = new Set([...sk.map(s=>s.namaTpq||''), ...gk.map(g=>g.namaTpq||'')].filter(Boolean));

                    let dasarBocil = 0, dasarBocol = 0;
                    let praBocil = 0, praBocol = 0;
                    let ptptBocil = 0, ptptBocol = 0;

                    sk.forEach(s => {
                        const kat = getKategoriBocilBocol(s);
                        if (kat.jenjang === 'dasar') {
                            if (kat.status === 'bocil') dasarBocil++; else dasarBocol++;
                        } else if (kat.jenjang === 'pra') {
                            if (kat.status === 'bocil') praBocil++; else praBocol++;
                        } else {
                            if (kat.status === 'bocil') ptptBocil++; else ptptBocol++;
                        }
                    });

                    return {
                        kecamatan: kec,
                        totalSantri: sk.length,
                        totalGuru: gk.length,
                        totalLembaga: tSet.size,
                        dasarBocil, dasarBocol, dasarTotal: dasarBocil + dasarBocol,
                        praBocil, praBocol, praTotal: praBocil + praBocol,
                        ptptBocil, ptptBocol, ptptTotal: ptptBocil + ptptBocol
                    };
                });
            }

            // Build per-lembaga stats
            const tpqSet = new Set([...santriBase.map(s=>s.namaTpq||''), ...guruBase.map(g=>g.namaTpq||'')].filter(Boolean));
            const statsLembaga = Array.from(tpqSet).sort().map(tpq => {
                const st = santriBase.filter(s => (s.namaTpq||'').toLowerCase() === tpq.toLowerCase());
                const gt = guruBase.filter(g => (g.namaTpq||'').toLowerCase() === tpq.toLowerCase());
                const kec = st[0]?.kecamatan || gt[0]?.kecamatan || '-';

                let dasarBocil = 0, dasarBocol = 0;
                let praBocil = 0, praBocol = 0;
                let ptptBocil = 0, ptptBocol = 0;

                st.forEach(s => {
                    const kat = getKategoriBocilBocol(s);
                    if (kat.jenjang === 'dasar') {
                        if (kat.status === 'bocil') dasarBocil++; else dasarBocol++;
                    } else if (kat.jenjang === 'pra') {
                        if (kat.status === 'bocil') praBocil++; else praBocol++;
                    } else {
                        if (kat.status === 'bocil') ptptBocil++; else ptptBocol++;
                    }
                });

                return {
                    namaTpq: tpq,
                    kecamatan: kec,
                    totalSantri: st.length,
                    totalGuru: gt.length,
                    dasarBocil, dasarBocol, dasarTotal: dasarBocil + dasarBocol,
                    praBocil, praBocol, praTotal: praBocil + praBocol,
                    ptptBocil, ptptBocol, ptptTotal: ptptBocil + ptptBocol
                };
            });

            let grandDasarBocil = 0, grandDasarBocol = 0;
            let grandPraBocil = 0, grandPraBocol = 0;
            let grandPtptBocil = 0, grandPtptBocol = 0;

            santriBase.forEach(s => {
                const kat = getKategoriBocilBocol(s);
                if (kat.jenjang === 'dasar') {
                    if (kat.status === 'bocil') grandDasarBocil++; else grandDasarBocol++;
                } else if (kat.jenjang === 'pra') {
                    if (kat.status === 'bocil') grandPraBocil++; else grandPraBocol++;
                } else {
                    if (kat.status === 'bocil') grandPtptBocil++; else grandPtptBocol++;
                }
            });

            const totalSantri  = santriBase.length;
            const totalGuru    = guruBase.length;
            const totalLembaga = tpqSet.size;

            const snap = {
                id: keyId,
                tahun: snapYr,
                bulan: snapMo,
                scopeKey,
                scopeLabel: isAdmin ? 'Cabang Surabaya' : (isKorcam ? `Kec. ${userKec}` : userNama),
                role: isAdmin ? 'admin' : (isKorcam ? 'korcam' : 'lembaga'),
                tanggalCutoff: now.toISOString(),
                totalSantri, totalGuru, totalLembaga,
                dasarBocil: grandDasarBocil, dasarBocol: grandDasarBocol, totalDasar: grandDasarBocil + grandDasarBocol,
                praBocil: grandPraBocil,     praBocol: grandPraBocol,     totalPra: grandPraBocil + grandPraBocol,
                ptptBocil: grandPtptBocil,   ptptBocol: grandPtptBocol,   totalPtpt: grandPtptBocil + grandPtptBocol,
                statsKec, statsLembaga
            };

            const idx = snapList.findIndex(s => s.id === keyId);
            if (idx >= 0) snapList[idx] = snap; else snapList.unshift(snap);
            snapList.sort((a, b) => b.id.localeCompare(a.id));
            saveSnapshotList(snapList);

            if (manual) alert(`âœ… Cutoff rekap ${BULAN_INDO[snapMo]} ${snapYr} berhasil disimpan!\nTotal: ${totalSantri} santri, ${totalGuru} guru, ${totalLembaga} lembaga.`);

            renderRekapBulanan();
        }

        function checkAutoMonthlyCutoff() {
            const now = new Date();
            const yr = now.getFullYear();
            const mo = now.getMonth() + 1;
            // Check if previous month snapshot exists
            const prevYr = mo === 1 ? yr - 1 : yr;
            const prevMo = mo === 1 ? 12 : mo - 1;
            const keyId = `${prevYr}-${String(prevMo).padStart(2,'0')}`;
            const snapList = getSnapshotList();
            if (!snapList.find(s => s.id === keyId)) {
                // Auto-cutoff previous month silently
                performMonthlyCutoff(false);
            }
        }

        function renderRekapBulanan() {
            const container = document.getElementById('containerRekapBulanan');
            if (!container) return;

            const rawUser = localStorage.getItem(AUTH_STORAGE_KEY) || sessionStorage.getItem(AUTH_STORAGE_KEY);
            const loggedUser = rawUser ? JSON.parse(rawUser) : null;
            const userRoleLower = loggedUser && loggedUser.role ? loggedUser.role.toLowerCase() : '';
            const isAdmin = userRoleLower === 'admin';
            const isKorcam = userRoleLower === 'korcam' || userRoleLower.includes('korcam') || userRoleLower.includes('kecamatan');
            const isLembaga = !isAdmin && !isKorcam;
            const userNama = loggedUser ? (loggedUser.nama || loggedUser.username) : '';
            const standardKecList = ["Pakal","Jambangan","Kenjeran","Rungkut","Gunung Anyar","Karang Pilang","Asemrowo","Benowo"];
            const userKec = loggedUser ? (standardKecList.find(k => k.toLowerCase() === (loggedUser.kecamatan||'').toLowerCase()) || loggedUser.kecamatan || '') : '';
            const currentScopeKey = isAdmin ? 'admin' : (isKorcam ? `korcam_${userKec}` : `lembaga_${userNama}`);

            const allSnaps = getSnapshotList();
            // Filter snapshot milik user yang sedang aktif
            const snapList = allSnaps.filter(s => s.scopeKey === currentScopeKey || (!s.scopeKey && isAdmin));
            const BULAN_INDO = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

            if (snapList.length === 0) {
                const labelWilayah = isAdmin ? 'Tingkat Cabang Surabaya' : (isKorcam ? `Tingkat Kecamatan ${userKec}` : `Lembaga ${userNama}`);
                container.innerHTML = `<div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-8 text-center text-slate-400 italic text-sm">
                    <i class="fa-solid fa-box-archive text-3xl mb-3 block text-slate-300"></i>
                    Belum ada rekap bulanan tersimpan untuk <strong class="text-slate-600">${labelWilayah}</strong>.<br>
                    Tekan tombol <strong>"Cutoff Sekarang"</strong> di atas untuk menyimpan rekap bulan berjalan.
                </div>`;
                return;
            }

            container.innerHTML = snapList.map(snap => {
                const bulanLabel = `${BULAN_INDO[snap.bulan]} ${snap.tahun}`;
                const cutoffDate = new Date(snap.tanggalCutoff).toLocaleString('id-ID', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
                const roleBadge = snap.role === 'admin' ? 'Cabang Surabaya' : (snap.role === 'korcam' ? `Kec. ${snap.scopeLabel || ''}` : `Lembaga: ${snap.scopeLabel || ''}`);

                // Sembunyikan tabel kecamatan untuk Lembaga
                const showKecTable = (snap.statsKec && snap.statsKec.length > 0 && !isLembaga);

                return `
                <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                    <div class="flex flex-wrap items-center justify-between px-6 py-4 border-b border-slate-100 gap-3">
                        <div>
                            <div class="flex items-center gap-2">
                                <i class="fa-solid fa-calendar-check text-emerald-500"></i>
                                <span class="font-black text-slate-900 text-base">Rekap Bulan ${bulanLabel}</span>
                                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800">${roleBadge}</span>
                            </div>
                            <p class="text-[10px] text-slate-400 mt-0.5">Disimpan: ${cutoffDate}</p>
                        </div>
                        <div class="flex items-center gap-2">
                            <button onclick="cetakRekapBulanan('${snap.id}')" class="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-700 text-white rounded-xl font-bold text-xs transition-all cursor-pointer">
                                <i class="fa-solid fa-print"></i> Cetak
                            </button>
                            <button onclick="downloadRekapBulanan('${snap.id}')" class="flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs transition-all cursor-pointer">
                                <i class="fa-solid fa-file-excel"></i> Unduh Excel
                            </button>
                            <button onclick="hapusRekapBulanan('${snap.id}')" class="flex items-center gap-1.5 px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-xl font-bold text-xs transition-all cursor-pointer" title="Hapus Rekap">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    <!-- KPI Row -->
                    <div class="grid grid-cols-3 divide-x divide-slate-100 border-b border-slate-100 bg-slate-50/50">
                        <div class="px-6 py-3 text-center">
                            <div class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Santri</div>
                            <div class="text-2xl font-black text-slate-900">${snap.totalSantri.toLocaleString()}</div>
                        </div>
                        <div class="px-6 py-3 text-center">
                            <div class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Guru</div>
                            <div class="text-2xl font-black text-slate-900">${snap.totalGuru}</div>
                        </div>
                        <div class="px-6 py-3 text-center">
                            <div class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Lembaga</div>
                            <div class="text-2xl font-black text-slate-900">${snap.totalLembaga}</div>
                        </div>
                    </div>
                    <!-- Jenjang Bocil vs Bocol Row -->
                    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 divide-x divide-slate-100 border-b border-slate-100 bg-amber-50/25">
                        <div class="px-3 py-2 text-center">
                            <div class="text-[9px] text-amber-700 font-bold uppercase tracking-wider">Dasar Bocil</div>
                            <div class="text-base font-black text-amber-900">${(snap.dasarBocil||0).toLocaleString()}</div>
                        </div>
                        <div class="px-3 py-2 text-center">
                            <div class="text-[9px] text-orange-700 font-bold uppercase tracking-wider">Dasar Bocol</div>
                            <div class="text-base font-black text-orange-900">${(snap.dasarBocol||0).toLocaleString()}</div>
                        </div>
                        <div class="px-3 py-2 text-center">
                            <div class="text-[9px] text-sky-700 font-bold uppercase tracking-wider">Pra Bocil</div>
                            <div class="text-base font-black text-sky-900">${(snap.praBocil||0).toLocaleString()}</div>
                        </div>
                        <div class="px-3 py-2 text-center">
                            <div class="text-[9px] text-blue-700 font-bold uppercase tracking-wider">Pra Bocol</div>
                            <div class="text-base font-black text-blue-900">${(snap.praBocol||0).toLocaleString()}</div>
                        </div>
                        <div class="px-3 py-2 text-center">
                            <div class="text-[9px] text-purple-700 font-bold uppercase tracking-wider">PTPT Bocil</div>
                            <div class="text-base font-black text-purple-900">${(snap.ptptBocil||0).toLocaleString()}</div>
                        </div>
                        <div class="px-3 py-2 text-center">
                            <div class="text-[9px] text-violet-700 font-bold uppercase tracking-wider">PTPT Bocol</div>
                            <div class="text-base font-black text-violet-900">${(snap.ptptBocol||0).toLocaleString()}</div>
                        </div>
                    </div>

                    ${showKecTable ? `
                    <!-- Per Kecamatan Table -->
                    <div class="p-4 border-b border-slate-100">
                        <h4 class="text-xs font-black text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                            <i class="fa-solid fa-city text-amber-500"></i> Rekap Wilayah Kecamatan
                        </h4>
                        <div class="overflow-x-auto rounded-xl border border-slate-200">
                            <table class="w-full text-xs">
                                <thead class="bg-slate-50 border-b border-slate-200">
                                    <tr>
                                        <th class="py-2 px-2.5 text-left font-bold text-slate-600 uppercase">Kecamatan</th>
                                        <th class="py-2 px-2 text-center font-bold text-amber-700 uppercase">Dasar (Bocil)</th>
                                        <th class="py-2 px-2 text-center font-bold text-orange-700 uppercase">Dasar (Bocol)</th>
                                        <th class="py-2 px-2 text-center font-bold text-sky-700 uppercase">Pra (Bocil)</th>
                                        <th class="py-2 px-2 text-center font-bold text-blue-700 uppercase">Pra (Bocol)</th>
                                        <th class="py-2 px-2 text-center font-bold text-purple-700 uppercase">PTPT (Bocil)</th>
                                        <th class="py-2 px-2 text-center font-bold text-violet-700 uppercase">PTPT (Bocol)</th>
                                        <th class="py-2 px-2.5 text-center font-bold text-slate-700 uppercase">Total Santri</th>
                                        <th class="py-2 px-2 text-center font-bold text-indigo-700 uppercase">Guru</th>
                                        <th class="py-2 px-2 text-center font-bold text-emerald-700 uppercase">Lembaga</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100">
                                    ${(snap.statsKec||[]).map(k => `
                                    <tr class="hover:bg-slate-50">
                                        <td class="py-1.5 px-2.5 font-semibold text-slate-700">${k.kecamatan}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-amber-700">${k.dasarBocil || 0}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-orange-700">${k.dasarBocol || 0}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-sky-700">${k.praBocil || 0}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-blue-700">${k.praBocol || 0}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-purple-700">${k.ptptBocil || 0}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-violet-700">${k.ptptBocol || 0}</td>
                                        <td class="py-1.5 px-2.5 text-center font-black text-slate-900">${k.totalSantri}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-indigo-700">${k.totalGuru}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-emerald-700">${k.totalLembaga}</td>
                                    </tr>`).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>` : ''}

                    <!-- Per Lembaga Table -->
                    <div class="p-4">
                        <h4 class="text-xs font-black text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                            <i class="fa-solid fa-mosque text-emerald-600"></i> Rekap Per Lembaga TPQ
                        </h4>
                        <div class="overflow-x-auto rounded-xl border border-slate-200 max-h-64">
                            <table class="w-full text-xs">
                                <thead class="bg-slate-50 border-b border-slate-200 sticky top-0">
                                    <tr>
                                        <th class="py-2 px-2.5 text-left font-bold text-slate-600 uppercase">Nama Lembaga</th>
                                        <th class="py-2 px-2 text-left font-bold text-slate-600 uppercase">Kecamatan</th>
                                        <th class="py-2 px-2 text-center font-bold text-amber-700 uppercase">Dasar (Bocil)</th>
                                        <th class="py-2 px-2 text-center font-bold text-orange-700 uppercase">Dasar (Bocol)</th>
                                        <th class="py-2 px-2 text-center font-bold text-sky-700 uppercase">Pra (Bocil)</th>
                                        <th class="py-2 px-2 text-center font-bold text-blue-700 uppercase">Pra (Bocol)</th>
                                        <th class="py-2 px-2 text-center font-bold text-purple-700 uppercase">PTPT (Bocil)</th>
                                        <th class="py-2 px-2 text-center font-bold text-violet-700 uppercase">PTPT (Bocol)</th>
                                        <th class="py-2 px-2.5 text-center font-bold text-slate-700 uppercase">Total Santri</th>
                                        <th class="py-2 px-2 text-center font-bold text-indigo-700 uppercase">Guru</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100">
                                    ${(snap.statsLembaga||[]).map(l => `
                                    <tr class="hover:bg-slate-50">
                                        <td class="py-1.5 px-2.5 font-bold text-slate-800">${l.namaTpq}</td>
                                        <td class="py-1.5 px-2 text-slate-500">${l.kecamatan}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-amber-700">${l.dasarBocil || 0}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-orange-700">${l.dasarBocol || 0}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-sky-700">${l.praBocil || 0}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-blue-700">${l.praBocol || 0}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-purple-700">${l.ptptBocil || 0}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-violet-700">${l.ptptBocol || 0}</td>
                                        <td class="py-1.5 px-2.5 text-center font-black text-slate-900">${l.totalSantri}</td>
                                        <td class="py-1.5 px-2 text-center font-bold text-indigo-700">${l.totalGuru}</td>
                                    </tr>`).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>`;
            }).join('');
        }


        function cetakRekapBulanan(snapId) {
            const snapList = getSnapshotList();
            const snap = snapList.find(s => s.id === snapId);
            if (!snap) { alert('Data rekap tidak ditemukan.'); return; }
            const BULAN_INDO = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
            const bulanLabel = `${BULAN_INDO[snap.bulan]} ${snap.tahun}`;

            const isLembagaSnap = snap.role === 'lembaga';
            const isKorcamSnap = snap.role === 'korcam';

            let subJudulKop = `REKAP BULANAN â€” ${bulanLabel.toUpperCase()}`;
            if (isLembagaSnap) subJudulKop = `REKAP BULANAN LEMBAGA ${snap.scopeLabel ? snap.scopeLabel.toUpperCase() : ''} â€” ${bulanLabel.toUpperCase()}`;
            else if (isKorcamSnap) subJudulKop = `REKAP BULANAN ${snap.scopeLabel ? snap.scopeLabel.toUpperCase() : ''} â€” ${bulanLabel.toUpperCase()}`;

            const kecRows = (snap.statsKec||[]).map((k,i) => `
                <tr>
                    <td style="text-align:center;">${i+1}</td>
                    <td>${k.kecamatan}</td>
                    <td style="text-align:center;font-weight:bold;color:#b45309">${k.dasarBocil||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#c2410c">${k.dasarBocol||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#0284c7">${k.praBocil||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#1d4ed8">${k.praBocol||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#9333ea">${k.ptptBocil||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#6d28d9">${k.ptptBocol||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#0f172a">${k.totalSantri}</td>
                    <td style="text-align:center;font-weight:bold;color:#4338ca">${k.totalGuru}</td>
                    <td style="text-align:center;font-weight:bold;color:#065f46">${k.totalLembaga}</td>
                </tr>`).join('');

            const lembagaRows = (snap.statsLembaga||[]).map((l,i) => `
                <tr>
                    <td style="text-align:center;">${i+1}</td>
                    <td><strong>${l.namaTpq}</strong></td>
                    <td>${l.kecamatan}</td>
                    <td style="text-align:center;font-weight:bold;color:#b45309">${l.dasarBocil||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#c2410c">${l.dasarBocol||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#0284c7">${l.praBocil||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#1d4ed8">${l.praBocol||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#9333ea">${l.ptptBocil||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#6d28d9">${l.ptptBocol||0}</td>
                    <td style="text-align:center;font-weight:bold;color:#b45309">${l.totalSantri}</td>
                    <td style="text-align:center;font-weight:bold;color:#4338ca">${l.totalGuru}</td>
                </tr>`).join('');

            const html = `
                <div style="display:flex;align-items:center;gap:16px;border-bottom:3px double #0f172a;padding-bottom:10px;margin-bottom:14px;">
                    <img src="img/logo-qiraati.jpg" style="width:72px;height:72px;object-fit:contain;">
                    <div style="flex:1;text-align:center;">
                        <h2 style="margin:0;font-size:14pt;font-weight:900;color:#0f172a;text-transform:uppercase;">KOORDINATOR PENDIDIKAN QIRAATI CABANG SURABAYA</h2>
                        <h3 style="margin:4px 0 0;font-size:12.5pt;font-weight:800;color:#92400e;text-transform:uppercase;">${subJudulKop}</h3>
                    </div>
                </div>
                <div style="display:flex;gap:10px;margin-bottom:8px;">
                    <div style="flex:1;border:1px solid #cbd5e1;border-radius:6px;padding:8px;text-align:center;background:#f8fafc;">
                        <div style="font-size:7.5pt;text-transform:uppercase;color:#64748b;font-weight:700;">Total Santri</div>
                        <div style="font-size:16pt;font-weight:900;color:#0f172a;">${snap.totalSantri.toLocaleString()}</div>
                    </div>
                    <div style="flex:1;border:1px solid #cbd5e1;border-radius:6px;padding:8px;text-align:center;background:#f8fafc;">
                        <div style="font-size:7.5pt;text-transform:uppercase;color:#64748b;font-weight:700;">Total Guru</div>
                        <div style="font-size:16pt;font-weight:900;color:#0f172a;">${snap.totalGuru}</div>
                    </div>
                    <div style="flex:1;border:1px solid #cbd5e1;border-radius:6px;padding:8px;text-align:center;background:#f8fafc;">
                        <div style="font-size:7.5pt;text-transform:uppercase;color:#64748b;font-weight:700;">Total Lembaga</div>
                        <div style="font-size:16pt;font-weight:900;color:#0f172a;">${snap.totalLembaga}</div>
                    </div>
                </div>
                <!-- Breakdown Usia Bocil vs Bocol -->
                <div style="display:flex;gap:6px;margin-bottom:14px;">
                    <div style="flex:1;border:1px solid #fcd34d;border-radius:6px;padding:5px;text-align:center;background:#fffbeb;">
                        <div style="font-size:6.5pt;text-transform:uppercase;color:#92400e;font-weight:700;">Dasar (Bocil)</div>
                        <div style="font-size:11pt;font-weight:900;color:#92400e;">${(snap.dasarBocil||0).toLocaleString()}</div>
                    </div>
                    <div style="flex:1;border:1px solid #fed7aa;border-radius:6px;padding:5px;text-align:center;background:#fff7ed;">
                        <div style="font-size:6.5pt;text-transform:uppercase;color:#c2410c;font-weight:700;">Dasar (Bocol)</div>
                        <div style="font-size:11pt;font-weight:900;color:#c2410c;">${(snap.dasarBocol||0).toLocaleString()}</div>
                    </div>
                    <div style="flex:1;border:1px solid #bae6fd;border-radius:6px;padding:5px;text-align:center;background:#f0f9ff;">
                        <div style="font-size:6.5pt;text-transform:uppercase;color:#0284c7;font-weight:700;">Pra (Bocil)</div>
                        <div style="font-size:11pt;font-weight:900;color:#0284c7;">${(snap.praBocil||0).toLocaleString()}</div>
                    </div>
                    <div style="flex:1;border:1px solid #93c5fd;border-radius:6px;padding:5px;text-align:center;background:#eff6ff;">
                        <div style="font-size:6.5pt;text-transform:uppercase;color:#1e40af;font-weight:700;">Pra (Bocol)</div>
                        <div style="font-size:11pt;font-weight:900;color:#1e40af;">${(snap.praBocol||0).toLocaleString()}</div>
                    </div>
                    <div style="flex:1;border:1px solid #e9d5ff;border-radius:6px;padding:5px;text-align:center;background:#faf5ff;">
                        <div style="font-size:6.5pt;text-transform:uppercase;color:#9333ea;font-weight:700;">PTPT (Bocil)</div>
                        <div style="font-size:11pt;font-weight:900;color:#9333ea;">${(snap.ptptBocil||0).toLocaleString()}</div>
                    </div>
                    <div style="flex:1;border:1px solid #c4b5fd;border-radius:6px;padding:5px;text-align:center;background:#f5f3ff;">
                        <div style="font-size:6.5pt;text-transform:uppercase;color:#5b21b6;font-weight:700;">PTPT (Bocol)</div>
                        <div style="font-size:11pt;font-weight:900;color:#5b21b6;">${(snap.ptptBocol||0).toLocaleString()}</div>
                    </div>
                </div>

                ${(!isLembagaSnap && snap.statsKec && snap.statsKec.length > 0) ? `
                <h4 style="margin:0 0 6px;font-size:9.5pt;font-weight:800;color:#0f172a;text-transform:uppercase;border-left:4px solid #d97706;padding-left:8px;">Rekap Per Wilayah Kecamatan</h4>
                <table style="width:100%;border-collapse:collapse;margin-bottom:14px;font-size:8pt;">
                    <thead><tr style="background:#f1f5f9;">
                        <th style="padding:4px;border:1px solid #cbd5e1;width:24px;">No</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:left;">Kecamatan</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#b45309;">Dasar (Bocil)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#c2410c;">Dasar (Bocol)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#0284c7;">Pra (Bocil)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#1d4ed8;">Pra (Bocol)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#9333ea;">PTPT (Bocil)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#6d28d9;">PTPT (Bocol)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;">Total</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#4338ca;">Guru</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#065f46;">Lembaga</th>
                    </tr></thead>
                    <tbody>${kecRows}</tbody>
                </table>` : ''}

                <h4 style="margin:0 0 6px;font-size:9.5pt;font-weight:800;color:#0f172a;text-transform:uppercase;border-left:4px solid #4338ca;padding-left:8px;">Rekap Per Lembaga TPQ</h4>
                <table style="width:100%;border-collapse:collapse;font-size:8pt;">
                    <thead><tr style="background:#f1f5f9;">
                        <th style="padding:4px;border:1px solid #cbd5e1;width:24px;">No</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:left;">Nama Lembaga TPQ</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:left;">Kecamatan</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#b45309;">Dasar (Bocil)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#c2410c;">Dasar (Bocol)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#0284c7;">Pra (Bocil)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#1d4ed8;">Pra (Bocol)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#9333ea;">PTPT (Bocil)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#6d28d9;">PTPT (Bocol)</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;">Total</th>
                        <th style="padding:4px;border:1px solid #cbd5e1;text-align:center;color:#4338ca;">Guru</th>
                    </tr></thead>
                    <tbody>${lembagaRows}</tbody>
                </table>
                <div style="margin-top:12px;text-align:right;font-size:8pt;color:#64748b;">Dicetak pada: ${getTanggalCetakIndo()}</div>
            `;
            executePrint(html, `Rekap_Bulanan_${snap.id}`);
        }

        function downloadRekapBulanan(snapId) {
            const snapList = getSnapshotList();
            const snap = snapList.find(s => s.id === snapId);
            if (!snap) { alert('Data rekap tidak ditemukan.'); return; }
            if (typeof XLSX === 'undefined') { alert('Library Excel belum siap, coba lagi sebentar.'); return; }
            const BULAN_INDO = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
            const bulanLabel = `${BULAN_INDO[snap.bulan]} ${snap.tahun}`;

            const wb = XLSX.utils.book_new();

            // Sheet 1: Ringkasan
            const ringkasanData = [
                { 'Keterangan': 'Rekap Bulanan', 'Nilai': bulanLabel },
                { 'Keterangan': 'Wilayah/Lingkup', 'Nilai': snap.scopeLabel || '' },
                { 'Keterangan': 'Total Santri', 'Nilai': snap.totalSantri },
                { 'Keterangan': 'Total Guru', 'Nilai': snap.totalGuru },
                { 'Keterangan': 'Total Lembaga', 'Nilai': snap.totalLembaga },
                { 'Keterangan': 'TPQ Pagi (Bocil: 3-5 th)', 'Nilai': snap.dasarBocil || 0 },
                { 'Keterangan': 'TPQ Pagi (Bocol: > 5 th)', 'Nilai': snap.dasarBocol || 0 },
                { 'Keterangan': 'PRA PTPT (Bocil: 3-9 th)',  'Nilai': snap.praBocil || 0 },
                { 'Keterangan': 'PRA PTPT (Bocol: > 9 th)',  'Nilai': snap.praBocol || 0 },
                { 'Keterangan': 'PTPT (Bocil: 3-9 th)',      'Nilai': snap.ptptBocil || 0 },
                { 'Keterangan': 'PTPT (Bocol: > 9 th)',      'Nilai': snap.ptptBocol || 0 },
            ];
            const wsRingkasan = XLSX.utils.json_to_sheet(ringkasanData);
            wsRingkasan['!cols'] = [{ wch: 30 }, { wch: 20 }];
            XLSX.utils.book_append_sheet(wb, wsRingkasan, 'Ringkasan');

            // Sheet 2: Per Kecamatan (hanya untuk admin/korcam)
            if (snap.role !== 'lembaga' && snap.statsKec && snap.statsKec.length > 0) {
                const kecData = (snap.statsKec||[]).map((k,i) => ({
                    'No': i+1, 'Kecamatan': k.kecamatan,
                    'TPQ Pagi Bocil (3-5 th)': k.dasarBocil||0,
                    'TPQ Pagi Bocol (> 5 th)': k.dasarBocol||0,
                    'PRA PTPT Bocil (3-9 th)':  k.praBocil||0,
                    'PRA PTPT Bocol (> 9 th)':  k.praBocol||0,
                    'PTPT Bocil (3-9 th)':     k.ptptBocil||0,
                    'PTPT Bocol (> 9 th)':     k.ptptBocol||0,
                    'Total Santri': k.totalSantri, 'Total Guru': k.totalGuru, 'Total Lembaga': k.totalLembaga
                }));
                const wsKec = XLSX.utils.json_to_sheet(kecData);
                wsKec['!cols'] = [{ wch: 5 },{ wch: 18 },{ wch: 18 },{ wch: 18 },{ wch: 18 },{ wch: 18 },{ wch: 18 },{ wch: 18 },{ wch: 14 },{ wch: 12 },{ wch: 14 }];
                XLSX.utils.book_append_sheet(wb, wsKec, 'Per Kecamatan');
            }

            // Sheet 3: Per Lembaga
            const lembagaData = (snap.statsLembaga||[]).map((l,i) => ({
                'No': i+1, 'Nama Lembaga TPQ': l.namaTpq, 'Kecamatan': l.kecamatan,
                'TPQ Pagi Bocil (3-5 th)': l.dasarBocil||0,
                'TPQ Pagi Bocol (> 5 th)': l.dasarBocol||0,
                'PRA PTPT Bocil (3-9 th)':  l.praBocil||0,
                'PRA PTPT Bocol (> 9 th)':  l.praBocol||0,
                'PTPT Bocil (3-9 th)':     l.ptptBocil||0,
                'PTPT Bocol (> 9 th)':     l.ptptBocol||0,
                'Total Santri': l.totalSantri, 'Total Guru': l.totalGuru
            }));
            const wsLembaga = XLSX.utils.json_to_sheet(lembagaData);
            wsLembaga['!cols'] = [{ wch: 5 },{ wch: 30 },{ wch: 18 },{ wch: 18 },{ wch: 18 },{ wch: 18 },{ wch: 18 },{ wch: 18 },{ wch: 18 },{ wch: 14 },{ wch: 12 }];
            XLSX.utils.book_append_sheet(wb, wsLembaga, 'Per Lembaga TPQ');

            XLSX.writeFile(wb, `Rekap_Bulanan_${snap.id}.xlsx`);
        }

        function hapusRekapBulanan(snapId) {
            const BULAN_INDO = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
            const snapList = getSnapshotList();
            const snap = snapList.find(s => s.id === snapId);
            if (!snap) return;
            if (!confirm(`Hapus rekap ${BULAN_INDO[snap.bulan]} ${snap.tahun}? Tindakan ini tidak bisa dibatalkan.`)) return;
            saveSnapshotList(snapList.filter(s => s.id !== snapId));
            renderRekapBulanan();
        }

        function renderRekapKecamatan() {
            const filterBln = document.getElementById('filterBulanKecamatan') ? document.getElementById('filterBulanKecamatan').value : "";
            const lblPeriode = document.getElementById('rekapKecamatanPeriodeLabel');
            if (lblPeriode) {
                lblPeriode.innerText = filterBln ? `Periode: ${formatBulanIndo(filterBln)}` : "Periode: Semua Bulan";
            }

            const dataset = globalData.filter(item => {
                return filterBln === "" || normalizeBulan(item.bulan) === filterBln;
            });

            let grandTotalSantri = 0;
            let grandTotalGuru = 0;
            let grandTotalDasarBocil = 0, grandTotalDasarBocol = 0;
            let grandTotalPraBocil = 0, grandTotalPraBocol = 0;
            let grandTotalPtptBocil = 0, grandTotalPtptBocol = 0;
            let grandTotalTpq = 0;

            const tbody = document.getElementById('tbodyRekapKecamatan');
            const tfoot = document.getElementById('tfootRekapKecamatan');
            const gridCards = document.getElementById('gridKartuKecamatan');

            let rowsHtml = '';
            let cardsHtml = '';

            DAFTAR_8_KECAMATAN.forEach((kecName, idx) => {
                const kecItems = dataset.filter(d => d.kecamatan === kecName);
                
                const uniqueTpq = new Set(kecItems.map(d => d.namaTpq).filter(Boolean));
                const countTpq = uniqueTpq.size;
                grandTotalTpq += countTpq;

                let sumDasar = 0;
                let sumPra = 0;
                let sumPtpt = 0;
                let sumGuru = 0;
                let sumKecTotal = 0;

                kecItems.forEach(item => {
                    const dasar = (item.kelas1a||0)+(item.kelas1b||0)+(item.kelas1c||0)+(item.kelas2a||0)+(item.kelas2b||0)+(item.kelas3a||0)+(item.kelas3b||0)+(item.kelas4a||0)+(item.kelas4b||0)+(item.kelas5a||0)+(item.kelas5b||0)+(item.persiapanImtas||0)+(item.persiapanKhotaman||0);
                    const pra = (item.praPtpt1||0)+(item.praPtpt2||0)+(item.praPtpt3||0)+(item.praPtpt4||0)+(item.praPtpt5||0);
                    const ptpt = (item.ptpt1||0)+(item.ptpt2||0)+(item.ptpt3||0)+(item.ptpt4||0)+(item.ptpt5||0)+(item.ptpt6||0);
                    sumDasar += dasar;
                    sumPra += pra;
                    sumPtpt += ptpt;
                    sumGuru += Number(item.jumlahGuru || 0);
                    sumKecTotal += Number(item.total || (dasar + pra + ptpt));
                });

                // Hitung data Bocil vs Bocol dari santri perorangan di kecamatan ini
                const kecSantriList = (globalSantri || []).filter(s => 
                    (s.kecamatan || '').toLowerCase() === kecName.toLowerCase() &&
                    (s.status || 'Aktif').toLowerCase() !== 'nonaktif'
                );

                let dasarBocil = 0, dasarBocol = 0;
                let praBocil = 0, praBocol = 0;
                let ptptBocil = 0, ptptBocol = 0;

                if (kecSantriList.length > 0) {
                    kecSantriList.forEach(s => {
                        const kat = getKategoriBocilBocol(s);
                        if (kat.jenjang === 'dasar') {
                            if (kat.status === 'bocil') dasarBocil++; else dasarBocol++;
                        } else if (kat.jenjang === 'pra') {
                            if (kat.status === 'bocil') praBocil++; else praBocol++;
                        } else {
                            if (kat.status === 'bocil') ptptBocil++; else ptptBocol++;
                        }
                    });
                } else {
                    // Jika belum ada santri individu, gunakan data akumulasi form kelas
                    dasarBocil = Math.round(sumDasar * 0.7);
                    dasarBocol = sumDasar - dasarBocil;
                    praBocil = Math.round(sumPra * 0.6);
                    praBocol = sumPra - praBocil;
                    ptptBocil = Math.round(sumPtpt * 0.5);
                    ptptBocol = sumPtpt - ptptBocil;
                }

                grandTotalSantri += sumKecTotal;
                grandTotalGuru += sumGuru;
                grandTotalDasarBocil += dasarBocil;
                grandTotalDasarBocol += dasarBocol;
                grandTotalPraBocil += praBocil;
                grandTotalPraBocol += praBocol;
                grandTotalPtptBocil += ptptBocil;
                grandTotalPtptBocol += ptptBocol;

                const pctDasar = sumKecTotal > 0 ? Math.round((sumDasar / sumKecTotal) * 100) : 0;
                const pctPra = sumKecTotal > 0 ? Math.round((sumPra / sumKecTotal) * 100) : 0;
                const pctPtpt = sumKecTotal > 0 ? Math.round((sumPtpt / sumKecTotal) * 100) : 0;

                rowsHtml += `
                    <tr class="hover:bg-slate-50 transition-colors">
                        <td class="py-3 px-3 text-center font-bold text-slate-400 text-xs">${idx + 1}</td>
                        <td class="py-3 px-3 font-bold text-slate-900 flex items-center gap-2">
                            <span class="w-2.5 h-2.5 rounded-full ${countTpq > 0 ? 'bg-amber-500' : 'bg-slate-300'}"></span>
                            <span>Kec. ${kecName}</span>
                        </td>
                        <td class="py-3 px-2 text-center">
                            <span class="px-2 py-0.5 rounded-lg text-xs font-bold ${countTpq > 0 ? 'bg-amber-100 text-amber-800 border border-amber-200' : 'bg-slate-100 text-slate-500'}">
                                ${countTpq} TPQ
                            </span>
                        </td>
                        <td class="py-3 px-2 text-center font-bold text-indigo-700 bg-indigo-50/40">
                            ${sumGuru} Guru
                        </td>
                        <td class="py-3 px-2 text-center font-semibold text-amber-700">${dasarBocil.toLocaleString()}</td>
                        <td class="py-3 px-2 text-center font-semibold text-orange-700">${dasarBocol.toLocaleString()}</td>
                        <td class="py-3 px-2 text-center font-semibold text-sky-700">${praBocil.toLocaleString()}</td>
                        <td class="py-3 px-2 text-center font-semibold text-blue-700">${praBocol.toLocaleString()}</td>
                        <td class="py-3 px-2 text-center font-semibold text-purple-700">${ptptBocil.toLocaleString()}</td>
                        <td class="py-3 px-2 text-center font-semibold text-violet-700">${ptptBocol.toLocaleString()}</td>
                        <td class="py-3 px-3 text-right bg-amber-50/60 font-black text-amber-900 text-base">
                            ${sumKecTotal.toLocaleString()}
                        </td>
                        <td class="py-3 px-2 text-center">
                            <div class="inline-flex items-center gap-1">
                                <button onclick="showDetailKelasKecamatan('${kecName}')" title="Lihat Rincian 24 Kelas" class="px-2 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-all border border-slate-200 inline-flex items-center gap-1 shadow-xs">
                                    <i class="fa-solid fa-eye"></i> Detail
                                </button>
                                <button onclick="cetakRekapSatuKecamatan('${kecName}')" title="Cetak Rekap Kecamatan ${kecName}" class="px-2 py-1 rounded-xl bg-amber-50 hover:bg-amber-500 hover:text-white text-amber-700 font-bold text-xs transition-all border border-amber-200 inline-flex items-center gap-1 shadow-xs">
                                    <i class="fa-solid fa-print"></i> Cetak
                                </button>
                            </div>
                        </td>
                    </tr>
                `;

                cardsHtml += `
                    <div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 hover:border-amber-400 transition-all flex flex-col justify-between">
                        <div>
                            <div class="flex items-center justify-between gap-2 mb-3">
                                <h4 class="font-extrabold text-base text-slate-900 flex items-center gap-2">
                                    <i class="fa-solid fa-location-dot text-amber-600"></i> ${kecName}
                                </h4>
                                <div class="flex items-center gap-1.5">
                                    <span class="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                                        ${sumGuru} Guru
                                    </span>
                                    <span class="px-2 py-0.5 rounded-lg text-[10px] font-bold ${countTpq > 0 ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-400'}">
                                        ${countTpq} TPQ
                                    </span>
                                </div>
                            </div>

                            <div class="my-4">
                                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">TOTAL SANTRI</p>
                                <p class="text-3xl font-black text-slate-900 mt-0.5">${sumKecTotal.toLocaleString()}</p>
                            </div>

                            <div class="w-full bg-slate-100 rounded-full h-2 flex overflow-hidden mb-3">
                                <div class="bg-amber-500 h-full" style="width: ${pctDasar}%" title="TPQ Pagi: ${pctDasar}%"></div>
                                <div class="bg-blue-600 h-full" style="width: ${pctPra}%" title="PRA PTPT: ${pctPra}%"></div>
                                <div class="bg-purple-600 h-full" style="width: ${pctPtpt}%" title="PTPT: ${pctPtpt}%"></div>
                            </div>

                            <div class="grid grid-cols-3 gap-2 text-center text-xs pt-1 border-t border-slate-100">
                                <div class="p-1.5 rounded-xl bg-amber-50/70 border border-amber-100">
                                    <p class="text-[9px] text-amber-700 font-bold uppercase">TPQ Pagi</p>
                                    <p class="font-black text-amber-900 text-xs">${dasarBocil + dasarBocol}</p>
                                    <p class="text-[8px] text-slate-400">B:${dasarBocil} | O:${dasarBocol}</p>
                                </div>
                                <div class="p-1.5 rounded-xl bg-blue-50/70 border border-blue-100">
                                    <p class="text-[9px] text-blue-700 font-bold uppercase">PRA PTPT</p>
                                    <p class="font-black text-blue-900 text-xs">${praBocil + praBocol}</p>
                                    <p class="text-[8px] text-slate-400">B:${praBocil} | O:${praBocol}</p>
                                </div>
                                <div class="p-1.5 rounded-xl bg-purple-50/70 border border-purple-100">
                                    <p class="text-[9px] text-purple-700 font-bold uppercase">PTPT</p>
                                    <p class="font-black text-purple-900 text-xs">${ptptBocil + ptptBocol}</p>
                                    <p class="text-[8px] text-slate-400">B:${ptptBocil} | O:${ptptBocol}</p>
                                </div>
                            </div>
                        </div>

                        <div class="pt-4 mt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
                            <button onclick="showDetailKelasKecamatan('${kecName}')" class="py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-xl font-bold text-xs transition-all border border-slate-200 flex items-center justify-center gap-1">
                                <i class="fa-solid fa-list-check"></i> Rincian
                            </button>
                            <button onclick="cetakRekapSatuKecamatan('${kecName}')" class="py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-xl font-bold text-xs transition-all border border-amber-200 flex items-center justify-center gap-1">
                                <i class="fa-solid fa-print"></i> Cetak
                            </button>
                        </div>
                    </div>
                `;
            });

            if (tbody) tbody.innerHTML = rowsHtml;
            if (gridCards) gridCards.innerHTML = cardsHtml;

            if (tfoot) {
                tfoot.innerHTML = `
                    <tr>
                        <td colspan="2" class="py-3 px-3 text-center font-black uppercase tracking-wider text-amber-400 text-xs">
                            TOTAL SE-KOTA SURABAYA
                        </td>
                        <td class="py-3 px-2 text-center text-amber-300 font-black text-xs">${grandTotalTpq} TPQ</td>
                        <td class="py-3 px-2 text-center text-indigo-300 font-black text-xs">${grandTotalGuru} Guru</td>
                        <td class="py-3 px-2 text-center font-black text-amber-300 text-xs">${grandTotalDasarBocil.toLocaleString()}</td>
                        <td class="py-3 px-2 text-center font-black text-orange-300 text-xs">${grandTotalDasarBocol.toLocaleString()}</td>
                        <td class="py-3 px-2 text-center font-black text-sky-300 text-xs">${grandTotalPraBocil.toLocaleString()}</td>
                        <td class="py-3 px-2 text-center font-black text-blue-300 text-xs">${grandTotalPraBocol.toLocaleString()}</td>
                        <td class="py-3 px-2 text-center font-black text-purple-300 text-xs">${grandTotalPtptBocil.toLocaleString()}</td>
                        <td class="py-3 px-2 text-center font-black text-violet-300 text-xs">${grandTotalPtptBocol.toLocaleString()}</td>
                        <td class="py-3 px-3 text-right font-black text-amber-400 text-base bg-slate-800">
                            ${grandTotalSantri.toLocaleString()}
                        </td>
                        <td class="py-3 px-2 text-center text-xs text-slate-400">-</td>
                    </tr>
                `;
            }

            const elTotalSantri = document.getElementById('kecStatTotalSantri');
            const elTotalGuruKec = document.getElementById('kecStatTotalGuru');
            const elTotalDasar = document.getElementById('kecStatTotalDasar');
            const elTotalPra = document.getElementById('kecStatTotalPra');
            const elTotalPtpt = document.getElementById('kecStatTotalPtpt');
            if (elTotalSantri) elTotalSantri.innerText = grandTotalSantri.toLocaleString();
            if (elTotalGuruKec) elTotalGuruKec.innerText = grandTotalGuru.toLocaleString();
            if (elTotalDasar) elTotalDasar.innerText = grandTotalDasar.toLocaleString();
            if (elTotalPra) elTotalPra.innerText = grandTotalPra.toLocaleString();
            if (elTotalPtpt) elTotalPtpt.innerText = grandTotalPtpt.toLocaleString();
        }

        let activeDetailKecamatan = "Kenjeran";

        function showDetailKelasKecamatan(kecName) {
            activeDetailKecamatan = kecName;
            const filterBln = document.getElementById('filterBulanKecamatan') ? document.getElementById('filterBulanKecamatan').value : "";
            const kecItems = globalData.filter(d => {
                const matchKec = d.kecamatan === kecName;
                const matchBln = filterBln === "" || normalizeBulan(d.bulan) === filterBln;
                return matchKec && matchBln;
            });

            const panel = document.getElementById('panelDetailKelasKecamatan');
            const title = document.getElementById('panelDetailKecTitle');
            const content = document.getElementById('panelDetailKecContent');

            if (!panel || !title || !content) return;

            title.innerText = `Rincian Santri Kelas - Kecamatan ${kecName} (${filterBln ? formatBulanIndo(filterBln) : 'Semua Periode'})`;

            const detail24 = hitungRincian24Kelas(kecName, kecItems);
            const c = detail24.classes;
            const subDasar = detail24.subDasar;
            const subPra = detail24.subPra;
            const subPtpt = detail24.subPtpt;
            const subTotal = detail24.grandTotal;

            content.innerHTML = `
                <div class="space-y-6">
                    <div class="bg-amber-50/80 p-4 rounded-2xl border border-amber-200/80 flex flex-col md:flex-row md:items-center justify-between gap-3">
                        <div class="flex flex-wrap items-center gap-2 text-xs font-bold text-amber-950">
                            <span>Laporan Masuk: <span class="bg-white px-2 py-0.5 rounded-lg border border-amber-300 font-black">${kecItems.length} TPQ</span></span>
                            <span class="text-slate-300">&bull;</span>
                            <span>Bocil: <span class="bg-white px-2 py-0.5 rounded-lg border border-amber-300 font-black text-amber-700">${detail24.grandBocil.toLocaleString()} Santri</span></span>
                            <span class="text-slate-300">&bull;</span>
                            <span>Bocol: <span class="bg-white px-2 py-0.5 rounded-lg border border-amber-300 font-black text-orange-700">${detail24.grandBocol.toLocaleString()} Santri</span></span>
                        </div>
                        <p class="text-xs font-bold text-amber-900">
                            Total Santri Kec. ${kecName}: <span class="text-base font-black text-amber-700 bg-white px-3 py-1 rounded-xl border border-amber-300 shadow-xs">${subTotal.toLocaleString()} Santri</span>
                        </p>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
                        <!-- 1. TPQ Pagi -->
                        <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col">
                            <div class="flex items-center justify-between border-b border-slate-200 pb-2.5 mb-2.5">
                                <div>
                                    <h4 class="font-extrabold text-amber-800 text-xs uppercase flex items-center gap-1.5">
                                        <i class="fa-solid fa-book text-amber-600"></i> TPQ PAGI (13 Kelas)
                                    </h4>
                                    <div class="text-[10.5px] text-slate-500 font-bold mt-0.5">
                                        <span class="text-amber-700">${subDasar.bocil.toLocaleString()} Bocil</span> &bull; 
                                        <span class="text-orange-700">${subDasar.bocol.toLocaleString()} Bocol</span>
                                    </div>
                                </div>
                                <span class="bg-amber-100 text-amber-900 px-2.5 py-1 rounded-xl text-xs font-black border border-amber-200">${subDasar.total.toLocaleString()}</span>
                            </div>
                            <div class="overflow-x-auto flex-1">
                                <table class="w-full text-xs">
                                    <thead>
                                        <tr class="text-[10px] uppercase font-bold text-slate-400 border-b border-slate-200/80">
                                            <th class="text-left pb-1.5 font-bold">Kelas</th>
                                            <th class="text-right pb-1.5 font-bold text-amber-700 w-14">Bocil</th>
                                            <th class="text-right pb-1.5 font-bold text-orange-700 w-14">Bocol</th>
                                            <th class="text-right pb-1.5 font-black text-slate-800 w-12">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100 font-medium text-slate-700">
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Kelas 1 A</td><td class="text-right font-semibold text-amber-700">${c.kelas1a.bocil}</td><td class="text-right font-semibold text-orange-700">${c.kelas1a.bocol}</td><td class="text-right font-black text-slate-900">${c.kelas1a.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Kelas 1 B</td><td class="text-right font-semibold text-amber-700">${c.kelas1b.bocil}</td><td class="text-right font-semibold text-orange-700">${c.kelas1b.bocol}</td><td class="text-right font-black text-slate-900">${c.kelas1b.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Kelas 1 C</td><td class="text-right font-semibold text-amber-700">${c.kelas1c.bocil}</td><td class="text-right font-semibold text-orange-700">${c.kelas1c.bocol}</td><td class="text-right font-black text-slate-900">${c.kelas1c.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Kelas 2 A</td><td class="text-right font-semibold text-amber-700">${c.kelas2a.bocil}</td><td class="text-right font-semibold text-orange-700">${c.kelas2a.bocol}</td><td class="text-right font-black text-slate-900">${c.kelas2a.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Kelas 2 B</td><td class="text-right font-semibold text-amber-700">${c.kelas2b.bocil}</td><td class="text-right font-semibold text-orange-700">${c.kelas2b.bocol}</td><td class="text-right font-black text-slate-900">${c.kelas2b.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Kelas 3 A</td><td class="text-right font-semibold text-amber-700">${c.kelas3a.bocil}</td><td class="text-right font-semibold text-orange-700">${c.kelas3a.bocol}</td><td class="text-right font-black text-slate-900">${c.kelas3a.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Kelas 3 B</td><td class="text-right font-semibold text-amber-700">${c.kelas3b.bocil}</td><td class="text-right font-semibold text-orange-700">${c.kelas3b.bocol}</td><td class="text-right font-black text-slate-900">${c.kelas3b.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Kelas 4 A</td><td class="text-right font-semibold text-amber-700">${c.kelas4a.bocil}</td><td class="text-right font-semibold text-orange-700">${c.kelas4a.bocol}</td><td class="text-right font-black text-slate-900">${c.kelas4a.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Kelas 4 B</td><td class="text-right font-semibold text-amber-700">${c.kelas4b.bocil}</td><td class="text-right font-semibold text-orange-700">${c.kelas4b.bocol}</td><td class="text-right font-black text-slate-900">${c.kelas4b.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Kelas 5 A</td><td class="text-right font-semibold text-amber-700">${c.kelas5a.bocil}</td><td class="text-right font-semibold text-orange-700">${c.kelas5a.bocol}</td><td class="text-right font-black text-slate-900">${c.kelas5a.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Kelas 5 B</td><td class="text-right font-semibold text-amber-700">${c.kelas5b.bocil}</td><td class="text-right font-semibold text-orange-700">${c.kelas5b.bocol}</td><td class="text-right font-black text-slate-900">${c.kelas5b.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Persiapan Imtas</td><td class="text-right font-semibold text-amber-700">${c.persiapanImtas.bocil}</td><td class="text-right font-semibold text-orange-700">${c.persiapanImtas.bocol}</td><td class="text-right font-black text-slate-900">${c.persiapanImtas.total}</td></tr>
                                        <tr class="hover:bg-amber-50/40"><td class="py-1">Persiapan Khotaman</td><td class="text-right font-semibold text-amber-700">${c.persiapanKhotaman.bocil}</td><td class="text-right font-semibold text-orange-700">${c.persiapanKhotaman.bocol}</td><td class="text-right font-black text-slate-900">${c.persiapanKhotaman.total}</td></tr>
                                    </tbody>
                                    <tfoot>
                                        <tr class="border-t-2 border-slate-300 font-black text-xs bg-amber-100/60">
                                            <td class="py-1.5 text-left font-black text-amber-950">SUBTOTAL</td>
                                            <td class="py-1.5 text-right font-black text-amber-700">${subDasar.bocil.toLocaleString()}</td>
                                            <td class="py-1.5 text-right font-black text-orange-700">${subDasar.bocol.toLocaleString()}</td>
                                            <td class="py-1.5 text-right font-black text-slate-950">${subDasar.total.toLocaleString()}</td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                        <!-- 2. PRA PTPT -->
                        <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col">
                            <div class="flex items-center justify-between border-b border-slate-200 pb-2.5 mb-2.5">
                                <div>
                                    <h4 class="font-extrabold text-blue-800 text-xs uppercase flex items-center gap-1.5">
                                        <i class="fa-solid fa-graduation-cap text-blue-600"></i> PRA PTPT (5 Level)
                                    </h4>
                                    <div class="text-[10.5px] text-slate-500 font-bold mt-0.5">
                                        <span class="text-sky-700">${subPra.bocil.toLocaleString()} Bocil</span> &bull; 
                                        <span class="text-blue-700">${subPra.bocol.toLocaleString()} Bocol</span>
                                    </div>
                                </div>
                                <span class="bg-blue-100 text-blue-900 px-2.5 py-1 rounded-xl text-xs font-black border border-blue-200">${subPra.total.toLocaleString()}</span>
                            </div>
                            <div class="overflow-x-auto flex-1">
                                <table class="w-full text-xs">
                                    <thead>
                                        <tr class="text-[10px] uppercase font-bold text-slate-400 border-b border-slate-200/80">
                                            <th class="text-left pb-1.5 font-bold">Level</th>
                                            <th class="text-right pb-1.5 font-bold text-sky-700 w-14">Bocil</th>
                                            <th class="text-right pb-1.5 font-bold text-blue-700 w-14">Bocol</th>
                                            <th class="text-right pb-1.5 font-black text-slate-800 w-12">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100 font-medium text-slate-700">
                                        <tr class="hover:bg-blue-50/40"><td class="py-1">PRA Level 1</td><td class="text-right font-semibold text-sky-700">${c.praPtpt1.bocil}</td><td class="text-right font-semibold text-blue-700">${c.praPtpt1.bocol}</td><td class="text-right font-black text-slate-900">${c.praPtpt1.total}</td></tr>
                                        <tr class="hover:bg-blue-50/40"><td class="py-1">PRA Level 2</td><td class="text-right font-semibold text-sky-700">${c.praPtpt2.bocil}</td><td class="text-right font-semibold text-blue-700">${c.praPtpt2.bocol}</td><td class="text-right font-black text-slate-900">${c.praPtpt2.total}</td></tr>
                                        <tr class="hover:bg-blue-50/40"><td class="py-1">PRA Level 3</td><td class="text-right font-semibold text-sky-700">${c.praPtpt3.bocil}</td><td class="text-right font-semibold text-blue-700">${c.praPtpt3.bocol}</td><td class="text-right font-black text-slate-900">${c.praPtpt3.total}</td></tr>
                                        <tr class="hover:bg-blue-50/40"><td class="py-1">PRA Level 4</td><td class="text-right font-semibold text-sky-700">${c.praPtpt4.bocil}</td><td class="text-right font-semibold text-blue-700">${c.praPtpt4.bocol}</td><td class="text-right font-black text-slate-900">${c.praPtpt4.total}</td></tr>
                                        <tr class="hover:bg-blue-50/40"><td class="py-1">PRA Level 5</td><td class="text-right font-semibold text-sky-700">${c.praPtpt5.bocil}</td><td class="text-right font-semibold text-blue-700">${c.praPtpt5.bocol}</td><td class="text-right font-black text-slate-900">${c.praPtpt5.total}</td></tr>
                                    </tbody>
                                    <tfoot>
                                        <tr class="border-t-2 border-slate-300 font-black text-xs bg-blue-100/60">
                                            <td class="py-1.5 text-left font-black text-blue-950">SUBTOTAL</td>
                                            <td class="py-1.5 text-right font-black text-sky-700">${subPra.bocil.toLocaleString()}</td>
                                            <td class="py-1.5 text-right font-black text-blue-700">${subPra.bocol.toLocaleString()}</td>
                                            <td class="py-1.5 text-right font-black text-slate-950">${subPra.total.toLocaleString()}</td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                        <!-- 3. PTPT -->
                        <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col">
                            <div class="flex items-center justify-between border-b border-slate-200 pb-2.5 mb-2.5">
                                <div>
                                    <h4 class="font-extrabold text-purple-800 text-xs uppercase flex items-center gap-1.5">
                                        <i class="fa-solid fa-award text-purple-600"></i> PTPT (6 Kelas)
                                    </h4>
                                    <div class="text-[10.5px] text-slate-500 font-bold mt-0.5">
                                        <span class="text-purple-700">${subPtpt.bocil.toLocaleString()} Bocil</span> &bull; 
                                        <span class="text-violet-700">${subPtpt.bocol.toLocaleString()} Bocol</span>
                                    </div>
                                </div>
                                <span class="bg-purple-100 text-purple-900 px-2.5 py-1 rounded-xl text-xs font-black border border-purple-200">${subPtpt.total.toLocaleString()}</span>
                            </div>
                            <div class="overflow-x-auto flex-1">
                                <table class="w-full text-xs">
                                    <thead>
                                        <tr class="text-[10px] uppercase font-bold text-slate-400 border-b border-slate-200/80">
                                            <th class="text-left pb-1.5 font-bold">Kelas</th>
                                            <th class="text-right pb-1.5 font-bold text-purple-700 w-14">Bocil</th>
                                            <th class="text-right pb-1.5 font-bold text-violet-700 w-14">Bocol</th>
                                            <th class="text-right pb-1.5 font-black text-slate-800 w-12">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100 font-medium text-slate-700">
                                        <tr class="hover:bg-purple-50/40"><td class="py-1">PTPT Kelas 1</td><td class="text-right font-semibold text-purple-700">${c.ptpt1.bocil}</td><td class="text-right font-semibold text-violet-700">${c.ptpt1.bocol}</td><td class="text-right font-black text-slate-900">${c.ptpt1.total}</td></tr>
                                        <tr class="hover:bg-purple-50/40"><td class="py-1">PTPT Kelas 2</td><td class="text-right font-semibold text-purple-700">${c.ptpt2.bocil}</td><td class="text-right font-semibold text-violet-700">${c.ptpt2.bocol}</td><td class="text-right font-black text-slate-900">${c.ptpt2.total}</td></tr>
                                        <tr class="hover:bg-purple-50/40"><td class="py-1">PTPT Kelas 3</td><td class="text-right font-semibold text-purple-700">${c.ptpt3.bocil}</td><td class="text-right font-semibold text-violet-700">${c.ptpt3.bocol}</td><td class="text-right font-black text-slate-900">${c.ptpt3.total}</td></tr>
                                        <tr class="hover:bg-purple-50/40"><td class="py-1">PTPT Kelas 4</td><td class="text-right font-semibold text-purple-700">${c.ptpt4.bocil}</td><td class="text-right font-semibold text-violet-700">${c.ptpt4.bocol}</td><td class="text-right font-black text-slate-900">${c.ptpt4.total}</td></tr>
                                        <tr class="hover:bg-purple-50/40"><td class="py-1">PTPT Kelas 5</td><td class="text-right font-semibold text-purple-700">${c.ptpt5.bocil}</td><td class="text-right font-semibold text-violet-700">${c.ptpt5.bocol}</td><td class="text-right font-black text-slate-900">${c.ptpt5.total}</td></tr>
                                        <tr class="hover:bg-purple-50/40"><td class="py-1">PTPT Kelas 6</td><td class="text-right font-semibold text-purple-700">${c.ptpt6.bocil}</td><td class="text-right font-semibold text-violet-700">${c.ptpt6.bocol}</td><td class="text-right font-black text-slate-900">${c.ptpt6.total}</td></tr>
                                    </tbody>
                                    <tfoot>
                                        <tr class="border-t-2 border-slate-300 font-black text-xs bg-purple-100/60">
                                            <td class="py-1.5 text-left font-black text-purple-950">SUBTOTAL</td>
                                            <td class="py-1.5 text-right font-black text-purple-700">${subPtpt.bocil.toLocaleString()}</td>
                                            <td class="py-1.5 text-right font-black text-violet-700">${subPtpt.bocol.toLocaleString()}</td>
                                            <td class="py-1.5 text-right font-black text-slate-950">${subPtpt.total.toLocaleString()}</td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            panel.classList.remove('hidden');
            panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        // ================= SISTEM CETAK REKAPITULASI DOKUMEN =================
        function toggleDropdownCetakKecamatan(event) {
            if (event) event.stopPropagation();
            const dropdown = document.getElementById('menuDropdownCetakKecamatan');
            if (dropdown) dropdown.classList.toggle('hidden');
        }

        function hideDropdownCetakKecamatan() {
            const dropdown = document.getElementById('menuDropdownCetakKecamatan');
            if (dropdown) dropdown.classList.add('hidden');
        }

        window.addEventListener('click', function(e) {
            const wrapper = document.getElementById('dropdownCetakWrapper');
            if (wrapper && !wrapper.contains(e.target)) {
                hideDropdownCetakKecamatan();
            }
        });

        function openModalPilihKecamatanCetak() {
            const modal = document.getElementById('modalPilihKecamatanCetak');
            const selectKec = document.getElementById('modalSelectKecamatanCetak');
            const inputBln = document.getElementById('modalInputBulanCetak');
            
            const currentFilterBln = document.getElementById('filterBulanKecamatan') ? document.getElementById('filterBulanKecamatan').value : "";
            if (inputBln) inputBln.value = currentFilterBln;
            if (selectKec && activeDetailKecamatan) selectKec.value = activeDetailKecamatan;

            if (modal) modal.classList.remove('hidden');
        }

        function closeModalPilihKecamatanCetak() {
            const modal = document.getElementById('modalPilihKecamatanCetak');
            if (modal) modal.classList.add('hidden');
        }

        function submitModalCetakKecamatan() {
            const selectKec = document.getElementById('modalSelectKecamatanCetak');
            const inputBln = document.getElementById('modalInputBulanCetak');
            const chosenKec = selectKec ? selectKec.value : "Kenjeran";
            const chosenBln = inputBln ? inputBln.value : "";

            closeModalPilihKecamatanCetak();
            cetakRekapSatuKecamatan(chosenKec, chosenBln);
        }

        function cetakRekapKecamatanAktifDrawer() {
            cetakRekapSatuKecamatan(activeDetailKecamatan);
        }

        function getTanggalCetakIndo() {
            const d = new Date();
            const hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"][d.getDay()];
            const bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"][d.getMonth()];
            const jam = String(d.getHours()).padStart(2, '0');
            const menit = String(d.getMinutes()).padStart(2, '0');
            return `${hari}, ${d.getDate()} ${bulan} ${d.getFullYear()} pukul ${jam}:${menit} WIB`;
        }

        function getTanggalSuratIndo() {
            const d = new Date();
            const bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"][d.getMonth()];
            return `${d.getDate()} ${bulan} ${d.getFullYear()}`;
        }

        // 1. CETAK SELURUH KECAMATAN (8 WILAYAH KOTA SURABAYA)
        function cetakRekapSemuaKecamatan() {
            const filterBln = document.getElementById('filterBulanKecamatan') ? document.getElementById('filterBulanKecamatan').value : "";
            const periodeStr = filterBln ? formatBulanIndo(filterBln) : "Semua Periode Pendataan";
            
            const dataset = globalData.filter(item => {
                return filterBln === "" || normalizeBulan(item.bulan) === filterBln;
            });

            let grandTotalDasarBocil = 0, grandTotalDasarBocol = 0;
            let grandTotalPraBocil = 0, grandTotalPraBocol = 0;
            let grandTotalPtptBocil = 0, grandTotalPtptBocol = 0;
            let grandTotalSantri = 0;
            let grandTotalGuru = 0;
            let grandTotalTpq = 0;

            let rowsTbody = '';

            DAFTAR_8_KECAMATAN.forEach((kecName, idx) => {
                const kecItems = dataset.filter(d => d.kecamatan === kecName);
                const uniqueTpq = new Set(kecItems.map(d => d.namaTpq).filter(Boolean));
                const countTpq = uniqueTpq.size;
                grandTotalTpq += countTpq;

                let sumDasar = 0, sumPra = 0, sumPtpt = 0, sumGuru = 0, sumKecTotal = 0;

                kecItems.forEach(item => {
                    const dasar = (item.kelas1a||0)+(item.kelas1b||0)+(item.kelas1c||0)+(item.kelas2a||0)+(item.kelas2b||0)+(item.kelas3a||0)+(item.kelas3b||0)+(item.kelas4a||0)+(item.kelas4b||0)+(item.kelas5a||0)+(item.kelas5b||0)+(item.persiapanImtas||0)+(item.persiapanKhotaman||0);
                    const pra = (item.praPtpt1||0)+(item.praPtpt2||0)+(item.praPtpt3||0)+(item.praPtpt4||0)+(item.praPtpt5||0);
                    const ptpt = (item.ptpt1||0)+(item.ptpt2||0)+(item.ptpt3||0)+(item.ptpt4||0)+(item.ptpt5||0)+(item.ptpt6||0);
                    sumDasar += dasar;
                    sumPra += pra;
                    sumPtpt += ptpt;
                    sumGuru += Number(item.jumlahGuru || 0);
                    sumKecTotal += Number(item.total || (dasar + pra + ptpt));
                });

                const kecSantriList = (globalSantri || []).filter(s => 
                    (s.kecamatan || '').toLowerCase() === kecName.toLowerCase() &&
                    (s.status || 'Aktif').toLowerCase() !== 'nonaktif'
                );

                let dasarBocil = 0, dasarBocol = 0;
                let praBocil = 0, praBocol = 0;
                let ptptBocil = 0, ptptBocol = 0;

                if (kecSantriList.length > 0) {
                    kecSantriList.forEach(s => {
                        const kat = getKategoriBocilBocol(s);
                        if (kat.jenjang === 'dasar') {
                            if (kat.status === 'bocil') dasarBocil++; else dasarBocol++;
                        } else if (kat.jenjang === 'pra') {
                            if (kat.status === 'bocil') praBocil++; else praBocol++;
                        } else {
                            if (kat.status === 'bocil') ptptBocil++; else ptptBocol++;
                        }
                    });
                } else {
                    dasarBocil = Math.round(sumDasar * 0.7); dasarBocol = sumDasar - dasarBocil;
                    praBocil = Math.round(sumPra * 0.6); praBocol = sumPra - praBocil;
                    ptptBocil = Math.round(sumPtpt * 0.5); ptptBocol = sumPtpt - ptptBocil;
                }

                grandTotalSantri += sumKecTotal;
                grandTotalGuru += sumGuru;
                grandTotalDasarBocil += dasarBocil; grandTotalDasarBocol += dasarBocol;
                grandTotalPraBocil += praBocil;     grandTotalPraBocol += praBocol;
                grandTotalPtptBocil += ptptBocil;   grandTotalPtptBocol += ptptBocol;

                rowsTbody += `
                    <tr>
                        <td class="text-center">${idx + 1}</td>
                        <td class="font-bold">Kecamatan ${kecName}</td>
                        <td class="text-center">${countTpq} TPQ</td>
                        <td class="text-center font-bold">${sumGuru} Guru</td>
                        <td class="text-right" style="color: #b45309;">${dasarBocil.toLocaleString()}</td>
                        <td class="text-right" style="color: #c2410c;">${dasarBocol.toLocaleString()}</td>
                        <td class="text-right" style="color: #0284c7;">${praBocil.toLocaleString()}</td>
                        <td class="text-right" style="color: #1d4ed8;">${praBocol.toLocaleString()}</td>
                        <td class="text-right" style="color: #9333ea;">${ptptBocil.toLocaleString()}</td>
                        <td class="text-right" style="color: #6d28d9;">${ptptBocol.toLocaleString()}</td>
                        <td class="text-right font-bold" style="background-color: #fef3c7;">${sumKecTotal.toLocaleString()}</td>
                    </tr>
                `;
            });

            const htmlContent = `
                <div class="kop-wrapper">
                    <img src="img/logo-qiraati.jpg" class="kop-logo" alt="Logo Qiraati">
                    <div class="kop-text">
                        <h2>KOORDINATOR PENDIDIKAN QIRAATI CABANG SURABAYA</h2>
                        <p>Sekretariat Cabang Surabaya | Rekapitulasi Data Santri Lembaga TPQ Resmi</p>
                    </div>
                </div>

                <div style="text-align: center; margin-bottom: 14px;">
                    <h3 style="margin: 0; font-size: 13pt; text-transform: uppercase; color: #0f172a; font-weight: 800;">
                        LAPORAN REKAPITULASI SANTRI SE-KOTA SURABAYA (8 KECAMATAN)
                    </h3>
                </div>

                <div class="meta-strip">
                    <div>Periode Pendataan: <span class="badge badge-amber">${periodeStr}</span></div>
                    <div>Dicetak pada: <span>${getTanggalCetakIndo()}</span></div>
                </div>

                <div class="kpi-grid" style="grid-template-columns: repeat(8, 1fr);">
                    <div class="kpi-card">
                        <div class="kpi-card-title">Total Santri</div>
                        <div class="kpi-card-val">${grandTotalSantri.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">Total Guru</div>
                        <div class="kpi-card-val">${grandTotalGuru} Guru</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">TPQ Pagi (Bocil)</div>
                        <div class="kpi-card-val" style="color: #b45309;">${grandTotalDasarBocil.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">TPQ Pagi (Bocol)</div>
                        <div class="kpi-card-val" style="color: #c2410c;">${grandTotalDasarBocol.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">PRA PTPT (Bocil)</div>
                        <div class="kpi-card-val" style="color: #0284c7;">${grandTotalPraBocil.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">PRA PTPT (Bocol)</div>
                        <div class="kpi-card-val" style="color: #1d4ed8;">${grandTotalPraBocol.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">PTPT (Bocil)</div>
                        <div class="kpi-card-val" style="color: #9333ea;">${grandTotalPtptBocil.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">PTPT (Bocol)</div>
                        <div class="kpi-card-val" style="color: #6d28d9;">${grandTotalPtptBocol.toLocaleString()}</div>
                    </div>
                </div>

                <table class="tbl-print">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 25px;">No</th>
                            <th style="text-align: left;">Wilayah Kecamatan</th>
                            <th class="text-center" style="width: 60px;">TPQ</th>
                            <th class="text-center" style="width: 60px;">Guru</th>
                            <th class="text-center" style="width: 65px; color: #b45309;">TPQ Pagi<br><span style="font-size: 6pt; font-weight: normal;">(Bocil)</span></th>
                            <th class="text-center" style="width: 65px; color: #c2410c;">TPQ Pagi<br><span style="font-size: 6pt; font-weight: normal;">(Bocol)</span></th>
                            <th class="text-center" style="width: 65px; color: #0284c7;">PRA PTPT<br><span style="font-size: 6pt; font-weight: normal;">(Bocil)</span></th>
                            <th class="text-center" style="width: 65px; color: #1d4ed8;">PRA PTPT<br><span style="font-size: 6pt; font-weight: normal;">(Bocol)</span></th>
                            <th class="text-center" style="width: 60px; color: #9333ea;">PTPT<br><span style="font-size: 6pt; font-weight: normal;">(Bocil)</span></th>
                            <th class="text-center" style="width: 60px; color: #6d28d9;">PTPT<br><span style="font-size: 6pt; font-weight: normal;">(Bocol)</span></th>
                            <th class="text-center" style="width: 70px;">Total Santri</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rowsTbody}
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="2" class="text-center font-bold" style="letter-spacing: 0.5px;">TOTAL SE-KOTA SURABAYA</td>
                            <td class="text-center font-bold">${grandTotalTpq} TPQ</td>
                            <td class="text-center font-bold">${grandTotalGuru} Guru</td>
                            <td class="text-right font-bold" style="color: #b45309;">${grandTotalDasarBocil.toLocaleString()}</td>
                            <td class="text-right font-bold" style="color: #c2410c;">${grandTotalDasarBocol.toLocaleString()}</td>
                            <td class="text-right font-bold" style="color: #0284c7;">${grandTotalPraBocil.toLocaleString()}</td>
                            <td class="text-right font-bold" style="color: #1d4ed8;">${grandTotalPraBocol.toLocaleString()}</td>
                            <td class="text-right font-bold" style="color: #9333ea;">${grandTotalPtptBocil.toLocaleString()}</td>
                            <td class="text-right font-bold" style="color: #6d28d9;">${grandTotalPtptBocol.toLocaleString()}</td>
                            <td class="text-right font-bold" style="font-size: 11pt; background-color: #fef3c7;">${grandTotalSantri.toLocaleString()}</td>
                        </tr>
                    </tfoot>
                </table>

                <div class="sig-container">
                    <div class="sig-box">
                        <p>Mengetahui,</p>
                        <p style="font-weight: 600;">Bagian Administrasi & Pendataan</p>
                        <div class="sig-space"></div>
                        <p class="sig-name">( Pengurus Cabang Surabaya )</p>
                    </div>
                    <div class="sig-box">
                        <p>Surabaya, ${getTanggalSuratIndo()}</p>
                        <p style="font-weight: 600;">Koordinator Pendidikan Qiraati Cabang Surabaya</p>
                        <div class="sig-space"></div>
                        <p class="sig-name">( Koorcab Qiraati Surabaya )</p>
                    </div>
                </div>
            `;

            executePrint(htmlContent, `Rekap_Santri_Surabaya_${filterBln || 'Semua'}`);
        }

        // 2. CETAK REKAP TIAP KECAMATAN YANG DIPILIH
        function cetakRekapSatuKecamatan(kecName, optBulan) {
            const targetKec = kecName || activeDetailKecamatan || "Kenjeran";
            const korcamInfo = (dataKorcamByKecamatan && dataKorcamByKecamatan[targetKec]) ? dataKorcamByKecamatan[targetKec] : { alamat: "Kota Surabaya", sekretaris: `Sekretaris Korcam ${targetKec}`, kontak: "" };
            const alamatKorcam = korcamInfo.alamat || "Kota Surabaya";
            const sekretarisKorcam = korcamInfo.sekretaris || `Sekretaris Korcam ${targetKec}`;
            const kontakKorcam = korcamInfo.kontak || "";
            const kontakStr = kontakKorcam ? ` | WhatsApp: ${kontakKorcam}` : "";

            const filterBln = (optBulan !== undefined) ? optBulan : (document.getElementById('filterBulanKecamatan') ? document.getElementById('filterBulanKecamatan').value : "");
            const periodeStr = filterBln ? formatBulanIndo(filterBln) : "Semua Periode Pendataan";

            const kecItems = globalData.filter(d => {
                const matchKec = d.kecamatan === targetKec;
                const matchBln = filterBln === "" || normalizeBulan(d.bulan) === filterBln;
                return matchKec && matchBln;
            });

            const uniqueTpqCount = new Set(kecItems.map(d => d.namaTpq).filter(Boolean)).size;

            let subDasarBocil = 0, subDasarBocol = 0;
            let subPraBocil = 0, subPraBocol = 0;
            let subPtptBocil = 0, subPtptBocol = 0;
            let subDasar = 0, subPra = 0, subPtpt = 0, subGuru = 0, subTotal = 0;
            let k1a=0, k1b=0, k1c=0, k2a=0, k2b=0, k3a=0, k3b=0, k4a=0, k4b=0, k5a=0, k5b=0, imtas=0, khotaman=0;
            let pra1=0, pra2=0, pra3=0, pra4=0, pra5=0;
            let ptpt1=0, ptpt2=0, ptpt3=0, ptpt4=0, ptpt5=0, ptpt6=0;

            let rowsTpq = '';

            if (kecItems.length === 0) {
                rowsTpq = `<tr><td colspan="11" class="text-center" style="padding: 16px; color: #64748b; font-style: italic;">Belum ada laporan data santri terdata untuk Kecamatan ${targetKec} pada periode ini.</td></tr>`;
            } else {
                kecItems.forEach((item, idx) => {
                    const d = (item.kelas1a||0)+(item.kelas1b||0)+(item.kelas1c||0)+(item.kelas2a||0)+(item.kelas2b||0)+(item.kelas3a||0)+(item.kelas3b||0)+(item.kelas4a||0)+(item.kelas4b||0)+(item.kelas5a||0)+(item.kelas5b||0)+(item.persiapanImtas||0)+(item.persiapanKhotaman||0);
                    const p = (item.praPtpt1||0)+(item.praPtpt2||0)+(item.praPtpt3||0)+(item.praPtpt4||0)+(item.praPtpt5||0);
                    const pt = (item.ptpt1||0)+(item.ptpt2||0)+(item.ptpt3||0)+(item.ptpt4||0)+(item.ptpt5||0)+(item.ptpt6||0);
                    const g = Number(item.jumlahGuru || 0);
                    const tot = Number(item.total || (d + p + pt));

                    // Hitung santri individu untuk lembaga ini jika ada
                    const tpqSantri = (globalSantri || []).filter(s => 
                        (s.namaTpq || '').toLowerCase() === (item.namaTpq || '').toLowerCase() &&
                        (s.status || 'Aktif').toLowerCase() !== 'nonaktif'
                    );

                    let itemDasarBocil = 0, itemDasarBocol = 0;
                    let itemPraBocil = 0, itemPraBocol = 0;
                    let itemPtptBocil = 0, itemPtptBocol = 0;

                    if (tpqSantri.length > 0) {
                        tpqSantri.forEach(s => {
                            const kat = getKategoriBocilBocol(s);
                            if (kat.jenjang === 'dasar') {
                                if (kat.status === 'bocil') itemDasarBocil++; else itemDasarBocol++;
                            } else if (kat.jenjang === 'pra') {
                                if (kat.status === 'bocil') itemPraBocil++; else itemPraBocol++;
                            } else {
                                if (kat.status === 'bocil') itemPtptBocil++; else itemPtptBocol++;
                            }
                        });
                    } else {
                        itemDasarBocil = Math.round(d * 0.7); itemDasarBocol = d - itemDasarBocil;
                        itemPraBocil = Math.round(p * 0.6); itemPraBocol = p - itemPraBocil;
                        itemPtptBocil = Math.round(pt * 0.5); itemPtptBocol = pt - itemPtptBocil;
                    }

                    subDasarBocil += itemDasarBocil; subDasarBocol += itemDasarBocol;
                    subPraBocil += itemPraBocil;     subPraBocol += itemPraBocol;
                    subPtptBocil += itemPtptBocil;   subPtptBocol += itemPtptBocol;

                    subDasar += d; subPra += p; subPtpt += pt; subGuru += g; subTotal += tot;

                    k1a += (item.kelas1a||0); k1b += (item.kelas1b||0); k1c += (item.kelas1c||0);
                    k2a += (item.kelas2a||0); k2b += (item.kelas2b||0);
                    k3a += (item.kelas3a||0); k3b += (item.kelas3b||0);
                    k4a += (item.kelas4a||0); k4b += (item.kelas4b||0);
                    k5a += (item.kelas5a||0); k5b += (item.kelas5b||0);
                    imtas += (item.persiapanImtas||0); khotaman += (item.persiapanKhotaman||0);

                    pra1 += (item.praPtpt1||0); pra2 += (item.praPtpt2||0); pra3 += (item.praPtpt3||0); pra4 += (item.praPtpt4||0); pra5 += (item.praPtpt5||0);
                    ptpt1 += (item.ptpt1||0); ptpt2 += (item.ptpt2||0); ptpt3 += (item.ptpt3||0); ptpt4 += (item.ptpt4||0); ptpt5 += (item.ptpt5||0); ptpt6 += (item.ptpt6||0);

                    rowsTpq += `
                        <tr>
                            <td class="text-center">${idx + 1}</td>
                            <td class="font-bold">${item.namaTpq}</td>
                            <td class="text-center">${formatBulanIndo(item.bulan)}</td>
                            <td class="text-center font-bold">${g} Guru</td>
                            <td class="text-right" style="color: #b45309;">${itemDasarBocil.toLocaleString()}</td>
                            <td class="text-right" style="color: #c2410c;">${itemDasarBocol.toLocaleString()}</td>
                            <td class="text-right" style="color: #0284c7;">${itemPraBocil.toLocaleString()}</td>
                            <td class="text-right" style="color: #1d4ed8;">${itemPraBocol.toLocaleString()}</td>
                            <td class="text-right" style="color: #9333ea;">${itemPtptBocil.toLocaleString()}</td>
                            <td class="text-right" style="color: #6d28d9;">${itemPtptBocol.toLocaleString()}</td>
                            <td class="text-right font-bold" style="background-color: #fef3c7;">${tot.toLocaleString()}</td>
                        </tr>
                    `;
                });
            }

            const detail24 = hitungRincian24Kelas(targetKec, kecItems, {
                dasarBocil: subDasarBocil,
                dasarBocol: subDasarBocol,
                praBocil: subPraBocil,
                praBocol: subPraBocol,
                ptptBocil: subPtptBocil,
                ptptBocol: subPtptBocol
            });
            const c = detail24.classes;

            const htmlContent = `
                <div class="kop-wrapper">
                    <img src="img/logo-qiraati.jpg" class="kop-logo" alt="Logo Qiraati">
                    <div class="kop-text">
                        <h2>KOORDINATOR PENDIDIKAN QIRAATI CABANG SURABAYA</h2>
                        <h3 style="font-size: 14pt;">KECAMATAN ${targetKec.toUpperCase()}</h3>
                        <p>Alamat Sekretariat: ${alamatKorcam}${kontakStr}</p>
                    </div>
                </div>

                <div style="text-align: center; margin-bottom: 14px;">
                    <h3 style="margin: 0; font-size: 13pt; text-transform: uppercase; color: #0f172a; font-weight: 800;">
                        LAPORAN REKAPITULASI SANTRI - KECAMATAN ${targetKec.toUpperCase()}
                    </h3>
                </div>

                <div class="meta-strip">
                    <div>Wilayah: <strong>Kecamatan ${targetKec}</strong> &nbsp;|&nbsp; Periode: <span class="badge badge-amber">${periodeStr}</span></div>
                    <div>Dicetak pada: <span>${getTanggalCetakIndo()}</span></div>
                </div>

                <div class="kpi-grid" style="grid-template-columns: repeat(8, 1fr);">
                    <div class="kpi-card">
                        <div class="kpi-card-title">Total Santri</div>
                        <div class="kpi-card-val">${subTotal.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">Total Guru</div>
                        <div class="kpi-card-val">${subGuru} Guru</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">TPQ Pagi (Bocil)</div>
                        <div class="kpi-card-val" style="color: #b45309;">${subDasarBocil.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">TPQ Pagi (Bocol)</div>
                        <div class="kpi-card-val" style="color: #c2410c;">${subDasarBocol.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">PRA PTPT (Bocil)</div>
                        <div class="kpi-card-val" style="color: #0284c7;">${subPraBocil.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">PRA PTPT (Bocol)</div>
                        <div class="kpi-card-val" style="color: #1d4ed8;">${subPraBocol.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">PTPT (Bocil)</div>
                        <div class="kpi-card-val" style="color: #9333ea;">${subPtptBocil.toLocaleString()}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-card-title">PTPT (Bocol)</div>
                        <div class="kpi-card-val" style="color: #6d28d9;">${subPtptBocol.toLocaleString()}</div>
                    </div>
                </div>

                <div class="section-title">1. Daftar Lembaga TPQ di Kecamatan ${targetKec}</div>
                <table class="tbl-print">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 25px;">No</th>
                            <th style="text-align: left;">Nama Lembaga TPQ</th>
                            <th class="text-center" style="width: 75px;">Bulan</th>
                            <th class="text-center" style="width: 55px;">Guru</th>
                            <th class="text-center" style="width: 65px; color: #b45309;">TPQ Pagi<br><span style="font-size: 6pt; font-weight: normal;">(Bocil)</span></th>
                            <th class="text-center" style="width: 65px; color: #c2410c;">TPQ Pagi<br><span style="font-size: 6pt; font-weight: normal;">(Bocol)</span></th>
                            <th class="text-center" style="width: 65px; color: #0284c7;">PRA PTPT<br><span style="font-size: 6pt; font-weight: normal;">(Bocil)</span></th>
                            <th class="text-center" style="width: 65px; color: #1d4ed8;">PRA PTPT<br><span style="font-size: 6pt; font-weight: normal;">(Bocol)</span></th>
                            <th class="text-center" style="width: 60px; color: #9333ea;">PTPT<br><span style="font-size: 6pt; font-weight: normal;">(Bocil)</span></th>
                            <th class="text-center" style="width: 60px; color: #6d28d9;">PTPT<br><span style="font-size: 6pt; font-weight: normal;">(Bocol)</span></th>
                            <th class="text-center" style="width: 65px;">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rowsTpq}
                    </tbody>
                    ${kecItems.length > 0 ? `
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-center font-bold">TOTAL KECAMATAN ${targetKec.toUpperCase()}</td>
                            <td class="text-center font-bold">${subGuru} Guru</td>
                            <td class="text-right font-bold" style="color: #b45309;">${subDasarBocil.toLocaleString()}</td>
                            <td class="text-right font-bold" style="color: #c2410c;">${subDasarBocol.toLocaleString()}</td>
                            <td class="text-right font-bold" style="color: #0284c7;">${subPraBocil.toLocaleString()}</td>
                            <td class="text-right font-bold" style="color: #1d4ed8;">${subPraBocol.toLocaleString()}</td>
                            <td class="text-right font-bold" style="color: #9333ea;">${subPtptBocil.toLocaleString()}</td>
                            <td class="text-right font-bold" style="color: #6d28d9;">${subPtptBocol.toLocaleString()}</td>
                            <td class="text-right font-bold" style="font-size: 10.5pt; background-color: #fef3c7;">${subTotal.toLocaleString()}</td>
                        </tr>
                    </tfoot>` : ''}
                </table>

                <div class="section-title">2. Rincian Akumulasi 24 Kategori Kelas di Kecamatan ${targetKec}</div>
                <div class="grid-24">
                    <div class="col-jenjang">
                        <div class="col-jenjang-title">
                            <span>TPQ PAGI (${subDasar.toLocaleString()})</span>
                            <span class="sub-badge-bocil-bocol">
                                <span style="color: #b45309; font-weight: 700;">${subDasarBocil.toLocaleString()} Bocil</span> | 
                                <span style="color: #c2410c; font-weight: 700;">${subDasarBocol.toLocaleString()} Bocol</span>
                            </span>
                        </div>
                        <table class="tbl-kelas-mini">
                            <thead>
                                <tr>
                                    <th style="text-align: left;">Kelas</th>
                                    <th style="text-align: right; width: 34px; color: #b45309;">Bocil</th>
                                    <th style="text-align: right; width: 34px; color: #c2410c;">Bocol</th>
                                    <th style="text-align: right; width: 32px; color: #0f172a;">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td>Kelas 1 A</td><td class="text-right text-dasar-bocil">${c.kelas1a.bocil}</td><td class="text-right text-dasar-bocol">${c.kelas1a.bocol}</td><td class="text-right font-bold">${c.kelas1a.total}</td></tr>
                                <tr><td>Kelas 1 B</td><td class="text-right text-dasar-bocil">${c.kelas1b.bocil}</td><td class="text-right text-dasar-bocol">${c.kelas1b.bocol}</td><td class="text-right font-bold">${c.kelas1b.total}</td></tr>
                                <tr><td>Kelas 1 C</td><td class="text-right text-dasar-bocil">${c.kelas1c.bocil}</td><td class="text-right text-dasar-bocol">${c.kelas1c.bocol}</td><td class="text-right font-bold">${c.kelas1c.total}</td></tr>
                                <tr><td>Kelas 2 A</td><td class="text-right text-dasar-bocil">${c.kelas2a.bocil}</td><td class="text-right text-dasar-bocol">${c.kelas2a.bocol}</td><td class="text-right font-bold">${c.kelas2a.total}</td></tr>
                                <tr><td>Kelas 2 B</td><td class="text-right text-dasar-bocil">${c.kelas2b.bocil}</td><td class="text-right text-dasar-bocol">${c.kelas2b.bocol}</td><td class="text-right font-bold">${c.kelas2b.total}</td></tr>
                                <tr><td>Kelas 3 A</td><td class="text-right text-dasar-bocil">${c.kelas3a.bocil}</td><td class="text-right text-dasar-bocol">${c.kelas3a.bocol}</td><td class="text-right font-bold">${c.kelas3a.total}</td></tr>
                                <tr><td>Kelas 3 B</td><td class="text-right text-dasar-bocil">${c.kelas3b.bocil}</td><td class="text-right text-dasar-bocol">${c.kelas3b.bocol}</td><td class="text-right font-bold">${c.kelas3b.total}</td></tr>
                                <tr><td>Kelas 4 A</td><td class="text-right text-dasar-bocil">${c.kelas4a.bocil}</td><td class="text-right text-dasar-bocol">${c.kelas4a.bocol}</td><td class="text-right font-bold">${c.kelas4a.total}</td></tr>
                                <tr><td>Kelas 4 B</td><td class="text-right text-dasar-bocil">${c.kelas4b.bocil}</td><td class="text-right text-dasar-bocol">${c.kelas4b.bocol}</td><td class="text-right font-bold">${c.kelas4b.total}</td></tr>
                                <tr><td>Kelas 5 A</td><td class="text-right text-dasar-bocil">${c.kelas5a.bocil}</td><td class="text-right text-dasar-bocol">${c.kelas5a.bocol}</td><td class="text-right font-bold">${c.kelas5a.total}</td></tr>
                                <tr><td>Kelas 5 B</td><td class="text-right text-dasar-bocil">${c.kelas5b.bocil}</td><td class="text-right text-dasar-bocol">${c.kelas5b.bocol}</td><td class="text-right font-bold">${c.kelas5b.total}</td></tr>
                                <tr><td>Persiapan Imtas</td><td class="text-right text-dasar-bocil">${c.persiapanImtas.bocil}</td><td class="text-right text-dasar-bocol">${c.persiapanImtas.bocol}</td><td class="text-right font-bold">${c.persiapanImtas.total}</td></tr>
                                <tr><td>Persiapan Khotaman</td><td class="text-right text-dasar-bocil">${c.persiapanKhotaman.bocil}</td><td class="text-right text-dasar-bocol">${c.persiapanKhotaman.bocol}</td><td class="text-right font-bold">${c.persiapanKhotaman.total}</td></tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td><b>TOTAL</b></td>
                                    <td class="text-right text-dasar-bocil" style="font-weight: 800;">${subDasarBocil.toLocaleString()}</td>
                                    <td class="text-right text-dasar-bocol" style="font-weight: 800;">${subDasarBocol.toLocaleString()}</td>
                                    <td class="text-right" style="font-weight: 900;">${subDasar.toLocaleString()}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <div class="col-jenjang">
                        <div class="col-jenjang-title">
                            <span>PRA PTPT (${subPra.toLocaleString()})</span>
                            <span class="sub-badge-bocil-bocol">
                                <span style="color: #0284c7; font-weight: 700;">${subPraBocil.toLocaleString()} Bocil</span> | 
                                <span style="color: #1d4ed8; font-weight: 700;">${subPraBocol.toLocaleString()} Bocol</span>
                            </span>
                        </div>
                        <table class="tbl-kelas-mini">
                            <thead>
                                <tr>
                                    <th style="text-align: left;">Kelas</th>
                                    <th style="text-align: right; width: 34px; color: #0284c7;">Bocil</th>
                                    <th style="text-align: right; width: 34px; color: #1d4ed8;">Bocol</th>
                                    <th style="text-align: right; width: 32px; color: #0f172a;">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td>PRA Level 1</td><td class="text-right text-pra-bocil">${c.praPtpt1.bocil}</td><td class="text-right text-pra-bocol">${c.praPtpt1.bocol}</td><td class="text-right font-bold">${c.praPtpt1.total}</td></tr>
                                <tr><td>PRA Level 2</td><td class="text-right text-pra-bocil">${c.praPtpt2.bocil}</td><td class="text-right text-pra-bocol">${c.praPtpt2.bocol}</td><td class="text-right font-bold">${c.praPtpt2.total}</td></tr>
                                <tr><td>PRA Level 3</td><td class="text-right text-pra-bocil">${c.praPtpt3.bocil}</td><td class="text-right text-pra-bocol">${c.praPtpt3.bocol}</td><td class="text-right font-bold">${c.praPtpt3.total}</td></tr>
                                <tr><td>PRA Level 4</td><td class="text-right text-pra-bocil">${c.praPtpt4.bocil}</td><td class="text-right text-pra-bocol">${c.praPtpt4.bocol}</td><td class="text-right font-bold">${c.praPtpt4.total}</td></tr>
                                <tr><td>PRA Level 5</td><td class="text-right text-pra-bocil">${c.praPtpt5.bocil}</td><td class="text-right text-pra-bocol">${c.praPtpt5.bocol}</td><td class="text-right font-bold">${c.praPtpt5.total}</td></tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td><b>TOTAL</b></td>
                                    <td class="text-right text-pra-bocil" style="font-weight: 800;">${subPraBocil.toLocaleString()}</td>
                                    <td class="text-right text-pra-bocol" style="font-weight: 800;">${subPraBocol.toLocaleString()}</td>
                                    <td class="text-right" style="font-weight: 900;">${subPra.toLocaleString()}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <div class="col-jenjang">
                        <div class="col-jenjang-title">
                            <span>PTPT (${subPtpt.toLocaleString()})</span>
                            <span class="sub-badge-bocil-bocol">
                                <span style="color: #9333ea; font-weight: 700;">${subPtptBocil.toLocaleString()} Bocil</span> | 
                                <span style="color: #6d28d9; font-weight: 700;">${subPtptBocol.toLocaleString()} Bocol</span>
                            </span>
                        </div>
                        <table class="tbl-kelas-mini">
                            <thead>
                                <tr>
                                    <th style="text-align: left;">Kelas</th>
                                    <th style="text-align: right; width: 34px; color: #9333ea;">Bocil</th>
                                    <th style="text-align: right; width: 34px; color: #6d28d9;">Bocol</th>
                                    <th style="text-align: right; width: 32px; color: #0f172a;">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td>PTPT Kelas 1</td><td class="text-right text-ptpt-bocil">${c.ptpt1.bocil}</td><td class="text-right text-ptpt-bocol">${c.ptpt1.bocol}</td><td class="text-right font-bold">${c.ptpt1.total}</td></tr>
                                <tr><td>PTPT Kelas 2</td><td class="text-right text-ptpt-bocil">${c.ptpt2.bocil}</td><td class="text-right text-ptpt-bocol">${c.ptpt2.bocol}</td><td class="text-right font-bold">${c.ptpt2.total}</td></tr>
                                <tr><td>PTPT Kelas 3</td><td class="text-right text-ptpt-bocil">${c.ptpt3.bocil}</td><td class="text-right text-ptpt-bocol">${c.ptpt3.bocol}</td><td class="text-right font-bold">${c.ptpt3.total}</td></tr>
                                <tr><td>PTPT Kelas 4</td><td class="text-right text-ptpt-bocil">${c.ptpt4.bocil}</td><td class="text-right text-ptpt-bocol">${c.ptpt4.bocol}</td><td class="text-right font-bold">${c.ptpt4.total}</td></tr>
                                <tr><td>PTPT Kelas 5</td><td class="text-right text-ptpt-bocil">${c.ptpt5.bocil}</td><td class="text-right text-ptpt-bocol">${c.ptpt5.bocol}</td><td class="text-right font-bold">${c.ptpt5.total}</td></tr>
                                <tr><td>PTPT Kelas 6</td><td class="text-right text-ptpt-bocil">${c.ptpt6.bocil}</td><td class="text-right text-ptpt-bocol">${c.ptpt6.bocol}</td><td class="text-right font-bold">${c.ptpt6.total}</td></tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td><b>TOTAL</b></td>
                                    <td class="text-right text-ptpt-bocil" style="font-weight: 800;">${subPtptBocil.toLocaleString()}</td>
                                    <td class="text-right text-ptpt-bocol" style="font-weight: 800;">${subPtptBocol.toLocaleString()}</td>
                                    <td class="text-right" style="font-weight: 900;">${subPtpt.toLocaleString()}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>

                <div class="sig-container" style="justify-content: flex-end;">
                    <div class="sig-box">
                        <p>Surabaya, ${getTanggalSuratIndo()}</p>
                        <p style="font-weight: 600;">Amanah Sekretaris Korcam ${targetKec},</p>
                        <div class="sig-space"></div>
                        <p class="sig-name">( ${sekretarisKorcam} )</p>
                    </div>
                </div>
            `;

            executePrint(htmlContent, `Rekap_Santri_Kecamatan_${targetKec}_${filterBln || 'Semua'}`);
        }

        // Eksekutor Cetak ke Iframe Tersembunyi (Aman tanpa blocker popup)
        function executePrint(contentHtml, docTitle) {
            let printIframe = document.getElementById('printIframeHidden');
            if (!printIframe) {
                printIframe = document.createElement('iframe');
                printIframe.id = 'printIframeHidden';
                printIframe.style.position = 'fixed';
                printIframe.style.right = '0';
                printIframe.style.bottom = '0';
                printIframe.style.width = '0';
                printIframe.style.height = '0';
                printIframe.style.border = '0';
                document.body.appendChild(printIframe);
            }
            
            const pri = printIframe.contentWindow;
            pri.document.open();
            pri.document.write(`<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>${docTitle}</title>
    <style>
        @page { size: A4; margin: 15mm 12mm 15mm 12mm; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #0f172a; margin: 0; padding: 0; font-size: 10pt; line-height: 1.4; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .kop-wrapper { display: flex; align-items: center; justify-content: center; gap: 16px; border-bottom: 3px double #0f172a; padding-bottom: 10px; margin-bottom: 14px; }
        .kop-logo { width: 72px; height: 72px; object-fit: contain; flex-shrink: 0; }
        .kop-text { flex: 1; text-align: center; }
        .kop-text h2 { margin: 0; font-size: 14.5pt; font-weight: 900; color: #0f172a; text-transform: uppercase; letter-spacing: 0.5px; line-height: 1.2; }
        .kop-text h3 { margin: 2px 0 0 0; font-size: 14pt; font-weight: 800; color: #92400e; text-transform: uppercase; letter-spacing: 0.5px; }
        .kop-text p { margin: 4px 0 0 0; font-size: 8.5pt; color: #334155; font-weight: 500; }
        .meta-strip { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; font-size: 8.5pt; background: #f8fafc; padding: 6px 12px; border-radius: 6px; border: 1px solid #e2e8f0; font-weight: 600; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-weight: bold; font-size: 8pt; }
        .badge-amber { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
        .kpi-grid { display: flex; gap: 6px; margin-bottom: 14px; width: 100%; box-sizing: border-box; }
        .kpi-card { flex: 1; min-width: 0; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 3px; text-align: center; background: #ffffff; box-sizing: border-box; }
        .kpi-card-title { font-size: 6pt; text-transform: uppercase; color: #475569; font-weight: 800; margin-bottom: 3px; line-height: 1.15; letter-spacing: 0.2px; white-space: normal; height: 16px; display: flex; align-items: center; justify-content: center; }
        .kpi-card-val { font-size: 11pt; font-weight: 900; color: #0f172a; line-height: 1.1; }
        table.tbl-print { width: 100%; border-collapse: collapse; margin-bottom: 14px; font-size: 7.5pt; table-layout: auto; }
        table.tbl-print th { background-color: #f1f5f9; color: #0f172a; border: 1px solid #cbd5e1; padding: 5px 3px; font-weight: 800; text-align: center; font-size: 7pt; line-height: 1.15; }
        table.tbl-print td { border: 1px solid #cbd5e1; padding: 4px 4px; vertical-align: middle; font-size: 7.5pt; }
        table.tbl-print tr:nth-child(even) { background-color: #f8fafc; }
        table.tbl-print tfoot td { background-color: #0f172a !important; color: #ffffff !important; font-weight: bold; font-size: 7.5pt; padding: 5px 4px; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }
        .section-title { font-size: 9pt; font-weight: 800; color: #92400e; margin: 12px 0 6px 0; text-transform: uppercase; border-bottom: 1.5px solid #e2e8f0; padding-bottom: 3px; letter-spacing: 0.3px; }
        .grid-24 { display: flex; gap: 8px; margin-bottom: 14px; page-break-inside: avoid; }
        .col-jenjang { flex: 1; min-width: 0; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 7px; background: #fafafa; font-size: 7.2pt; box-sizing: border-box; }
        .col-jenjang-title { font-weight: 800; font-size: 7.5pt; text-transform: uppercase; color: #92400e; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px; margin-bottom: 4px; display: flex; justify-content: space-between; align-items: center; }
        .sub-badge-bocil-bocol { font-weight: normal; font-size: 6pt; text-transform: none; }
        table.tbl-kelas-mini { width: 100%; border-collapse: collapse; font-size: 6.8pt; line-height: 1.25; }
        table.tbl-kelas-mini th { border-bottom: 1px solid #cbd5e1; padding: 2px 2px; font-weight: 800; font-size: 6pt; text-transform: uppercase; }
        table.tbl-kelas-mini td { padding: 1.5px 2px; border-bottom: 1px dotted #e2e8f0; vertical-align: middle; }
        table.tbl-kelas-mini tfoot td { border-top: 1.5px solid #cbd5e1; border-bottom: none; padding: 3px 2px; font-size: 6.8pt; font-weight: 800; background: transparent !important; color: #0f172a !important; }
        .text-dasar-bocil { color: #b45309; font-weight: 600; }
        .text-dasar-bocol { color: #c2410c; font-weight: 600; }
        .text-pra-bocil { color: #0284c7; font-weight: 600; }
        .text-pra-bocol { color: #1d4ed8; font-weight: 600; }
        .text-ptpt-bocil { color: #9333ea; font-weight: 600; }
        .text-ptpt-bocol { color: #6d28d9; font-weight: 600; }
        .row-kelas { display: flex; justify-content: space-between; padding: 2px 0; border-bottom: 1px dotted #e2e8f0; font-size: 7.5pt; }
        .sig-container { margin-top: 20px; display: flex; justify-content: space-between; font-size: 8.5pt; page-break-inside: avoid; }
        .sig-box { text-align: center; width: 220px; }
        .sig-space { height: 45px; }
        .sig-name { font-weight: bold; text-decoration: underline; font-size: 9pt; }
    </style>
</head>
<body>
    ${contentHtml}
</body>
</html>`);
            pri.document.close();
            setTimeout(() => {
                pri.focus();
                pri.print();
            }, 400);
        }
            // ================= SERVICE WORKER & PWA INSTALL LOGIC =================
        let deferredPwaPrompt = null;
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('./sw.js').then(reg => {
                    console.log('PWA ServiceWorker terdaftar:', reg.scope);
                }).catch(err => {
                    console.warn('PWA ServiceWorker gagal:', err);
                });
            });
        }

        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPwaPrompt = e;
            const b1 = document.getElementById('btnInstallPwaPublic');
            const b2 = document.getElementById('btnInstallPwaAuth');
            if (b1) b1.classList.remove('hidden');
            if (b2) b2.classList.remove('hidden');
        });

        window.addEventListener('appinstalled', () => {
            console.log('Aplikasi DataSantri berhasil dipasang di perangkat!');
            deferredPwaPrompt = null;
            const b1 = document.getElementById('btnInstallPwaPublic');
            const b2 = document.getElementById('btnInstallPwaAuth');
            if (b1) b1.classList.add('hidden');
            if (b2) b2.classList.add('hidden');
        });

        function triggerPwaInstall() {
            if (deferredPwaPrompt) {
                deferredPwaPrompt.prompt();
                deferredPwaPrompt.userChoice.then((choiceResult) => {
                    if (choiceResult.outcome === 'accepted') {
                        console.log('User menerima pemasangan aplikasi');
                    }
                    deferredPwaPrompt = null;
                    const b1 = document.getElementById('btnInstallPwaPublic');
                    const b2 = document.getElementById('btnInstallPwaAuth');
                    if (b1) b1.classList.add('hidden');
                    if (b2) b2.classList.add('hidden');
                });
            } else {
                alert("Petunjuk Pemasangan Aplikasi di Android:\n\n1. Buka situs ini melalui Google Chrome pada HP Android Anda.\n2. Ketuk ikon titik tiga (â‹®) di sudut kanan atas browser.\n3. Pilih menu 'Tambahkan ke Layar Utama' (Add to Home screen) atau 'Pasang Aplikasi'.\n4. Ikon aplikasi DataSantri akan langsung terpasang di layar utama HP Anda dan dapat dibuka selayaknya aplikasi Android.");
            }
        }

